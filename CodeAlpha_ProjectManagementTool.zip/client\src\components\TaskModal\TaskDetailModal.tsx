import React, { useState, useEffect } from 'react';
import {
  X,
  Calendar,
  CheckSquare,
  Paperclip,
  MessageSquare,
  AlertCircle,
  Plus,
  Trash2,
  Edit2,
  Smile,
  Send,
  UserPlus,
  Tag,
  Clock,
  Sparkles,
  ExternalLink,
} from 'lucide-react';
import { Task, User, Comment, Checklist, Attachment, Project } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useSocket } from '../../context/SocketContext';
import api from '../../services/api';

interface TaskDetailModalProps {
  taskId: string;
  project: Project;
  onClose: () => void;
  onTaskUpdated: (updatedTask: Task) => void;
  onTaskDeleted: (taskId: string) => void;
}

export const TaskDetailModal: React.FC<TaskDetailModalProps> = ({
  taskId,
  project,
  onClose,
  onTaskUpdated,
  onTaskDeleted,
}) => {
  const { user } = useAuth();
  const { socket, typingUsers, emitTyping } = useSocket();

  const [task, setTask] = useState<Task | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'details' | 'activity'>('details');

  // Editing states
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isEditingDesc, setIsEditingDesc] = useState(false);

  // Comments
  const [commentText, setCommentText] = useState('');
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  const [editingCommentId, setEditingCommentId] = useState<string | null>(null);
  const [editCommentText, setEditCommentText] = useState('');

  // Checklists
  const [newChecklistTitle, setNewChecklistTitle] = useState('');
  const [newItemText, setNewItemText] = useState<{ [clId: string]: string }>({});

  // Attachments
  const [attachmentFileName, setAttachmentFileName] = useState('');
  const [attachmentUrl, setAttachmentUrl] = useState('');
  const [isAddingAttachment, setIsAddingAttachment] = useState(false);

  // Fetch task full details
  const loadTask = async () => {
    try {
      const data = await api.getTask(taskId);
      setTask(data);
      setTitle(data.title);
      setDescription(data.description || '');
      setIsLoading(false);
    } catch (error) {
      console.error('Failed to load task:', error);
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadTask();
  }, [taskId]);

  // Real-time listener for task comment & checklist updates
  useEffect(() => {
    if (!socket) return;

    const handleCommentCreated = ({ taskId: tId, comment }: { taskId: string; comment: Comment }) => {
      if (tId === taskId) {
        setTask((prev) => {
          if (!prev) return prev;
          const currentComments = Array.isArray(prev.comments) ? (prev.comments as Comment[]) : [];
          if (currentComments.some((c) => c.id === comment.id)) return prev;
          return { ...prev, comments: [...currentComments, comment] };
        });
      }
    };

    const handleCommentDeleted = ({ taskId: tId, commentId }: { taskId: string; commentId: string }) => {
      if (tId === taskId) {
        setTask((prev) => {
          if (!prev) return prev;
          const currentComments = Array.isArray(prev.comments) ? (prev.comments as Comment[]) : [];
          return { ...prev, comments: currentComments.filter((c) => c.id !== commentId) };
        });
      }
    };

    const handleReactionUpdated = ({ taskId: tId, commentId, reactions }: any) => {
      if (tId === taskId) {
        setTask((prev) => {
          if (!prev) return prev;
          const currentComments = Array.isArray(prev.comments) ? (prev.comments as Comment[]) : [];
          return {
            ...prev,
            comments: currentComments.map((c) =>
              c.id === commentId ? { ...c, reactions: JSON.stringify(reactions) } : c
            ),
          };
        });
      }
    };

    const handleChecklistItemUpdated = ({ taskId: tId, item }: any) => {
      if (tId === taskId) {
        setTask((prev) => {
          if (!prev) return prev;
          return {
            ...prev,
            checklists: prev.checklists?.map((cl) =>
              cl.id === item.checklistId
                ? { ...cl, items: cl.items.map((i) => (i.id === item.id ? item : i)) }
                : cl
            ),
          };
        });
      }
    };

    socket.on('comment:created', handleCommentCreated);
    socket.on('comment:deleted', handleCommentDeleted);
    socket.on('comment:reaction_updated', handleReactionUpdated);
    socket.on('checklist_item:updated', handleChecklistItemUpdated);

    return () => {
      socket.off('comment:created', handleCommentCreated);
      socket.off('comment:deleted', handleCommentDeleted);
      socket.off('comment:reaction_updated', handleReactionUpdated);
      socket.off('checklist_item:updated', handleChecklistItemUpdated);
    };
  }, [socket, taskId]);

  if (isLoading || !task) {
    return (
      <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl p-8 max-w-sm w-full text-center shadow-2xl">
          <div className="w-10 h-10 border-4 border-[#A3E635] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-sm font-semibold text-gray-700">Loading task details...</p>
        </div>
      </div>
    );
  }

  // Updates
  const handleSaveTitle = async () => {
    if (title.trim() && title !== task.title) {
      const updated = await api.updateTask(task.id, { title: title.trim() });
      setTask({ ...task, title: updated.title });
      onTaskUpdated(updated);
    }
    setIsEditingTitle(false);
  };

  const handleSaveDescription = async () => {
    const updated = await api.updateTask(task.id, { description });
    setTask({ ...task, description });
    setIsEditingDesc(false);
    onTaskUpdated(updated);
  };

  const handleChangePriority = async (newPriority: any) => {
    const updated = await api.updateTask(task.id, { priority: newPriority });
    setTask({ ...task, priority: newPriority });
    onTaskUpdated(updated);
  };

  const handleChangeDueDate = async (newDate: string) => {
    const updated = await api.updateTask(task.id, { dueDate: newDate });
    setTask({ ...task, dueDate: newDate });
    onTaskUpdated(updated);
  };

  const handleDeleteTask = async () => {
    if (!confirm('Are you sure you want to delete this task?')) return;
    await api.deleteTask(task.id);
    onTaskDeleted(task.id);
    onClose();
  };

  // Toggle Assignee
  const handleToggleAssignee = async (targetUserId: string) => {
    await api.toggleAssignee(task.id, targetUserId);
    loadTask();
  };

  // Toggle Label
  const handleToggleLabel = async (labelId: string) => {
    await api.toggleLabel(task.id, labelId);
    loadTask();
  };

  // Checklists
  const handleAddChecklist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChecklistTitle.trim()) return;
    const newCl = await api.createChecklist(task.id, newChecklistTitle.trim());
    setTask({
      ...task,
      checklists: [...(task.checklists || []), { ...newCl, items: [] }],
    });
    setNewChecklistTitle('');
  };

  const handleAddChecklistItem = async (checklistId: string) => {
    const text = newItemText[checklistId];
    if (!text || !text.trim()) return;
    const item = await api.createChecklistItem(checklistId, text.trim());
    setTask({
      ...task,
      checklists: task.checklists?.map((cl) =>
        cl.id === checklistId ? { ...cl, items: [...cl.items, item] } : cl
      ),
    });
    setNewItemText({ ...newItemText, [checklistId]: '' });
  };

  const handleToggleChecklistItem = async (itemId: string, completed: boolean) => {
    await api.updateChecklistItem(itemId, { completed });
    setTask({
      ...task,
      checklists: task.checklists?.map((cl) => ({
        ...cl,
        items: cl.items.map((i) => (i.id === itemId ? { ...i, completed } : i)),
      })),
    });
  };

  const handleDeleteChecklistItem = async (itemId: string) => {
    await api.deleteChecklistItem(itemId);
    setTask({
      ...task,
      checklists: task.checklists?.map((cl) => ({
        ...cl,
        items: cl.items.filter((i) => i.id !== itemId),
      })),
    });
  };

  // Comments
  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    setIsSubmittingComment(true);
    emitTyping(project.id, task.id, false);
    try {
      const comment = await api.createComment(task.id, commentText.trim());
      const currentComments = Array.isArray(task.comments) ? (task.comments as Comment[]) : [];
      setTask({ ...task, comments: [...currentComments, comment] });
      setCommentText('');
    } catch (err) {
      console.error('Failed to post comment:', err);
    } finally {
      setIsSubmittingComment(false);
    }
  };

  const handleToggleReaction = async (commentId: string, emoji: string) => {
    try {
      const updated = await api.toggleReaction(commentId, emoji);
      const currentComments = Array.isArray(task.comments) ? (task.comments as Comment[]) : [];
      setTask({
        ...task,
        comments: currentComments.map((c) => (c.id === commentId ? updated : c)),
      });
    } catch (err) {
      console.error('Failed to toggle reaction:', err);
    }
  };

  const handleDeleteComment = async (commentId: string) => {
    if (!confirm('Delete this comment?')) return;
    await api.deleteComment(commentId);
    const currentComments = Array.isArray(task.comments) ? (task.comments as Comment[]) : [];
    setTask({
      ...task,
      comments: currentComments.filter((c) => c.id !== commentId),
    });
  };

  // Attachments
  const handleAddAttachment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!attachmentFileName.trim() || !attachmentUrl.trim()) return;
    try {
      const newAtt = await api.addAttachment(task.id, {
        fileName: attachmentFileName.trim(),
        fileUrl: attachmentUrl.trim(),
      });
      setTask({
        ...task,
        attachments: [...(task.attachments || []), newAtt],
      });
      setAttachmentFileName('');
      setAttachmentUrl('');
      setIsAddingAttachment(false);
    } catch (error) {
      console.error('Failed to add attachment:', error);
    }
  };

  const handleDeleteAttachment = async (attachmentId: string) => {
    await api.deleteAttachment(attachmentId);
    setTask({
      ...task,
      attachments: task.attachments?.filter((a) => a.id !== attachmentId),
    });
  };

  const commentsList: Comment[] = Array.isArray(task.comments)
    ? (task.comments as Comment[]).filter((c) => c.body !== undefined)
    : [];

  const typingNames = typingUsers[task.id] || [];

  return (
    <div
      className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-2 sm:p-4 overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-3xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl border border-gray-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Bar */}
        <div className="px-6 py-4 bg-[#20242C] text-white flex items-center justify-between border-b border-[#2D333F]">
          <div className="flex items-center space-x-3">
            <span
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: project.color }}
            />
            <span className="text-xs text-gray-400 font-medium">
              {project.name} / {task.list?.name || 'Board'}
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleDeleteTask}
              className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-500/20 transition-colors text-xs font-semibold flex items-center gap-1"
              title="Delete Task"
            >
              <Trash2 className="w-4 h-4" />
              <span className="hidden sm:inline">Delete</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-[#2D333F] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Main Body: 2 Columns */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Main Left Rail (2 cols) */}
          <div className="md:col-span-2 space-y-6">
            {/* Title */}
            <div>
              {isEditingTitle ? (
                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSaveTitle()}
                    className="w-full text-xl font-bold text-[#20242C] border-2 border-[#A3E635] rounded-xl px-3 py-1.5 focus:outline-none"
                    autoFocus
                  />
                  <button
                    onClick={handleSaveTitle}
                    className="px-3 py-1.5 bg-[#A3E635] text-[#20242C] font-bold text-xs rounded-xl"
                  >
                    Save
                  </button>
                </div>
              ) : (
                <h2
                  onClick={() => setIsEditingTitle(true)}
                  className="text-xl sm:text-2xl font-extrabold text-[#20242C] hover:bg-gray-50 p-1 -ml-1 rounded-lg cursor-pointer transition-colors"
                >
                  {task.title}
                </h2>
              )}
            </div>

            {/* Description Section */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500 flex items-center gap-1.5">
                  <Edit2 className="w-3.5 h-3.5 text-[#A3E635]" />
                  Description
                </h4>
                {!isEditingDesc && (
                  <button
                    onClick={() => setIsEditingDesc(true)}
                    className="text-xs text-gray-500 hover:text-[#20242C] font-semibold"
                  >
                    Edit
                  </button>
                )}
              </div>

              {isEditingDesc ? (
                <div className="space-y-2">
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Add detailed markdown notes, requirements, or links..."
                    rows={4}
                    className="w-full text-xs text-[#20242C] p-3 border border-[#A3E635] rounded-xl focus:outline-none resize-none leading-relaxed"
                    autoFocus
                  />
                  <div className="flex space-x-2">
                    <button
                      onClick={handleSaveDescription}
                      className="bg-[#A3E635] hover:bg-[#8dd321] text-[#20242C] font-bold text-xs px-3.5 py-1.5 rounded-lg"
                    >
                      Save Description
                    </button>
                    <button
                      onClick={() => setIsEditingDesc(false)}
                      className="text-gray-500 text-xs px-2 py-1.5"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <div
                  onClick={() => setIsEditingDesc(true)}
                  className="bg-gray-50 hover:bg-gray-100/80 rounded-xl p-3.5 text-xs text-gray-700 min-h-[70px] cursor-pointer whitespace-pre-wrap leading-relaxed border border-gray-100"
                >
                  {task.description || (
                    <span className="text-gray-400 italic">No description provided. Click to add details...</span>
                  )}
                </div>
              )}
            </div>

            {/* Checklists Section */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500 flex items-center gap-1.5">
                  <CheckSquare className="w-3.5 h-3.5 text-[#A3E635]" />
                  Checklists
                </h4>
              </div>

              {task.checklists?.map((checklist) => {
                const total = checklist.items?.length || 0;
                const completed = checklist.items?.filter((i) => i.completed).length || 0;
                const percent = total > 0 ? Math.round((completed / total) * 100) : 0;

                return (
                  <div key={checklist.id} className="bg-gray-50/70 border border-gray-200 rounded-2xl p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-[#20242C]">{checklist.title}</span>
                      <span className="text-xs font-bold text-gray-500">{percent}%</span>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full h-1.5 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-[#A3E635] rounded-full transition-all duration-300"
                        style={{ width: `${percent}%` }}
                      />
                    </div>

                    {/* Items List */}
                    <div className="space-y-2">
                      {checklist.items?.map((item) => (
                        <div
                          key={item.id}
                          className="flex items-center justify-between group p-1.5 hover:bg-white rounded-lg transition-colors"
                        >
                          <label className="flex items-center space-x-2.5 cursor-pointer flex-1">
                            <input
                              type="checkbox"
                              checked={item.completed}
                              onChange={(e) => handleToggleChecklistItem(item.id, e.target.checked)}
                              className="w-4 h-4 rounded text-[#A3E635] accent-[#A3E635] cursor-pointer"
                            />
                            <span
                              className={`text-xs ${
                                item.completed ? 'line-through text-gray-400' : 'text-[#20242C] font-medium'
                              }`}
                            >
                              {item.text}
                            </span>
                          </label>
                          <button
                            onClick={() => handleDeleteChecklistItem(item.id)}
                            className="opacity-0 group-hover:opacity-100 p-1 text-gray-400 hover:text-rose-500 transition-opacity"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>

                    {/* Add Item to Checklist */}
                    <div className="flex items-center space-x-2 pt-1">
                      <input
                        type="text"
                        value={newItemText[checklist.id] || ''}
                        onChange={(e) =>
                          setNewItemText({ ...newItemText, [checklist.id]: e.target.value })
                        }
                        onKeyDown={(e) => e.key === 'Enter' && handleAddChecklistItem(checklist.id)}
                        placeholder="Add subtask item..."
                        className="flex-1 text-xs px-3 py-1.5 bg-white border border-gray-200 rounded-xl focus:outline-none focus:border-[#A3E635]"
                      />
                      <button
                        onClick={() => handleAddChecklistItem(checklist.id)}
                        className="px-3 py-1.5 bg-[#20242C] text-white hover:bg-[#323946] font-semibold text-xs rounded-xl"
                      >
                        Add
                      </button>
                    </div>
                  </div>
                );
              })}

              {/* Add New Checklist Trigger */}
              <form onSubmit={handleAddChecklist} className="flex items-center space-x-2">
                <input
                  type="text"
                  value={newChecklistTitle}
                  onChange={(e) => setNewChecklistTitle(e.target.value)}
                  placeholder="New checklist title (e.g. Design review)..."
                  className="flex-1 text-xs px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-[#A3E635]"
                />
                <button
                  type="submit"
                  disabled={!newChecklistTitle.trim()}
                  className="px-4 py-2 bg-[#A3E635] text-[#20242C] font-bold text-xs rounded-xl disabled:opacity-50"
                >
                  + Add Checklist
                </button>
              </form>
            </div>

            {/* Attachments Section */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500 flex items-center gap-1.5">
                  <Paperclip className="w-3.5 h-3.5 text-[#A3E635]" />
                  Attachments ({task.attachments?.length || 0})
                </h4>
                <button
                  onClick={() => setIsAddingAttachment(!isAddingAttachment)}
                  className="text-xs text-[#20242C] font-semibold hover:text-[#A3E635] flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add Link / File
                </button>
              </div>

              {isAddingAttachment && (
                <form
                  onSubmit={handleAddAttachment}
                  className="p-3 bg-gray-50 border border-gray-200 rounded-xl space-y-2 mb-3"
                >
                  <input
                    type="text"
                    value={attachmentFileName}
                    onChange={(e) => setAttachmentFileName(e.target.value)}
                    placeholder="File name (e.g. Figma Prototype)"
                    className="w-full text-xs px-3 py-1.5 bg-white border border-gray-200 rounded-lg focus:outline-none focus:border-[#A3E635]"
                    required
                  />
                  <input
                    type="url"
                    value={attachmentUrl}
                    onChange={(e) => setAttachmentUrl(e.target.value)}
                    placeholder="URL (e.g. https://figma.com/... or cloud link)"
                    className="w-full text-xs px-3 py-1.5 bg-white border border-gray-200 rounded-lg focus:outline-none focus:border-[#A3E635]"
                    required
                  />
                  <div className="flex space-x-2">
                    <button
                      type="submit"
                      className="bg-[#A3E635] text-[#20242C] font-bold text-xs px-3 py-1.5 rounded-lg"
                    >
                      Save Attachment
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsAddingAttachment(false)}
                      className="text-gray-500 text-xs px-2 py-1.5"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              )}

              <div className="space-y-1.5">
                {task.attachments?.map((att) => (
                  <div
                    key={att.id}
                    className="flex items-center justify-between p-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs hover:border-[#A3E635] transition-colors"
                  >
                    <a
                      href={att.fileUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center space-x-2 text-[#20242C] hover:text-[#A3E635] font-semibold truncate"
                    >
                      <ExternalLink className="w-3.5 h-3.5 flex-shrink-0" />
                      <span className="truncate">{att.fileName}</span>
                    </a>
                    <button
                      onClick={() => handleDeleteAttachment(att.id)}
                      className="text-gray-400 hover:text-rose-500 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Comments & Collaboration Stream */}
            <div className="pt-4 border-t border-gray-100 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500 flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-[#A3E635]" />
                  Discussion ({commentsList.length})
                </h4>

                {/* Live typing indicator */}
                {typingNames.length > 0 && (
                  <div className="flex items-center space-x-1.5 text-xs text-[#20242C] font-medium bg-[#D9F99D]/40 px-2.5 py-0.5 rounded-full animate-pulse">
                    <span className="w-2 h-2 rounded-full bg-[#A3E635]" />
                    <span>{typingNames.join(', ')} is typing...</span>
                  </div>
                )}
              </div>

              {/* Comment composer */}
              <form onSubmit={handleAddComment} className="space-y-2">
                <div className="relative">
                  <textarea
                    value={commentText}
                    onChange={(e) => {
                      setCommentText(e.target.value);
                      emitTyping(project.id, task.id, e.target.value.length > 0);
                    }}
                    onBlur={() => emitTyping(project.id, task.id, false)}
                    placeholder="Write a comment... Tip: Mention teammates with @Alex or @Riya"
                    rows={3}
                    className="w-full text-xs text-[#20242C] p-3 border border-gray-200 rounded-2xl focus:outline-none focus:border-[#A3E635] shadow-xs resize-none leading-relaxed"
                  />
                  <div className="flex items-center justify-between pt-1">
                    <div className="flex items-center space-x-1 text-gray-400 text-xs">
                      <span className="font-medium text-[11px] text-gray-400">
                        Supports @mentions & emoji reactions
                      </span>
                    </div>

                    <button
                      type="submit"
                      disabled={!commentText.trim() || isSubmittingComment}
                      className="bg-[#A3E635] hover:bg-[#8dd321] text-[#20242C] font-bold text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 disabled:opacity-50 transition-colors shadow-xs"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Comment</span>
                    </button>
                  </div>
                </div>
              </form>

              {/* Comments List */}
              <div className="space-y-3.5 pt-2">
                {commentsList.map((c) => {
                  let reactions: Record<string, string[]> = {};
                  try {
                    reactions = c.reactions ? JSON.parse(c.reactions) : {};
                  } catch {
                    reactions = {};
                  }

                  const emojis = ['👍', '❤️', '🚀', '👀', '🎉'];

                  return (
                    <div
                      key={c.id}
                      className="p-3.5 bg-gray-50 border border-gray-100 rounded-2xl space-y-2 group"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2.5">
                          <img
                            src={c.author?.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${c.author?.name}`}
                            alt={c.author?.name}
                            className="w-7 h-7 rounded-full object-cover border border-gray-200"
                          />
                          <div>
                            <span className="text-xs font-bold text-[#20242C] mr-2">
                              {c.author?.name}
                            </span>
                            <span className="text-[11px] text-gray-400">
                              {new Date(c.createdAt).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                            {c.edited && (
                              <span className="ml-1.5 text-[10px] text-gray-400 italic">
                                (edited)
                              </span>
                            )}
                          </div>
                        </div>

                        {c.authorId === user?.id && (
                          <button
                            onClick={() => handleDeleteComment(c.id)}
                            className="opacity-0 group-hover:opacity-100 p-1 text-gray-400 hover:text-rose-500 transition-opacity"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                      {/* Comment Body */}
                      <p className="text-xs text-gray-800 whitespace-pre-wrap leading-relaxed pl-9">
                        {c.body}
                      </p>

                      {/* Emoji Reactions Row */}
                      <div className="flex flex-wrap items-center gap-1.5 pl-9 pt-1">
                        {emojis.map((emoji) => {
                          const userList = reactions[emoji] || [];
                          const hasReacted = userList.includes(user?.id || '');
                          if (userList.length === 0 && !hasReacted) return null;

                          return (
                            <button
                              key={emoji}
                              onClick={() => handleToggleReaction(c.id, emoji)}
                              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold border transition-all ${
                                hasReacted
                                  ? 'bg-[#A3E635]/20 border-[#A3E635] text-[#20242C]'
                                  : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-100'
                              }`}
                            >
                              <span>{emoji}</span>
                              <span className="text-[11px] font-bold">{userList.length}</span>
                            </button>
                          );
                        })}

                        {/* Add Reaction Button */}
                        <div className="relative group/emoji inline-block">
                          <button className="p-1 rounded-full text-gray-400 hover:text-gray-600 hover:bg-gray-200 transition-colors">
                            <Smile className="w-3.5 h-3.5" />
                          </button>
                          <div className="hidden group-hover/emoji:flex absolute left-0 bottom-full mb-1 bg-white border border-gray-200 rounded-xl shadow-lg p-1 space-x-1 z-20">
                            {emojis.map((emoji) => (
                              <button
                                key={emoji}
                                onClick={() => handleToggleReaction(c.id, emoji)}
                                className="p-1 hover:bg-gray-100 rounded text-sm hover:scale-125 transition-transform"
                              >
                                {emoji}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Rail: Properties & Actions */}
          <div className="space-y-6 md:border-l md:border-gray-100 md:pl-6">
            {/* Priority Selector */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-gray-400 block mb-1.5">
                Priority
              </label>
              <select
                value={task.priority}
                onChange={(e) => handleChangePriority(e.target.value)}
                className="w-full text-xs font-semibold px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-[#20242C] focus:outline-none focus:border-[#A3E635]"
              >
                <option value="LOW">Low</option>
                <option value="MEDIUM">Medium</option>
                <option value="HIGH">High</option>
                <option value="URGENT">Urgent ⚡</option>
              </select>
            </div>

            {/* Due Date */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-gray-400 block mb-1.5">
                Due Date
              </label>
              <input
                type="date"
                value={task.dueDate ? new Date(task.dueDate).toISOString().split('T')[0] : ''}
                onChange={(e) => handleChangeDueDate(e.target.value)}
                className="w-full text-xs font-medium px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-[#20242C] focus:outline-none focus:border-[#A3E635]"
              />
            </div>

            {/* Assignees Picker */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-gray-400 block mb-1.5">
                Assignees ({task.assignees?.length || 0})
              </label>
              <div className="space-y-1.5 max-h-40 overflow-y-auto">
                {project.members?.map((m) => {
                  const isAssigned = task.assignees?.some((a) => a.userId === m.userId);
                  return (
                    <button
                      key={m.userId}
                      onClick={() => handleToggleAssignee(m.userId)}
                      className={`w-full flex items-center justify-between p-2 rounded-xl text-xs font-medium border transition-colors ${
                        isAssigned
                          ? 'bg-[#A3E635]/15 border-[#A3E635] text-[#20242C]'
                          : 'bg-white border-gray-100 text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      <div className="flex items-center space-x-2 truncate">
                        <img
                          src={m.user?.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${m.user?.name}`}
                          alt={m.user?.name}
                          className="w-5 h-5 rounded-full object-cover"
                        />
                        <span className="truncate">{m.user?.name}</span>
                      </div>
                      {isAssigned && <span className="text-[10px] font-bold text-green-700">✓</span>}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Labels Picker */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-gray-400 block mb-1.5">
                Labels
              </label>
              <div className="flex flex-wrap gap-1.5">
                {project.labels?.map((label) => {
                  const isApplied = task.labels?.some((tl) => tl.labelId === label.id);
                  return (
                    <button
                      key={label.id}
                      onClick={() => handleToggleLabel(label.id)}
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium border transition-all ${
                        isApplied
                          ? 'border-[#20242C] text-[#20242C] font-bold shadow-xs'
                          : 'border-gray-200 text-gray-500 hover:border-gray-400'
                      }`}
                    >
                      <span
                        className="w-2 h-2 rounded-full"
                        style={{ backgroundColor: label.color }}
                      />
                      <span>{label.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Task Info Metadata */}
            <div className="pt-4 border-t border-gray-100 text-[11px] text-gray-400 space-y-1 font-medium">
              <div>Created: {new Date(task.createdAt).toLocaleDateString()}</div>
              <div>Last updated: {new Date(task.updatedAt).toLocaleDateString()}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
