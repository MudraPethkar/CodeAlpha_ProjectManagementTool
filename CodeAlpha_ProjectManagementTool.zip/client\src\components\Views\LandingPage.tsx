import React from 'react';
import {
  CheckCircle2,
  Zap,
  Users,
  Kanban,
  Bell,
  MessageSquare,
  ArrowRight,
  ShieldCheck,
  Sparkles,
  Layers,
  Clock,
} from 'lucide-react';

interface LandingPageProps {
  onGoToAuth: (mode: 'login' | 'register') => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onGoToAuth,
}) => {
  return (
    <div className="min-h-screen bg-[#F9FAFB] text-[#20242C] flex flex-col font-sans selection:bg-[#D9F99D] selection:text-[#20242C]">
      {/* Top Marketing Navigation */}
      <header className="h-20 bg-white/80 backdrop-blur-md border-b border-[#E5E7EB] px-6 md:px-12 flex items-center justify-between sticky top-0 z-40 shadow-xs">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-[#A3E635] flex items-center justify-center text-[#20242C] shadow-md shadow-[#A3E635]/20">
            <CheckCircle2 className="w-6 h-6 stroke-[2.5]" />
          </div>
          <div>
            <span className="font-black text-xl tracking-tight text-[#20242C]">TASKLY</span>
            <span className="hidden sm:inline-block text-[11px] font-bold text-gray-400 ml-2">
              Plan together. Ship faster.
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-3 sm:space-x-4">
          <button
            onClick={() => onGoToAuth('login')}
            className="text-xs sm:text-sm font-bold text-[#20242C] hover:text-black px-3.5 py-2 rounded-xl transition-colors"
          >
            Sign in
          </button>
          <button
            onClick={() => onGoToAuth('register')}
            className="bg-[#20242C] hover:bg-[#323946] text-white font-bold text-xs sm:text-sm px-4 sm:px-5 py-2.5 rounded-xl shadow-md transition-all active:scale-95"
          >
            Get Started Free
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-16 pb-20 md:pt-24 md:pb-32 px-6 max-w-7xl mx-auto w-full text-center">
        <div className="inline-flex items-center space-x-2 bg-white border border-[#E5E7EB] px-4 py-1.5 rounded-full text-xs font-bold text-[#20242C] shadow-xs mb-8">
          <span className="w-2 h-2 rounded-full bg-[#A3E635] animate-ping" />
          <span>Real-time WebSocket Collaboration Engine 2.0</span>
        </div>

        <h1 className="text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tight text-[#20242C] max-w-4xl mx-auto leading-[1.08] mb-6">
          Plan together.{' '}
          <span className="relative inline-block">
            <span className="relative z-10 text-[#20242C] underline decoration-[#A3E635] decoration-wavy decoration-4">
              Ship faster.
            </span>
          </span>
        </h1>

        <p className="text-base sm:text-xl text-gray-600 max-w-2xl mx-auto mb-10 leading-relaxed">
          The collaborative project management platform built for modern product teams.
          Kanban boards, instant WebSocket updates, checklists, and @mentions without friction.
        </p>

        {/* Hero CTAs */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 mb-16">
          <button
            onClick={() => onGoToAuth('register')}
            className="w-full sm:w-auto bg-[#A3E635] hover:bg-[#8dd321] text-[#20242C] font-extrabold text-sm sm:text-base px-8 py-4 rounded-2xl shadow-xl shadow-[#A3E635]/25 flex items-center justify-center space-x-2 transition-all active:scale-95"
          >
            <span>Get Started Free</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => onGoToAuth('login')}
            className="w-full sm:w-auto bg-white hover:bg-gray-50 border border-gray-200 text-[#20242C] font-bold text-sm sm:text-base px-7 py-4 rounded-2xl shadow-xs flex items-center justify-center space-x-2 transition-all"
          >
            <span>Sign In to Workspace</span>
          </button>
        </div>

        {/* Interactive App Preview Banner */}
        <div className="relative mx-auto max-w-5xl rounded-3xl overflow-hidden border border-gray-200 shadow-2xl bg-[#20242C] text-left">
          {/* Mock Window Controls */}
          <div className="h-10 bg-[#181B21] px-4 flex items-center justify-between border-b border-[#2D333F]">
            <div className="flex items-center space-x-2">
              <span className="w-3 h-3 rounded-full bg-rose-500/80" />
              <span className="w-3 h-3 rounded-full bg-amber-500/80" />
              <span className="w-3 h-3 rounded-full bg-emerald-500/80" />
            </div>
            <span className="text-xs font-mono text-gray-400">taskly.dev/board/sprint-24</span>
            <div className="flex items-center space-x-1.5 text-[11px] text-[#A3E635] font-mono">
              <span className="w-2 h-2 rounded-full bg-[#A3E635] animate-pulse" />
              <span>4 members online</span>
            </div>
          </div>

          {/* Mock Kanban Layout */}
          <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-4 bg-[#1C2028]">
            {/* Column 1 */}
            <div className="bg-[#20242C] rounded-2xl p-4 border border-[#2D333F]">
              <div className="flex items-center justify-between text-xs font-bold text-gray-300 mb-3 uppercase">
                <span>In Progress</span>
                <span className="bg-[#2D333F] text-[#A3E635] px-2 py-0.5 rounded-full text-[10px]">2</span>
              </div>
              <div className="bg-[#282D37] rounded-xl p-3 border border-[#3A4150] shadow-sm mb-2.5">
                <span className="text-[10px] font-black uppercase text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded">High</span>
                <p className="text-xs font-bold text-white mt-2">Smooth drag & drop reordering</p>
                <div className="flex items-center justify-between text-[11px] text-gray-400 mt-3 pt-2 border-t border-[#3A4150]">
                  <span>2/3 subtasks</span>
                  <div className="w-5 h-5 rounded-full bg-[#A3E635] text-[#20242C] font-bold text-[10px] flex items-center justify-center">R</div>
                </div>
              </div>
            </div>

            {/* Column 2 */}
            <div className="bg-[#20242C] rounded-2xl p-4 border border-[#2D333F]">
              <div className="flex items-center justify-between text-xs font-bold text-gray-300 mb-3 uppercase">
                <span>Review</span>
                <span className="bg-[#2D333F] text-[#A3E635] px-2 py-0.5 rounded-full text-[10px]">1</span>
              </div>
              <div className="bg-[#282D37] rounded-xl p-3 border border-[#3A4150] shadow-sm">
                <span className="text-[10px] font-black uppercase text-rose-400 bg-rose-400/10 px-2 py-0.5 rounded">Urgent</span>
                <p className="text-xs font-bold text-white mt-2">WebSocket live room broadcast</p>
                <div className="flex items-center justify-between text-[11px] text-gray-400 mt-3 pt-2 border-t border-[#3A4150]">
                  <span>💬 3 comments</span>
                  <div className="w-5 h-5 rounded-full bg-blue-500 text-white font-bold text-[10px] flex items-center justify-center">M</div>
                </div>
              </div>
            </div>

            {/* Column 3 */}
            <div className="bg-[#20242C] rounded-2xl p-4 border border-[#2D333F]">
              <div className="flex items-center justify-between text-xs font-bold text-gray-300 mb-3 uppercase">
                <span>Done</span>
                <span className="bg-[#2D333F] text-[#A3E635] px-2 py-0.5 rounded-full text-[10px]">4</span>
              </div>
              <div className="bg-[#282D37] rounded-xl p-3 border border-[#3A4150] shadow-sm">
                <span className="text-[10px] font-black uppercase text-emerald-400 bg-emerald-400/10 px-2 py-0.5 rounded">Design</span>
                <p className="text-xs font-bold text-white mt-2">Graphite Lime design system tokens</p>
                <div className="flex items-center justify-between text-[11px] text-gray-400 mt-3 pt-2 border-t border-[#3A4150]">
                  <span className="text-emerald-400">✓ Completed</span>
                  <div className="w-5 h-5 rounded-full bg-[#A3E635] text-[#20242C] font-bold text-[10px] flex items-center justify-center">A</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Core Features Grid */}
      <section className="py-20 bg-white border-y border-[#E5E7EB] px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-xs font-bold uppercase tracking-wider text-[#A3E635] bg-[#20242C] px-3 py-1 rounded-full inline-block mb-3">
              Built for Engineering & Design Velocity
            </h2>
            <h3 className="text-3xl sm:text-4xl font-extrabold text-[#20242C] tracking-tight">
              Everything your team needs to ship on time.
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-[#F9FAFB] rounded-3xl p-8 border border-gray-200">
              <div className="w-12 h-12 rounded-2xl bg-[#A3E635] flex items-center justify-center text-[#20242C] mb-6 shadow-md shadow-[#A3E635]/20">
                <Kanban className="w-6 h-6 stroke-[2.5]" />
              </div>
              <h4 className="text-xl font-bold text-[#20242C] mb-2">Fluid Kanban Boards</h4>
              <p className="text-xs text-gray-600 leading-relaxed">
                Drag-and-drop tasks effortlessly between Backlog, To Do, In Progress, Review, and Done. Add custom columns and filters.
              </p>
            </div>

            <div className="bg-[#F9FAFB] rounded-3xl p-8 border border-gray-200">
              <div className="w-12 h-12 rounded-2xl bg-[#20242C] flex items-center justify-center text-[#A3E635] mb-6 shadow-md">
                <Zap className="w-6 h-6 stroke-[2.5]" />
              </div>
              <h4 className="text-xl font-bold text-[#20242C] mb-2">Real-Time WebSockets</h4>
              <p className="text-xs text-gray-600 leading-relaxed">
                Changes appear instantly across all team members’ screens. Live presence dots indicate who is viewing the board in real time.
              </p>
            </div>

            <div className="bg-[#F9FAFB] rounded-3xl p-8 border border-gray-200">
              <div className="w-12 h-12 rounded-2xl bg-[#A3E635] flex items-center justify-center text-[#20242C] mb-6 shadow-md shadow-[#A3E635]/20">
                <MessageSquare className="w-6 h-6 stroke-[2.5]" />
              </div>
              <h4 className="text-xl font-bold text-[#20242C] mb-2">Comments & @Mentions</h4>
              <p className="text-xs text-gray-600 leading-relaxed">
                Communicate directly on task cards. Tag teammates with @username, express feedback with emoji reactions, and track activity audit trails.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#20242C] text-gray-400 py-12 px-6 border-t border-[#2D333F] mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center space-x-2">
            <span className="font-extrabold text-white text-base">TASKLY</span>
            <span>— Plan together. Ship faster.</span>
          </div>
          <div>© {new Date().getFullYear()} TASKLY Inc. All rights reserved.</div>
        </div>
      </footer>
    </div>
  );
};
