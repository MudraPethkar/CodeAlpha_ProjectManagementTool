import React, { createContext, useContext, useEffect, useState, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { useAuth } from './AuthContext';
import { PresenceUser, Notification } from '../types';

interface SocketContextType {
  socket: Socket | null;
  onlineUsers: PresenceUser[];
  typingUsers: { [taskId: string]: string[] };
  joinProject: (projectId: string) => void;
  leaveProject: (projectId: string) => void;
  emitTyping: (projectId: string, taskId: string, isTyping: boolean) => void;
  latestNotification: Notification | null;
  clearLatestNotification: () => void;
}

const SocketContext = createContext<SocketContextType | undefined>(undefined);

export const SocketProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, token } = useAuth();
  const [socket, setSocket] = useState<Socket | null>(null);
  const [onlineUsers, setOnlineUsers] = useState<PresenceUser[]>([]);
  const [typingUsers, setTypingUsers] = useState<{ [taskId: string]: string[] }>({});
  const [latestNotification, setLatestNotification] = useState<Notification | null>(null);
  const currentProjectRef = useRef<string | null>(null);

  useEffect(() => {
    if (!token || !user) {
      if (socket) {
        socket.disconnect();
        setSocket(null);
      }
      return;
    }

    const newSocket = io({
      auth: { token },
      transports: ['websocket', 'polling'],
    });

    newSocket.on('connect', () => {
      // Rejoin project room if was active
      if (currentProjectRef.current) {
        newSocket.emit('project:join', {
          projectId: currentProjectRef.current,
          userInfo: { name: user.name, avatarUrl: user.avatarUrl },
        });
      }
    });

    newSocket.on('project:presence', (users: PresenceUser[]) => {
      setOnlineUsers(users);
    });

    newSocket.on('task:typing', ({ taskId, userName, isTyping }: { taskId: string; userName: string; isTyping: boolean }) => {
      setTypingUsers((prev) => {
        const current = prev[taskId] || [];
        if (isTyping) {
          if (!current.includes(userName)) {
            return { ...prev, [taskId]: [...current, userName] };
          }
          return prev;
        } else {
          return { ...prev, [taskId]: current.filter((u) => u !== userName) };
        }
      });
    });

    newSocket.on('notification:new', (notification: Notification) => {
      setLatestNotification(notification);
    });

    setSocket(newSocket);

    return () => {
      newSocket.disconnect();
    };
  }, [token, user?.id]);

  const joinProject = (projectId: string) => {
    currentProjectRef.current = projectId;
    if (socket && user) {
      socket.emit('project:join', {
        projectId,
        userInfo: { name: user.name, avatarUrl: user.avatarUrl },
      });
    }
  };

  const leaveProject = (projectId: string) => {
    if (currentProjectRef.current === projectId) {
      currentProjectRef.current = null;
    }
    if (socket) {
      socket.emit('project:leave', { projectId });
    }
    setOnlineUsers([]);
  };

  const emitTyping = (projectId: string, taskId: string, isTyping: boolean) => {
    if (socket && user) {
      socket.emit('task:typing', {
        projectId,
        taskId,
        userName: user.name,
        isTyping,
      });
    }
  };

  const clearLatestNotification = () => setLatestNotification(null);

  return (
    <SocketContext.Provider
      value={{
        socket,
        onlineUsers,
        typingUsers,
        joinProject,
        leaveProject,
        emitTyping,
        latestNotification,
        clearLatestNotification,
      }}
    >
      {children}
    </SocketContext.Provider>
  );
};

export const useSocket = () => {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error('useSocket must be used within a SocketProvider');
  }
  return context;
};
