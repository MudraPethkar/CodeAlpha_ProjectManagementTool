import { Response, NextFunction } from 'express';
import { AuthRequest } from '../types/index.js';
import { verifyAccessToken } from '../utils/jwt.js';
import prisma from '../prisma.js';

export const authenticate = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({ message: 'Authentication required. No token provided.' });
      return;
    }

    const token = authHeader.split(' ')[1];
    const payload = verifyAccessToken(token);

    if (!payload) {
      res.status(401).json({ message: 'Invalid or expired token.' });
      return;
    }

    req.user = payload;
    next();
  } catch (error) {
    res.status(401).json({ message: 'Authentication failed.' });
  }
};

export const requireProjectMember = (minRole: 'MEMBER' | 'ADMIN' | 'OWNER' = 'MEMBER') => {
  return async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
    try {
      const userId = req.user?.userId;
      const projectId = req.params.projectId || req.body.projectId;

      if (!userId) {
        res.status(401).json({ message: 'User not authenticated.' });
        return;
      }

      if (!projectId) {
        res.status(400).json({ message: 'Project ID is required.' });
        return;
      }

      const membership = await prisma.projectMember.findUnique({
        where: {
          projectId_userId: {
            projectId,
            userId,
          },
        },
      });

      if (!membership) {
        res.status(403).json({ message: 'Access denied: You are not a member of this project.' });
        return;
      }

      const roleHierarchy: Record<string, number> = {
        MEMBER: 1,
        ADMIN: 2,
        OWNER: 3,
      };

      if ((roleHierarchy[membership.role] || 0) < (roleHierarchy[minRole] || 1)) {
        res.status(403).json({ message: `Access denied: Requires ${minRole} role.` });
        return;
      }

      // Attach membership info to request
      (req as any).projectMembership = membership;
      next();
    } catch (error) {
      res.status(500).json({ message: 'Error checking project permissions.' });
    }
  };
};
