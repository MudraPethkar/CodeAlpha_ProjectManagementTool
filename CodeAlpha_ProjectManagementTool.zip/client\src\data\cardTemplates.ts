export interface CardOption {
  id: string;
  title: string;
  description: string;
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
  section: 'BACKLOG' | 'TODO' | 'IN_PROGRESS' | 'REVIEW' | 'DONE' | 'GENERAL';
  category: string;
  badge?: string;
  checklists?: string[];
}

export interface WorkflowBundle {
  id: string;
  name: string;
  description: string;
  icon: string;
  cards: {
    section: 'BACKLOG' | 'TODO' | 'IN_PROGRESS' | 'REVIEW' | 'DONE';
    title: string;
    description: string;
    priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
    category: string;
    checklists?: string[];
  }[];
}

// Curated options for every Kanban section
export const SECTION_CARD_OPTIONS: Record<string, CardOption[]> = {
  BACKLOG: [
    {
      id: 'b-1',
      title: 'OAuth 2.0 & Social Login (Google & GitHub)',
      description: 'Configure passport/JWT strategy for third-party OAuth providers with account linking and callback routes.',
      priority: 'HIGH',
      section: 'BACKLOG',
      category: 'Auth',
      badge: 'Feature',
      checklists: [
        'Register OAuth app in Google Cloud Console',
        'Configure GitHub Developer OAuth application',
        'Build callback route & JWT token exchange',
        'Link social profile with existing user email',
      ],
    },
    {
      id: 'b-2',
      title: 'Export Project Velocity Reports to CSV/PDF',
      description: 'Allow project managers to generate summary exports of completed cards, member contributions, and overdue items.',
      priority: 'MEDIUM',
      section: 'BACKLOG',
      category: 'Reporting',
      badge: 'Analytics',
      checklists: [
        'Implement CSV streaming export endpoint',
        'Design printable PDF template layout',
        'Test export performance on large boards',
      ],
    },
    {
      id: 'b-3',
      title: 'Database Query Optimization & Indexing Audit',
      description: 'Profile slow queries on board retrieval. Add composite database indexes on listId, position, and status.',
      priority: 'MEDIUM',
      section: 'BACKLOG',
      category: 'Performance',
      badge: 'Tech Debt',
      checklists: [
        'Profile slow Prisma queries in development',
        'Add compound database indexes in schema.prisma',
        'Benchmark retrieval latency before and after',
      ],
    },
    {
      id: 'b-4',
      title: 'Configurable Webhook Integrations (Slack/Discord)',
      description: 'Broadcast card creation, assignment, and status updates directly to external team messaging channels.',
      priority: 'LOW',
      section: 'BACKLOG',
      category: 'Integrations',
      badge: 'Integration',
      checklists: [
        'Add project webhook settings form',
        'Format Slack & Discord payload JSON',
        'Add retry queue for failed webhook deliveries',
      ],
    },
    {
      id: 'b-5',
      title: 'Document & Image File Attachment Preview Lightbox',
      description: 'Enable rich in-browser previews for images, PDFs, and code snippets attached to task cards.',
      priority: 'LOW',
      section: 'BACKLOG',
      category: 'UX',
      badge: 'Enhancement',
      checklists: [
        'Implement responsive image lightbox modal',
        'Integrate PDF viewer preview pane',
        'Support keyboard Esc / Arrow navigation in gallery',
      ],
    },
  ],

  TODO: [
    {
      id: 't-1',
      title: 'Build REST API for Bulk Card Status & Move Operations',
      description: 'Create batch endpoints allowing users to move multiple tasks or adjust priorities simultaneously in one call.',
      priority: 'HIGH',
      section: 'TODO',
      category: 'Backend',
      badge: 'API',
      checklists: [
        'Define Zod schema for batch task IDs',
        'Implement Prisma atomic transaction endpoint',
        'Wire frontend multi-select checkboxes',
      ],
    },
    {
      id: 't-2',
      title: 'Keyboard Accessibility & Quick Hotkeys (J/K/N/Space)',
      description: 'Add keyboard navigation: "N" for new card, "J/K" to cycle cards, "Space" to preview, and "Esc" to close.',
      priority: 'MEDIUM',
      section: 'TODO',
      category: 'Accessibility',
      badge: 'UX',
      checklists: [
        'Attach global keyboard listener hook',
        'Style accessible focus ring around active card',
        'Create hotkey help modal dialog (Shift + ?)',
      ],
    },
    {
      id: 't-3',
      title: 'Automated Vitest & Supertest Integration Tests',
      description: 'Ensure 100% test coverage for board state transformations, permissions, and task movement rules.',
      priority: 'HIGH',
      section: 'TODO',
      category: 'Testing',
      badge: 'Quality',
      checklists: [
        'Setup in-memory SQLite testing database',
        'Write tests for task reordering and list boundaries',
        'Verify unauthorized user permission rejections',
      ],
    },
    {
      id: 't-4',
      title: 'Enforce Zod Input Validation & Payload Sanitization',
      description: 'Validate all request bodies and sanitize HTML content in task descriptions and comments to prevent XSS.',
      priority: 'HIGH',
      section: 'TODO',
      category: 'Security',
      badge: 'Security',
      checklists: [
        'Audit all Express request handler schemas',
        'Sanitize rich Markdown inputs',
        'Add user-friendly error response messages',
      ],
    },
    {
      id: 't-5',
      title: 'Due Date Urgency Indicators & Overdue Badges',
      description: 'Show visual countdown badges on cards: yellow for due within 24h, red for overdue, green for completed on time.',
      priority: 'URGENT',
      section: 'TODO',
      category: 'Features',
      badge: 'Deadline',
      checklists: [
        'Add date comparison utility functions',
        'Style dynamic colored badges on task cards',
        'Trigger in-app notification when task is overdue',
      ],
    },
  ],

  IN_PROGRESS: [
    {
      id: 'p-1',
      title: 'Fluid Kanban Drag & Drop with Instant Server Sync',
      description: 'Ensure zero-latency visual card movement with optimistic state updates and graceful rollback on network error.',
      priority: 'URGENT',
      section: 'IN_PROGRESS',
      category: 'Frontend',
      badge: 'Core UI',
      checklists: [
        'Configure HTML5 drag-and-drop event handlers',
        'Implement position re-indexing logic',
        'Trigger confetti celebration when card enters Done',
      ],
    },
    {
      id: 'p-2',
      title: 'Real-time WebSocket Presence & Live Typing Indicators',
      description: 'Broadcast active teammates on the board and live typing alerts when someone is drafting a task comment.',
      priority: 'HIGH',
      section: 'IN_PROGRESS',
      category: 'Real-time',
      badge: 'Sockets',
      checklists: [
        'Socket.IO room join/leave heartbeat',
        'Typing debounce tracker (1.5s delay)',
        'Display live animated teammate status rings',
      ],
    },
    {
      id: 'p-3',
      title: 'Interactive Emoji Reaction Drawer & Mentions',
      description: 'Allow teammates to react with 👍, ❤️, 🚀, 🎉, and trigger popover teammate suggestions when typing "@".',
      priority: 'HIGH',
      section: 'IN_PROGRESS',
      category: 'Collaboration',
      badge: 'Social',
      checklists: [
        'Build reaction counter badge component',
        'Implement @mention autocomplete popover',
        'Dispatch in-app notification on mention',
      ],
    },
    {
      id: 'p-4',
      title: 'Mobile Responsive Touch Layout & Column Swiping',
      description: 'Optimize horizontal column scrolling, touch target sizing, and mobile gesture controls for iOS and Android.',
      priority: 'MEDIUM',
      section: 'IN_PROGRESS',
      category: 'Mobile',
      badge: 'Mobile',
      checklists: [
        'Ensure minimum 44px tap targets for buttons',
        'Enable horizontal swipe scroll snapping',
        'Test modal drawer responsiveness on mobile',
      ],
    },
  ],

  REVIEW: [
    {
      id: 'r-1',
      title: 'Security Audit: JWT Refresh Flow & RBAC Route Protection',
      description: 'Verify all project routes require proper membership check (OWNER/ADMIN/MEMBER) and tokens rotate safely.',
      priority: 'URGENT',
      section: 'REVIEW',
      category: 'Security',
      badge: 'Audit',
      checklists: [
        'Verify project membership check on all endpoints',
        'Audit refresh token expiration and revocation',
        'Check CORS origins and CSP security headers',
      ],
    },
    {
      id: 'r-2',
      title: 'Cross-Browser Verification (Chrome, Edge, Safari, Firefox)',
      description: 'Perform visual inspection across all major browsers, verifying layout parity and animation smoothness.',
      priority: 'HIGH',
      section: 'REVIEW',
      category: 'QA',
      badge: 'Testing',
      checklists: [
        'Test on Chromium engines (Chrome, Edge, Brave)',
        'Test on WebKit (macOS / iOS Safari)',
        'Check font rendering and border radiuses',
      ],
    },
    {
      id: 'r-3',
      title: 'Accessibility Audit: Contrast, ARIA Labels & Focus Traps',
      description: 'Ensure all interactive buttons, modals, and dropdowns comply with WCAG 2.1 AA accessibility guidelines.',
      priority: 'MEDIUM',
      section: 'REVIEW',
      category: 'Accessibility',
      badge: 'WCAG',
      checklists: [
        'Check color contrast ratios with Lighthouse',
        'Add aria-labels to all icon-only buttons',
        'Ensure modals correctly trap and restore focus',
      ],
    },
    {
      id: 'r-4',
      title: 'Production Bundle Analysis & Lazy-loading Routes',
      description: 'Analyze Vite vendor chunks, split dynamic imports for heavy modals, and compress svg/image assets.',
      priority: 'MEDIUM',
      section: 'REVIEW',
      category: 'Performance',
      badge: 'Build',
      checklists: [
        'Analyze bundle chunks via Vite build output',
        'Lazy load non-critical modal components',
        'Optimize Lucide icon tree-shaking imports',
      ],
    },
  ],

  DONE: [
    {
      id: 'd-1',
      title: 'Setup Full-Stack Monorepo Structure & TypeScript Strict Mode',
      description: 'Configured unified workspace with TypeScript, Tailwind CSS, Vite, and Node.js Express architecture.',
      priority: 'MEDIUM',
      section: 'DONE',
      category: 'Infrastructure',
      badge: 'DevOps',
      checklists: [
        'Root package.json concurrently runner configured',
        'Client tsconfig and Tailwind CSS setup',
        'Server tsx watch dev workflow verified',
      ],
    },
    {
      id: 'd-2',
      title: 'Design Relational Schema for Projects, Boards, Lists & Tasks',
      description: 'Implemented normalized SQLite schema with foreign key cascades and Prisma ORM client generator.',
      priority: 'HIGH',
      section: 'DONE',
      category: 'Database',
      badge: 'Prisma',
      checklists: [
        'Defined models in schema.prisma',
        'Pushed SQLite dev.db migration',
        'Created seed dataset with demo users and tasks',
      ],
    },
    {
      id: 'd-3',
      title: 'Implement JWT Authentication & Role-Based Permissions',
      description: 'Created secure bcrypt password hashing, access/refresh token generation, and role authorization middleware.',
      priority: 'HIGH',
      section: 'DONE',
      category: 'Security',
      badge: 'Auth',
      checklists: [
        'JWT signing and verification routines',
        'Owner/Admin/Member role gates applied',
        'Secure password hashing with bcryptjs',
      ],
    },
  ],
};

// Ready-to-go workflow bundles to populate an entire board with 1 click
export const WORKFLOW_BUNDLES: WorkflowBundle[] = [
  {
    id: 'fullstack',
    name: 'Full-Stack Software Sprint',
    description: 'Complete agile development workflow covering architecture, APIs, frontend UI, testing, and deployment.',
    icon: 'code',
    cards: [
      {
        section: 'BACKLOG',
        title: 'OAuth 2.0 & Social Login (Google & GitHub)',
        description: 'Configure passport/JWT strategy for third-party OAuth providers with account linking and callback routes.',
        priority: 'HIGH',
        category: 'Auth',
        checklists: ['Register OAuth app in Google Cloud', 'Configure GitHub Developer OAuth', 'Build callback route'],
      },
      {
        section: 'BACKLOG',
        title: 'Export Project Velocity Reports to CSV/PDF',
        description: 'Allow project managers to generate summary exports of completed cards and member contributions.',
        priority: 'MEDIUM',
        category: 'Reporting',
        checklists: ['Implement CSV streaming endpoint', 'Design PDF printable layout'],
      },
      {
        section: 'TODO',
        title: 'Build REST API for Bulk Card Status & Move Operations',
        description: 'Create batch endpoints allowing users to move multiple tasks or adjust priorities simultaneously.',
        priority: 'HIGH',
        category: 'Backend',
        checklists: ['Define Zod schema for batch IDs', 'Implement Prisma atomic transaction'],
      },
      {
        section: 'TODO',
        title: 'Keyboard Accessibility & Quick Hotkeys (J/K/N/Space)',
        description: 'Add keyboard navigation: "N" for new card, "J/K" to cycle cards, "Space" to preview.',
        priority: 'MEDIUM',
        category: 'UX',
        checklists: ['Attach global keyboard listener', 'Style accessible focus rings'],
      },
      {
        section: 'IN_PROGRESS',
        title: 'Fluid Kanban Drag & Drop with Instant Server Sync',
        description: 'Ensure zero-latency visual card movement with optimistic state updates and graceful rollback.',
        priority: 'URGENT',
        category: 'Frontend',
        checklists: ['Configure HTML5 drag handlers', 'Trigger celebratory confetti on Done'],
      },
      {
        section: 'IN_PROGRESS',
        title: 'Real-time WebSocket Presence & Live Typing Indicators',
        description: 'Broadcast active teammates on the board and live typing alerts when someone is drafting a comment.',
        priority: 'HIGH',
        category: 'Real-time',
        checklists: ['Socket.IO presence heartbeat', 'Typing debounce tracker'],
      },
      {
        section: 'REVIEW',
        title: 'Security Audit: JWT Refresh Flow & RBAC Route Protection',
        description: 'Verify all project routes require proper membership check (OWNER/ADMIN/MEMBER) and tokens rotate safely.',
        priority: 'URGENT',
        category: 'Security',
        checklists: ['Audit route membership middleware', 'Check CORS and CSP headers'],
      },
      {
        section: 'DONE',
        title: 'Setup Full-Stack Monorepo Structure & TypeScript Strict Mode',
        description: 'Configured unified workspace with TypeScript, Tailwind CSS, Vite, and Node.js Express architecture.',
        priority: 'MEDIUM',
        category: 'DevOps',
        checklists: ['Concurrently dev runner', 'Vite & Tailwind CSS configured', 'Prisma setup'],
      },
    ],
  },
  {
    id: 'product-launch',
    name: 'Product Launch & Marketing Campaign',
    description: 'End-to-end launch plan spanning product positioning, landing page assets, QA, and announcement rollout.',
    icon: 'rocket',
    cards: [
      {
        section: 'BACKLOG',
        title: 'Compile Customer Testimonials & Case Study Quotes',
        description: 'Interview beta users and obtain approval to display quotes and company logos on landing page.',
        priority: 'MEDIUM',
        category: 'Marketing',
        checklists: ['Draft customer survey', 'Collect high-res company logos', 'Sign media release'],
      },
      {
        section: 'TODO',
        title: 'Design Hero Banner & Product Feature Graphics',
        description: 'Create high-resolution product mockups, animated GIFs, and social share preview cards.',
        priority: 'HIGH',
        category: 'Design',
        checklists: ['Hero banner (1200x630)', 'Feature screenshot carousels', 'Twitter/LinkedIn card previews'],
      },
      {
        section: 'IN_PROGRESS',
        title: 'Draft Product Hunt & Hacker News Launch Brief',
        description: 'Prepare maker comment, initial demo video walkthrough, and discount code for early adopters.',
        priority: 'URGENT',
        category: 'Growth',
        checklists: ['Record 90-second video demo', 'Write first maker comment', 'Coordinate launch team upvotes'],
      },
      {
        section: 'REVIEW',
        title: 'Proofread Launch Email Sequence & Announcement Blog',
        description: 'Review copy, test all UTM tracking links, and verify mobile rendering on major email clients.',
        priority: 'HIGH',
        category: 'Copywriting',
        checklists: ['Test UTM link parameters', 'Check dark mode email rendering', 'Verify mobile responsiveness'],
      },
      {
        section: 'DONE',
        title: 'Set up Production Domain, SSL & Analytics Tracking',
        description: 'DNS configuration verified, SSL cert active, and privacy-friendly analytics configured.',
        priority: 'HIGH',
        category: 'Infrastructure',
        checklists: ['Point DNS records to Vercel/Cloudflare', 'Verify HTTPS certificate', 'Test event tracking'],
      },
    ],
  },
  {
    id: 'bug-bash',
    name: 'Bug Bash & Quality Hardening',
    description: 'Structured sprint focused on edge cases, responsiveness, accessibility fixes, and performance tuning.',
    icon: 'shield',
    cards: [
      {
        section: 'BACKLOG',
        title: 'Investigate intermittent WebSocket disconnects on iOS',
        description: 'Audit mobile Safari background tab behavior and implement ping-pong reconnection backoff.',
        priority: 'MEDIUM',
        category: 'Bug',
        checklists: ['Reproduce on iOS simulator', 'Add reconnection retry limit', 'Test background tab sleep'],
      },
      {
        section: 'TODO',
        title: 'Fix text overflow on long task titles in mobile view',
        description: 'Ensure titles gracefully wrap or truncate with tooltip on narrow screens without breaking column layout.',
        priority: 'HIGH',
        category: 'Bug',
        checklists: ['Add CSS line-clamp-2', 'Add title tooltip on hover', 'Verify on 360px viewport'],
      },
      {
        section: 'IN_PROGRESS',
        title: 'Resolve dark mode contrast issue on priority badges',
        description: 'Urgent red and amber badges should have sufficient contrast when displayed against dark column surfaces.',
        priority: 'HIGH',
        category: 'UI Bug',
        checklists: ['Update HSL lightness variables', 'Run Axe accessibility test', 'Verify in dark mode'],
      },
      {
        section: 'REVIEW',
        title: 'Verify memory leak fix in comment subscription listeners',
        description: 'Ensure Socket.IO listeners are reliably removed on component unmount to prevent memory leaks.',
        priority: 'URGENT',
        category: 'Quality',
        checklists: ['Profile heap snapshot in Chrome DevTools', 'Confirm listener count stays constant'],
      },
      {
        section: 'DONE',
        title: 'Patch CORS vulnerability on public invitation routes',
        description: 'Restricted cross-origin access strictly to verified frontend origins with credential cookies.',
        priority: 'HIGH',
        category: 'Security',
        checklists: ['Configure CORS whitelist', 'Test unauthorized origin rejection'],
      },
    ],
  },
];

// Helper to find matching options for any column name
export const getOptionsForColumnName = (columnName: string): CardOption[] => {
  const norm = columnName.trim().toUpperCase().replace(/[\s-_]+/g, '');
  
  if (norm.includes('BACKLOG') || norm.includes('IDEAS') || norm.includes('FUTURE')) {
    return SECTION_CARD_OPTIONS.BACKLOG;
  }
  if (norm.includes('TODO') || norm.includes('PLANNED') || norm.includes('READY')) {
    return SECTION_CARD_OPTIONS.TODO;
  }
  if (norm.includes('PROGRESS') || norm.includes('DOING') || norm.includes('DEV') || norm.includes('ACTIVE')) {
    return SECTION_CARD_OPTIONS.IN_PROGRESS;
  }
  if (norm.includes('REVIEW') || norm.includes('TEST') || norm.includes('QA') || norm.includes('VERIFY')) {
    return SECTION_CARD_OPTIONS.REVIEW;
  }
  if (norm.includes('DONE') || norm.includes('COMPLETE') || norm.includes('SHIPPED') || norm.includes('CLOSED')) {
    return SECTION_CARD_OPTIONS.DONE;
  }

  // Fallback: return a curated mix from backlog and todo
  return [
    ...SECTION_CARD_OPTIONS.TODO.slice(0, 3),
    ...SECTION_CARD_OPTIONS.BACKLOG.slice(0, 2),
  ];
};
