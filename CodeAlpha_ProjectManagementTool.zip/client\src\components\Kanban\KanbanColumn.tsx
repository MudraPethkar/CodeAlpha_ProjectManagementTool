import React, { useState } from 'react';
import {
  Plus,
  MoreVertical,
  Trash2,
  Edit2,
  Check,
  X,
  Sparkles,
  Zap,
  ListPlus,
  CheckCircle2,
  ChevronDown,
} from 'lucide-react';
import { List, Task } from '../../types';
import { TaskCard } from './TaskCard';
import { CardOption, getOptionsForColumnName } from '../../data/cardTemplates';

interface KanbanColumnProps {
  list: List;
  onSelectTask: (task: Task) => void;
  onDragStart: (e: React.DragEvent, task: Task) => void;
  onDropTask: (listId: string) => void;
  onCreateTask: (
    listId: string,
    taskData:
      | { title: string; description?: string; priority?: string; checklists?: string[] }
      | string
  ) => Promise<void>;
  onRenameList: (listId: string, newName: string) => Promise<void>;
  onDeleteList: (listId: string) => Promise<void>;
}

export const KanbanColumn: React.FC<KanbanColumnProps> = ({
  list,
  onSelectTask,
  onDragStart,
  onDropTask,
  onCreateTask,
  onRenameList,
  onDeleteList,
}) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [isAddingTask, setIsAddingTask] = useState(false);
  const [addMode, setAddMode] = useState<'preset' | 'custom'>('preset');
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [isEditingName, setIsEditingName] = useState(false);
  const [listName, setListName] = useState(list.name);
  const [showMenu, setShowMenu] = useState(false);
  const [showOptionsPicker, setShowOptionsPicker] = useState(false);
  const [isSubmittingPreset, setIsSubmittingPreset] = useState(false);

  const columnOptions = getOptionsForColumnName(list.name);

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;
    await onCreateTask(list.id, { title: newTaskTitle.trim() });
    setNewTaskTitle('');
    setIsAddingTask(false);
  };

  const handleSelectOption = async (option: CardOption) => {
    setIsSubmittingPreset(true);
    try {
      await onCreateTask(list.id, {
        title: option.title,
        description: option.description,
        priority: option.priority,
        checklists: option.checklists,
      });
      setShowOptionsPicker(false);
      setIsAddingTask(false);
    } catch (err) {
      console.error('Failed to create card from option:', err);
    } finally {
      setIsSubmittingPreset(false);
    }
  };

  const handleRename = async () => {
    if (listName.trim() && listName !== list.name) {
      await onRenameList(list.id, listName.trim());
    }
    setIsEditingName(false);
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'URGENT':
        return <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded-md bg-rose-100 text-rose-700">Urgent</span>;
      case 'HIGH':
        return <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded-md bg-amber-100 text-amber-700">High</span>;
      case 'MEDIUM':
        return <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded-md bg-sky-100 text-sky-700">Med</span>;
      default:
        return <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-gray-200 text-gray-700">Low</span>;
    }
  };

  return (
    <div
      onDragOver={(e) => {
        e.preventDefault();
        setIsDragOver(true);
      }}
      onDragLeave={() => setIsDragOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setIsDragOver(false);
        onDropTask(list.id);
      }}
      className={`w-72 sm:w-80 flex-shrink-0 flex flex-col bg-[#F3F4F6] rounded-2xl p-3 border transition-all duration-200 relative ${
        isDragOver
          ? 'border-[#A3E635] bg-[#D9F99D]/20 shadow-md ring-2 ring-[#A3E635]/40'
          : 'border-transparent hover:border-[#E5E7EB]'
      }`}
    >
      {/* Column Header */}
      <div className="flex items-center justify-between px-2 py-1.5 mb-2">
        <div className="flex items-center space-x-2 flex-1 mr-2">
          {isEditingName ? (
            <div className="flex items-center space-x-1 w-full">
              <input
                type="text"
                value={listName}
                onChange={(e) => setListName(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleRename()}
                className="w-full text-xs font-bold px-2 py-1 bg-white border border-[#A3E635] rounded-md focus:outline-none"
                autoFocus
              />
              <button onClick={handleRename} className="p-1 hover:text-green-600">
                <Check className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => {
                  setListName(list.name);
                  setIsEditingName(false);
                }}
                className="p-1 hover:text-red-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <div className="flex items-center space-x-2">
              <h3 className="font-bold text-xs uppercase tracking-wider text-[#20242C]">
                {list.name}
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-[#E5E7EB] text-[#20242C]">
                {list.tasks.length}
              </span>
            </div>
          )}
        </div>

        {/* Actions: Card Options Menu, Add Card, Column Menu */}
        <div className="flex items-center space-x-1 relative">
          {/* Quick Preset Options Button */}
          <button
            onClick={() => setShowOptionsPicker(!showOptionsPicker)}
            className={`p-1.5 rounded-lg text-xs font-bold flex items-center gap-1 transition-all ${
              showOptionsPicker
                ? 'bg-[#A3E635] text-[#20242C] shadow-xs'
                : 'text-gray-500 hover:text-[#20242C] hover:bg-white'
            }`}
            title="Card Options & Templates for this column"
          >
            <Sparkles className="w-3.5 h-3.5 text-lime-600" />
            <span className="text-[10px] hidden sm:inline">Options</span>
          </button>

          {/* Quick Add Custom Button */}
          <button
            onClick={() => {
              setIsAddingTask(true);
              setAddMode('custom');
            }}
            className="p-1 text-gray-500 hover:text-[#20242C] hover:bg-white rounded-md transition-colors"
            title="Type custom card"
          >
            <Plus className="w-4 h-4" />
          </button>

          {/* Column Settings Menu */}
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="p-1 text-gray-500 hover:text-[#20242C] hover:bg-white rounded-md transition-colors"
          >
            <MoreVertical className="w-4 h-4" />
          </button>

          {/* Settings Dropdown */}
          {showMenu && (
            <div
              className="absolute right-0 top-7 w-36 bg-white border border-[#E5E7EB] rounded-xl shadow-lg py-1 z-30 text-xs"
              onClick={() => setShowMenu(false)}
            >
              <button
                onClick={() => setIsEditingName(true)}
                className="w-full px-3 py-1.5 text-left text-gray-700 hover:bg-gray-50 flex items-center space-x-2"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Rename List</span>
              </button>
              <button
                onClick={() => onDeleteList(list.id)}
                className="w-full px-3 py-1.5 text-left text-rose-600 hover:bg-rose-50 flex items-center space-x-2"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete List</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Popover Options Drawer for this Column */}
      {showOptionsPicker && (
        <div className="mb-3 bg-white rounded-xl p-3 border border-[#A3E635] shadow-lg animate-in fade-in zoom-in-95 duration-150 z-20">
          <div className="flex items-center justify-between pb-2 border-b border-gray-100 mb-2">
            <div className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              <span className="text-xs font-extrabold text-[#20242C]">
                Ready Options for {list.name}
              </span>
            </div>
            <button
              onClick={() => setShowOptionsPicker(false)}
              className="text-gray-400 hover:text-gray-600 p-0.5 rounded"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <p className="text-[11px] text-gray-500 mb-2.5">
            Click any ready card to add it to this column without typing:
          </p>

          <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
            {columnOptions.map((opt) => (
              <button
                key={opt.id}
                onClick={() => handleSelectOption(opt)}
                disabled={isSubmittingPreset}
                className="w-full text-left p-2 rounded-lg bg-gray-50 hover:bg-[#A3E635]/15 border border-transparent hover:border-[#A3E635]/50 transition-all group flex flex-col gap-1"
              >
                <div className="flex items-start justify-between gap-1.5">
                  <span className="text-xs font-bold text-[#20242C] group-hover:text-black line-clamp-1">
                    {opt.title}
                  </span>
                  {getPriorityBadge(opt.priority)}
                </div>
                <div className="flex items-center justify-between text-[10px] text-gray-500">
                  <span className="font-semibold text-gray-600">{opt.category}</span>
                  {opt.checklists && (
                    <span className="flex items-center gap-1 font-medium text-gray-400">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      {opt.checklists.length} tasks
                    </span>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Task Cards Container */}
      <div className="flex-1 overflow-y-auto space-y-2.5 pr-0.5 min-h-[120px]">
        {list.tasks.map((task) => (
          <TaskCard
            key={task.id}
            task={task}
            onSelectTask={onSelectTask}
            onDragStart={onDragStart}
          />
        ))}

        {/* Empty State with Ready-to-Click Card Options */}
        {list.tasks.length === 0 && !isAddingTask && (
          <div className="bg-white/70 border-2 border-dashed border-gray-200 rounded-2xl p-3.5 text-center flex flex-col items-center justify-center space-y-2.5">
            <div className="flex items-center gap-1.5 text-gray-400 text-xs font-semibold">
              <span>Drop cards here, or pick an option:</span>
            </div>

            {/* Quick 1-Click Option Buttons */}
            <div className="w-full space-y-1.5">
              {columnOptions.slice(0, 3).map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => handleSelectOption(opt)}
                  disabled={isSubmittingPreset}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-white hover:bg-[#A3E635]/20 border border-gray-200 hover:border-[#A3E635] text-left transition-all flex items-center justify-between shadow-2xs group"
                >
                  <div className="flex items-center space-x-1.5 truncate mr-1">
                    <Plus className="w-3 h-3 text-[#A3E635] group-hover:scale-125 transition-transform shrink-0" />
                    <span className="text-[11px] font-bold text-gray-700 group-hover:text-[#20242C] truncate">
                      {opt.title}
                    </span>
                  </div>
                  {getPriorityBadge(opt.priority)}
                </button>
              ))}
            </div>

            <button
              onClick={() => setShowOptionsPicker(true)}
              className="text-[11px] font-bold text-lime-700 hover:text-lime-800 hover:underline flex items-center gap-1 pt-1"
            >
              <Sparkles className="w-3 h-3" />
              <span>Browse all {columnOptions.length} {list.name} options</span>
            </button>
          </div>
        )}

        {/* Expandable Add Card Section */}
        {isAddingTask && (
          <div className="bg-white rounded-xl p-3 border border-[#A3E635] shadow-sm space-y-3">
            {/* Mode Switcher Tabs */}
            <div className="flex p-0.5 bg-gray-100 rounded-lg text-[11px] font-bold">
              <button
                type="button"
                onClick={() => setAddMode('preset')}
                className={`flex-1 py-1 rounded-md transition-all flex items-center justify-center gap-1 ${
                  addMode === 'preset'
                    ? 'bg-white text-[#20242C] shadow-2xs'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                <Sparkles className="w-3 h-3 text-lime-600" />
                <span>Ready Options</span>
              </button>
              <button
                type="button"
                onClick={() => setAddMode('custom')}
                className={`flex-1 py-1 rounded-md transition-all flex items-center justify-center gap-1 ${
                  addMode === 'custom'
                    ? 'bg-white text-[#20242C] shadow-2xs'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                <Edit2 className="w-3 h-3 text-gray-500" />
                <span>Type Custom</span>
              </button>
            </div>

            {/* Ready Options List */}
            {addMode === 'preset' ? (
              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider">
                  Select a card to add immediately:
                </p>
                {columnOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => handleSelectOption(opt)}
                    disabled={isSubmittingPreset}
                    className="w-full text-left p-2 rounded-lg bg-gray-50 hover:bg-[#A3E635]/20 border border-gray-100 hover:border-[#A3E635] transition-all flex items-center justify-between group"
                  >
                    <div className="truncate mr-2">
                      <div className="text-xs font-bold text-[#20242C] truncate">
                        {opt.title}
                      </div>
                      <div className="text-[10px] text-gray-500">{opt.category}</div>
                    </div>
                    {getPriorityBadge(opt.priority)}
                  </button>
                ))}
                <div className="pt-1 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setIsAddingTask(false)}
                    className="text-gray-500 hover:text-gray-700 text-xs px-2 py-1"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              /* Custom Input Form */
              <form onSubmit={handleCreateTask} className="space-y-2.5">
                <textarea
                  value={newTaskTitle}
                  onChange={(e) => setNewTaskTitle(e.target.value)}
                  placeholder="What needs to be done?"
                  className="w-full text-xs text-[#20242C] placeholder-gray-400 resize-none focus:outline-none"
                  rows={2}
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleCreateTask(e);
                    }
                  }}
                />
                <div className="flex items-center justify-between pt-1">
                  <div className="flex space-x-1.5">
                    <button
                      type="submit"
                      disabled={!newTaskTitle.trim()}
                      className="bg-[#A3E635] hover:bg-[#8dd321] text-[#20242C] font-bold text-xs px-3 py-1.5 rounded-lg disabled:opacity-50 transition-colors"
                    >
                      Add Card
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setIsAddingTask(false);
                        setNewTaskTitle('');
                      }}
                      className="text-gray-500 hover:text-gray-700 text-xs px-2 py-1.5"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </form>
            )}
          </div>
        )}
      </div>

      {/* Quick Add Buttons at bottom of column */}
      {!isAddingTask && (
        <div className="mt-2.5 flex items-center space-x-1.5">
          <button
            onClick={() => {
              setIsAddingTask(true);
              setAddMode('preset');
            }}
            className="flex-1 py-2 rounded-xl text-xs font-bold text-gray-600 hover:text-[#20242C] bg-white/60 hover:bg-white border border-gray-200 hover:border-[#A3E635] flex items-center justify-center space-x-1.5 transition-all shadow-2xs"
            title="Choose from ready card options"
          >
            <Sparkles className="w-3.5 h-3.5 text-lime-600" />
            <span>Card Options</span>
          </button>

          <button
            onClick={() => {
              setIsAddingTask(true);
              setAddMode('custom');
            }}
            className="p-2 rounded-xl text-gray-500 hover:text-[#20242C] bg-white/60 hover:bg-white border border-gray-200 hover:border-gray-300 transition-all shadow-2xs"
            title="Type custom card manually"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};
