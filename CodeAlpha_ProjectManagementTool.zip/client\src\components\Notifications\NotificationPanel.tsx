import React, { useState } from 'react';
import {
  Bell,
  CheckCheck,
  CheckCircle2,
  Clock,
  MessageSquare,
  UserPlus,
  AlertTriangle,
  X,
} from 'lucide-react';
import { Notification } from '../../types';
import api from '../../services/api';

interface NotificationPanelProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: Notification[];
  onRefreshNotifications: () => void;
  onSelectResource: (resourceType: string, resourceId: string) => void;
}

export const NotificationPanel: React.FC<NotificationPanelProps> = ({
  isOpen,
  onClose,
  notifications,
  onRefreshNotifications,
  onSelectResource,
}) => {
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  if (!isOpen) return null;

  const handleMarkAllRead = async () => {
    try {
      await api.markAllNotificationsRead();
      onRefreshNotifications();
    } catch (error) {
      console.error('Failed to mark all as read:', error);
    }
  };

  const handleNotificationClick = async (notif: Notification) => {
    if (!notif.read) {
      try {
        await api.markNotificationRead(notif.id);
        onRefreshNotifications();
      } catch (err) {
        console.error('Failed to mark read:', err);
      }
    }
    onSelectResource(notif.resourceType, notif.resourceId);
    onClose();
  };

  const filtered = notifications.filter((n) => (filter === 'unread' ? !n.read : true));

  const getIcon = (type: string) => {
    switch (type) {
      case 'TASK_ASSIGNED':
        return <UserPlus className="w-4 h-4 text-[#A3E635]" />;
      case 'COMMENT_MENTION':
        return <MessageSquare className="w-4 h-4 text-blue-500" />;
      case 'STATUS_CHANGED':
        return <CheckCircle2 className="w-4 h-4 text-emerald-500" />;
      case 'TASK_DUE_SOON':
      case 'TASK_OVERDUE':
        return <AlertTriangle className="w-4 h-4 text-rose-500" />;
      default:
        return <Bell className="w-4 h-4 text-gray-500" />;
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-hidden bg-black/40 backdrop-blur-xs flex justify-end"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm sm:max-w-md bg-white h-full shadow-2xl flex flex-col border-l border-gray-200 animate-in slide-in-from-right duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 bg-[#20242C] text-white flex items-center justify-between border-b border-[#2D333F]">
          <div className="flex items-center space-x-2">
            <Bell className="w-5 h-5 text-[#A3E635]" />
            <h3 className="font-extrabold text-base tracking-tight">Notifications</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-gray-400 hover:text-white hover:bg-[#2D333F] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Controls & Mark all read */}
        <div className="px-4 py-2.5 bg-gray-50 border-b border-gray-200 flex items-center justify-between text-xs">
          <div className="flex space-x-2">
            <button
              onClick={() => setFilter('all')}
              className={`px-2.5 py-1 rounded-lg font-bold transition-colors ${
                filter === 'all'
                  ? 'bg-[#20242C] text-white'
                  : 'text-gray-500 hover:text-gray-800'
              }`}
            >
              All ({notifications.length})
            </button>
            <button
              onClick={() => setFilter('unread')}
              className={`px-2.5 py-1 rounded-lg font-bold transition-colors ${
                filter === 'unread'
                  ? 'bg-[#20242C] text-white'
                  : 'text-gray-500 hover:text-gray-800'
              }`}
            >
              Unread ({notifications.filter((n) => !n.read).length})
            </button>
          </div>

          <button
            onClick={handleMarkAllRead}
            className="flex items-center gap-1 font-semibold text-gray-600 hover:text-[#20242C] transition-colors"
          >
            <CheckCheck className="w-3.5 h-3.5 text-[#A3E635]" />
            <span>Mark all read</span>
          </button>
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto divide-y divide-gray-100">
          {filtered.map((n) => (
            <div
              key={n.id}
              onClick={() => handleNotificationClick(n)}
              className={`p-4 flex items-start space-x-3 cursor-pointer hover:bg-gray-50 transition-colors ${
                !n.read ? 'bg-[#D9F99D]/15' : ''
              }`}
            >
              <div className="p-2 rounded-xl bg-gray-100 flex-shrink-0 mt-0.5">
                {getIcon(n.type)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-0.5">
                  <h4 className="text-xs font-bold text-[#20242C] truncate">{n.title}</h4>
                  <span className="text-[10px] text-gray-400 font-medium">
                    {new Date(n.createdAt).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
                <p className="text-xs text-gray-600 leading-relaxed">{n.body}</p>
              </div>
              {!n.read && (
                <span className="w-2 h-2 rounded-full bg-[#A3E635] flex-shrink-0 self-center" />
              )}
            </div>
          ))}

          {filtered.length === 0 && (
            <div className="py-16 text-center text-gray-400 text-xs flex flex-col items-center">
              <Bell className="w-8 h-8 stroke-1 mb-2 text-gray-300" />
              <p className="font-semibold text-gray-600">All caught up!</p>
              <p className="text-gray-400 mt-1">No {filter === 'unread' ? 'unread ' : ''}notifications.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
