import React, { useState, useEffect } from 'react';
import {
  FolderKanban,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Plus,
  ArrowRight,
  TrendingUp,
  Activity as ActivityIcon,
  Calendar,
} from 'lucide-react';
import { Project, Task, Activity } from '../../types';
import { useAuth } from '../../context/AuthContext';
import api from '../../services/api';

interface DashboardViewProps {
  projects: Project[];
  onSelectProject: (projectId: string) => void;
  onOpenCreateProject: () => void;
  onOpenCreateTask: () => void;
  onSelectTask: (task: Task) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  projects,
  onSelectProject,
  onOpenCreateProject,
  onOpenCreateTask,
  onSelectTask,
}) => {
  const { user } = useAuth();
  const [assignedTasks, setAssignedTasks] = useState<Task[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        const actRes = await api.getActivities();
        setActivities(actRes);

        // Fetch assigned tasks across all boards
        const allAssigned: Task[] = [];
        for (const p of projects) {
          try {
            const board = await api.getBoard(p.id);
            board.lists.forEach((list) => {
              list.tasks.forEach((task) => {
                const isAssigned =
                  (task.assignees && task.assignees.some((a) => a.userId === user?.id)) ||
                  task.createdById === user?.id;
                if (isAssigned && list.name.toLowerCase() !== 'done') {
                  allAssigned.push({ ...task, list: { id: list.id, name: list.name } });
                }
              });
            });
          } catch (e) {
            // ignore individual board load errors
          }
        }
        setAssignedTasks(allAssigned);
      } catch (err) {
        console.error('Failed to load dashboard data:', err);
      } finally {
        setIsLoading(false);
      }
    };

    if (projects.length > 0) {
      loadDashboardData();
    } else {
      setIsLoading(false);
    }
  }, [projects, user?.id]);

  // Metric Computations
  const totalProjects = projects.length;
  const inProgressTasks = assignedTasks.filter(
    (t) => t.list?.name.toLowerCase() === 'in progress'
  ).length;

  const overdueTasks = assignedTasks.filter((t) => {
    if (!t.dueDate) return false;
    return new Date(t.dueDate).getTime() < Date.now();
  }).length;

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8 space-y-8 bg-[#F9FAFB]">
      {/* Welcome Hero Banner */}
      <div className="bg-[#20242C] rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden shadow-xl border border-[#2D333F]">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-radial from-[#A3E635]/15 via-transparent to-transparent pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-wider text-[#A3E635] mb-2">
              <span className="w-2 h-2 rounded-full bg-[#A3E635] animate-ping" />
              <span>Workspace Overview</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-2">
              Welcome back, {user?.name?.split(' ')[0]} 👋
            </h1>
            <p className="text-sm text-gray-400 max-w-xl leading-relaxed">
              Plan together. Ship faster. You have {assignedTasks.length} active tasks assigned across {totalProjects} team projects.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={onOpenCreateTask}
              className="bg-[#A3E635] hover:bg-[#8dd321] text-[#20242C] font-extrabold text-xs px-4 py-3 rounded-xl flex items-center space-x-2 shadow-lg shadow-[#A3E635]/20 transition-all duration-150 active:scale-95"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>New Task</span>
            </button>
            <button
              onClick={onOpenCreateProject}
              className="bg-[#2D333F] hover:bg-[#3A4150] text-white font-bold text-xs px-4 py-3 rounded-xl border border-gray-700 flex items-center space-x-2 transition-all active:scale-95"
            >
              <FolderKanban className="w-4 h-4 text-[#A3E635]" />
              <span>New Project</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        <div className="bg-white rounded-2xl p-5 border border-[#E5E7EB] shadow-xs">
          <div className="flex items-center justify-between text-gray-400 mb-3">
            <span className="text-xs font-bold uppercase tracking-wider">Active Projects</span>
            <FolderKanban className="w-5 h-5 text-[#A3E635]" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-[#20242C]">{totalProjects}</div>
          <span className="text-[11px] text-gray-400 font-medium mt-1 inline-block">
            Across your workspace
          </span>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-[#E5E7EB] shadow-xs">
          <div className="flex items-center justify-between text-gray-400 mb-3">
            <span className="text-xs font-bold uppercase tracking-wider">Assigned to Me</span>
            <CheckCircle2 className="w-5 h-5 text-blue-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-[#20242C]">
            {assignedTasks.length}
          </div>
          <span className="text-[11px] text-gray-400 font-medium mt-1 inline-block">
            Pending sprint tasks
          </span>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-[#E5E7EB] shadow-xs">
          <div className="flex items-center justify-between text-gray-400 mb-3">
            <span className="text-xs font-bold uppercase tracking-wider">In Progress</span>
            <Clock className="w-5 h-5 text-amber-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-[#20242C]">
            {inProgressTasks}
          </div>
          <span className="text-[11px] text-gray-400 font-medium mt-1 inline-block">
            Actively being built
          </span>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-[#E5E7EB] shadow-xs">
          <div className="flex items-center justify-between text-gray-400 mb-3">
            <span className="text-xs font-bold uppercase tracking-wider">Overdue</span>
            <AlertTriangle className={`w-5 h-5 ${overdueTasks > 0 ? 'text-rose-500' : 'text-gray-400'}`} />
          </div>
          <div className={`text-2xl sm:text-3xl font-extrabold ${overdueTasks > 0 ? 'text-rose-600' : 'text-[#20242C]'}`}>
            {overdueTasks}
          </div>
          <span className="text-[11px] text-gray-400 font-medium mt-1 inline-block">
            Requires immediate attention
          </span>
        </div>
      </div>

      {/* Main Content Split: Recent Projects & Assigned Tasks */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column (2 cols): Recent Projects Grid */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-lg text-[#20242C] tracking-tight">Recent Projects</h3>
            <span className="text-xs text-gray-400 font-medium">{projects.length} available</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {projects.map((project) => (
              <div
                key={project.id}
                onClick={() => onSelectProject(project.id)}
                className="bg-white rounded-2xl p-5 border border-[#E5E7EB] hover:border-[#A3E635] shadow-xs hover:shadow-md transition-all duration-200 cursor-pointer group flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span
                      className="w-3.5 h-3.5 rounded-full"
                      style={{ backgroundColor: project.color }}
                    />
                    <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">
                      {project.currentUserRole || 'Member'}
                    </span>
                  </div>

                  <h4 className="font-bold text-base text-[#20242C] group-hover:text-[#20242C] mb-1.5 transition-colors">
                    {project.name}
                  </h4>
                  <p className="text-xs text-gray-500 line-clamp-2 leading-relaxed mb-4">
                    {project.description || 'No description provided.'}
                  </p>
                </div>

                <div>
                  {/* Progress Bar */}
                  <div className="mb-3">
                    <div className="flex items-center justify-between text-[11px] text-gray-500 font-semibold mb-1">
                      <span>Progress</span>
                      <span>{project.progressPercent || 0}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-[#A3E635] rounded-full transition-all duration-300"
                        style={{ width: `${project.progressPercent || 0}%` }}
                      />
                    </div>
                  </div>

                  {/* Members & Action */}
                  <div className="flex items-center justify-between pt-2 border-t border-gray-100 text-xs">
                    <div className="flex items-center -space-x-1.5">
                      {project.members?.slice(0, 4).map((m) => (
                        <img
                          key={m.id}
                          src={m.user?.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${m.user?.name}`}
                          alt={m.user?.name}
                          title={m.user?.name}
                          className="w-6 h-6 rounded-full object-cover border-2 border-white"
                        />
                      ))}
                    </div>

                    <span className="text-xs font-bold text-gray-400 group-hover:text-[#20242C] flex items-center gap-1 transition-colors">
                      Open Board
                      <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Assigned Tasks Stream */}
          <div className="pt-4">
            <h3 className="font-extrabold text-lg text-[#20242C] tracking-tight mb-4">
              My Assigned Tasks ({assignedTasks.length})
            </h3>

            <div className="bg-white rounded-2xl border border-[#E5E7EB] divide-y divide-gray-100 overflow-hidden shadow-xs">
              {assignedTasks.map((t) => (
                <div
                  key={t.id}
                  onClick={() => onSelectTask(t)}
                  className="p-4 hover:bg-gray-50 cursor-pointer flex items-center justify-between transition-colors group"
                >
                  <div className="flex items-center space-x-3 truncate">
                    <CheckCircle2 className="w-4 h-4 text-gray-300 group-hover:text-[#A3E635] transition-colors flex-shrink-0" />
                    <div className="truncate">
                      <h5 className="text-xs font-bold text-[#20242C] truncate">{t.title}</h5>
                      <span className="text-[11px] text-gray-400">Status: {t.list?.name}</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 flex-shrink-0">
                    {t.dueDate && (
                      <span className="text-[11px] font-medium text-gray-500 bg-gray-100 px-2 py-0.5 rounded">
                        {new Date(t.dueDate).toLocaleDateString([], {
                          month: 'short',
                          day: 'numeric',
                        })}
                      </span>
                    )}
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                        t.priority === 'URGENT'
                          ? 'bg-rose-100 text-rose-700'
                          : t.priority === 'HIGH'
                          ? 'bg-amber-100 text-amber-700'
                          : 'bg-gray-100 text-gray-700'
                      }`}
                    >
                      {t.priority}
                    </span>
                  </div>
                </div>
              ))}

              {assignedTasks.length === 0 && (
                <div className="p-8 text-center text-xs text-gray-400">
                  No pending tasks assigned to you right now! 🎉
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column (1 col): Live Activity Feed */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-lg text-[#20242C] tracking-tight flex items-center gap-2">
              <ActivityIcon className="w-4 h-4 text-[#A3E635]" />
              Team Activity
            </h3>
          </div>

          <div className="bg-white rounded-2xl border border-[#E5E7EB] p-4 divide-y divide-gray-100 shadow-xs max-h-[600px] overflow-y-auto">
            {activities.map((act) => (
              <div key={act.id} className="py-3 flex items-start space-x-3">
                <img
                  src={act.actor?.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${act.actor?.name}`}
                  alt={act.actor?.name}
                  className="w-7 h-7 rounded-full object-cover border border-gray-200 mt-0.5"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-[#20242C] leading-snug">
                    <span className="font-bold">{act.actor?.name}</span>{' '}
                    <span className="text-gray-600">
                      {act.action === 'task_created' && 'created task'}
                      {act.action === 'task_moved' && 'moved task'}
                      {act.action === 'task_completed' && 'completed task'}
                      {act.action === 'comment_added' && 'commented on'}
                      {act.action === 'project_created' && 'created project'}
                      {!['task_created', 'task_moved', 'task_completed', 'comment_added', 'project_created'].includes(act.action) && act.action.replace('_', ' ')}
                    </span>{' '}
                    {act.task && <span className="font-semibold text-[#20242C]">"{act.task.title}"</span>}
                  </p>
                  <span className="text-[10px] text-gray-400 font-medium">
                    {new Date(act.createdAt).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
              </div>
            ))}

            {activities.length === 0 && (
              <div className="py-8 text-center text-xs text-gray-400">
                No recent team activity logged yet.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
