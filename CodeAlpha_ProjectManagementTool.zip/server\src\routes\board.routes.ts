import { Router, Response } from 'express';
import { z } from 'zod';
import prisma from '../prisma.js';
import { authenticate, requireProjectMember } from '../middleware/auth.js';
import { AuthRequest } from '../types/index.js';
import { broadcastToProject } from '../socket.js';

const router = Router({ mergeParams: true });

// GET /projects/:projectId/board - Get the board with all lists and tasks
router.get('/', authenticate, requireProjectMember('MEMBER'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { projectId } = req.params;

    let board = await prisma.board.findFirst({
      where: { projectId },
      include: {
        lists: {
          orderBy: { position: 'asc' },
          include: {
            tasks: {
              where: { archived: false },
              orderBy: { position: 'asc' },
              include: {
                assignees: {
                  include: {
                    user: {
                      select: { id: true, name: true, email: true, avatarUrl: true },
                    },
                  },
                },
                labels: {
                  include: {
                    label: true,
                  },
                },
                checklists: {
                  include: {
                    items: true,
                  },
                },
                attachments: {
                  select: { id: true, fileName: true, fileUrl: true, fileSize: true },
                },
                comments: {
                  select: { id: true },
                },
              },
            },
          },
        },
      },
    });

    // If board does not exist yet, create default board and lists
    if (!board) {
      board = await prisma.$transaction(async (tx) => {
        const newBoard = await tx.board.create({
          data: {
            projectId,
            name: 'Main Board',
            position: 0,
          },
        });

        const defaultLists = ['Backlog', 'To Do', 'In Progress', 'Review', 'Done'];
        for (let i = 0; i < defaultLists.length; i++) {
          await tx.list.create({
            data: {
              boardId: newBoard.id,
              name: defaultLists[i],
              position: i,
            },
          });
        }

        return tx.board.findUnique({
          where: { id: newBoard.id },
          include: {
            lists: {
              orderBy: { position: 'asc' },
              include: {
                tasks: {
                  include: {
                    assignees: { include: { user: true } },
                    labels: { include: { label: true } },
                    checklists: { include: { items: true } },
                    attachments: true,
                    comments: true,
                  },
                },
              },
            },
          },
        });
      });
    }

    res.json(board);
  } catch (error) {
    console.error('Fetch board error:', error);
    res.status(500).json({ message: 'Failed to retrieve project board.' });
  }
});

// POST /projects/:projectId/lists - Create a new column/list
router.post('/lists', authenticate, requireProjectMember('ADMIN'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { projectId } = req.params;
    const { name } = req.body;

    if (!name || name.trim().length === 0) {
      res.status(400).json({ message: 'List name is required.' });
      return;
    }

    const board = await prisma.board.findFirst({ where: { projectId } });
    if (!board) {
      res.status(404).json({ message: 'Board not found.' });
      return;
    }

    const lastList = await prisma.list.findFirst({
      where: { boardId: board.id },
      orderBy: { position: 'desc' },
    });

    const nextPosition = lastList ? lastList.position + 1 : 0;

    const list = await prisma.list.create({
      data: {
        boardId: board.id,
        name: name.trim(),
        position: nextPosition,
      },
      include: {
        tasks: {
          include: {
            assignees: { include: { user: true } },
            labels: { include: { label: true } },
            checklists: { include: { items: true } },
            attachments: true,
            comments: true,
          },
        },
      },
    });

    broadcastToProject(projectId, 'list:created', list);
    res.status(201).json(list);
  } catch (error) {
    res.status(500).json({ message: 'Failed to create list.' });
  }
});

// PATCH /projects/:projectId/lists/:listId - Rename list
router.patch('/lists/:listId', authenticate, requireProjectMember('ADMIN'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { projectId, listId } = req.params;
    const { name, position } = req.body;

    const updated = await prisma.list.update({
      where: { id: listId },
      data: {
        ...(name !== undefined && { name: name.trim() }),
        ...(position !== undefined && { position }),
      },
    });

    broadcastToProject(projectId, 'list:updated', updated);
    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: 'Failed to update list.' });
  }
});

// DELETE /projects/:projectId/lists/:listId - Delete list
router.delete('/lists/:listId', authenticate, requireProjectMember('ADMIN'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { projectId, listId } = req.params;

    await prisma.list.delete({
      where: { id: listId },
    });

    broadcastToProject(projectId, 'list:deleted', { listId });
    res.json({ message: 'List deleted successfully.' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete list.' });
  }
});

// POST /projects/:projectId/board/populate-presets - Populate ready-made cards across all sections
router.post('/populate-presets', authenticate, requireProjectMember('MEMBER'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { projectId } = req.params;
    const userId = req.user!.userId;
    const { templateId = 'fullstack' } = req.body;

    // 1. Get or create board with lists
    let board = await prisma.board.findFirst({
      where: { projectId },
      include: {
        lists: {
          orderBy: { position: 'asc' },
        },
      },
    });

    if (!board) {
      const defaultLists = ['Backlog', 'To Do', 'In Progress', 'Review', 'Done'];
      board = await prisma.board.create({
        data: {
          projectId,
          name: 'Main Board',
          position: 0,
          lists: {
            create: defaultLists.map((name, index) => ({ name, position: index })),
          },
        },
        include: { lists: { orderBy: { position: 'asc' } } },
      });
    }

    // 2. Fetch project labels & members for realistic assignments
    const [projectLabels, projectMembers] = await Promise.all([
      prisma.label.findMany({ where: { projectId } }),
      prisma.projectMember.findMany({ where: { projectId }, select: { userId: true } }),
    ]);

    const memberIds = projectMembers.map((m) => m.userId);
    if (!memberIds.includes(userId)) {
      memberIds.push(userId);
    }

    const getLabelIdByName = (name: string) => {
      const found = projectLabels.find((l) => l.name.toLowerCase().includes(name.toLowerCase()));
      return found ? found.id : null;
    };

    // 3. Define cards by section
    const presetCardsBySection: Record<string, Array<{
      title: string;
      description: string;
      priority: string;
      labelName?: string;
      checklists: string[];
    }>> = {
      BACKLOG: [
        {
          title: 'OAuth 2.0 & Social Login (Google & GitHub)',
          description: 'Configure passport/JWT strategy for third-party OAuth providers with account linking and callback routes.',
          priority: 'HIGH',
          labelName: 'Backend',
          checklists: [
            'Register OAuth app in Google Cloud Console',
            'Configure GitHub Developer OAuth application',
            'Build callback route & JWT token exchange',
            'Link social profile with existing user email',
          ],
        },
        {
          title: 'Export Project Velocity Reports to CSV/PDF',
          description: 'Allow project managers to generate summary exports of completed cards, member contributions, and overdue items.',
          priority: 'MEDIUM',
          labelName: 'Feature',
          checklists: [
            'Implement CSV streaming export endpoint',
            'Design printable PDF template layout',
            'Test export performance on large boards',
          ],
        },
        {
          title: 'Database Query Optimization & Indexing Audit',
          description: 'Profile slow queries on board retrieval. Add composite database indexes on listId, position, and status.',
          priority: 'MEDIUM',
          labelName: 'Backend',
          checklists: [
            'Profile slow Prisma queries in development',
            'Add compound database indexes in schema.prisma',
            'Benchmark retrieval latency before and after',
          ],
        },
      ],
      TODO: [
        {
          title: 'Build REST API for Bulk Card Status & Move Operations',
          description: 'Create batch endpoints allowing users to move multiple tasks or adjust priorities simultaneously in one call.',
          priority: 'HIGH',
          labelName: 'Backend',
          checklists: [
            'Define Zod schema for batch task IDs',
            'Implement Prisma atomic transaction endpoint',
            'Wire frontend multi-select checkboxes',
          ],
        },
        {
          title: 'Keyboard Accessibility & Quick Hotkeys (J/K/N/Space)',
          description: 'Add keyboard navigation: "N" for new card, "J/K" to cycle cards, "Space" to preview, and "Esc" to close.',
          priority: 'MEDIUM',
          labelName: 'Design',
          checklists: [
            'Attach global keyboard listener hook',
            'Style accessible focus ring around active card',
            'Create hotkey help modal dialog (Shift + ?)',
          ],
        },
        {
          title: 'Automated Vitest & Supertest Integration Tests',
          description: 'Ensure 100% test coverage for board state transformations, permissions, and task movement rules.',
          priority: 'HIGH',
          labelName: 'Feature',
          checklists: [
            'Setup in-memory SQLite testing database',
            'Write tests for task reordering and list boundaries',
            'Verify unauthorized user permission rejections',
          ],
        },
      ],
      IN_PROGRESS: [
        {
          title: 'Fluid Kanban Drag & Drop with Instant Server Sync',
          description: 'Ensure zero-latency visual card movement with optimistic state updates and graceful rollback on network error.',
          priority: 'URGENT',
          labelName: 'Design',
          checklists: [
            'Configure HTML5 drag-and-drop event handlers',
            'Implement position re-indexing logic',
            'Trigger confetti celebration when card enters Done',
          ],
        },
        {
          title: 'Real-time WebSocket Presence & Live Typing Indicators',
          description: 'Broadcast active teammates on the board and live typing alerts when someone is drafting a task comment.',
          priority: 'HIGH',
          labelName: 'Feature',
          checklists: [
            'Socket.IO room join/leave heartbeat',
            'Typing debounce tracker (1.5s delay)',
            'Display live animated teammate status rings',
          ],
        },
      ],
      REVIEW: [
        {
          title: 'Security Audit: JWT Refresh Flow & RBAC Route Protection',
          description: 'Verify all project routes require proper membership check (OWNER/ADMIN/MEMBER) and tokens rotate safely.',
          priority: 'URGENT',
          labelName: 'Backend',
          checklists: [
            'Verify project membership check on all endpoints',
            'Audit refresh token expiration and revocation',
            'Check CORS origins and CSP security headers',
          ],
        },
        {
          title: 'Cross-Browser Verification (Chrome, Edge, Safari, Firefox)',
          description: 'Perform visual inspection across all major browsers, verifying layout parity and animation smoothness.',
          priority: 'HIGH',
          labelName: 'Design',
          checklists: [
            'Test on Chromium engines (Chrome, Edge, Brave)',
            'Test on WebKit (macOS / iOS Safari)',
            'Check font rendering and border radiuses',
          ],
        },
      ],
      DONE: [
        {
          title: 'Setup Full-Stack Monorepo Structure & TypeScript Strict Mode',
          description: 'Configured unified workspace with TypeScript, Tailwind CSS, Vite, and Node.js Express architecture.',
          priority: 'MEDIUM',
          labelName: 'Feature',
          checklists: [
            'Root package.json concurrently runner configured',
            'Client tsconfig and Tailwind CSS setup',
            'Server tsx watch dev workflow verified',
          ],
        },
        {
          title: 'Design Relational Schema for Projects, Boards, Lists & Tasks',
          description: 'Implemented normalized SQLite schema with foreign key cascades and Prisma ORM client generator.',
          priority: 'HIGH',
          labelName: 'Backend',
          checklists: [
            'Defined models in schema.prisma',
            'Pushed SQLite dev.db migration',
            'Created seed dataset with demo users and tasks',
          ],
        },
      ],
    };

    // 4. Populate tasks in transaction
    await prisma.$transaction(async (tx) => {
      for (const list of board!.lists) {
        const norm = list.name.trim().toUpperCase().replace(/[\s-_]+/g, '');
        let sectionKey = 'TODO';
        if (norm.includes('BACKLOG')) sectionKey = 'BACKLOG';
        else if (norm.includes('TODO')) sectionKey = 'TODO';
        else if (norm.includes('PROGRESS') || norm.includes('DOING')) sectionKey = 'IN_PROGRESS';
        else if (norm.includes('REVIEW') || norm.includes('TEST') || norm.includes('QA')) sectionKey = 'REVIEW';
        else if (norm.includes('DONE') || norm.includes('COMPLETE')) sectionKey = 'DONE';

        const cards = presetCardsBySection[sectionKey] || [];
        
        // Find existing max position in this list
        const lastTask = await tx.task.findFirst({
          where: { listId: list.id },
          orderBy: { position: 'desc' },
        });
        let currentPos = lastTask ? lastTask.position + 1 : 0;

        for (let i = 0; i < cards.length; i++) {
          const cardDef = cards[i];
          const assignedUser = memberIds[(i + currentPos) % memberIds.length];
          const labelId = cardDef.labelName ? getLabelIdByName(cardDef.labelName) : null;

          const created = await tx.task.create({
            data: {
              listId: list.id,
              title: cardDef.title,
              description: cardDef.description,
              priority: cardDef.priority,
              position: currentPos++,
              createdById: userId,
              status: list.name.toUpperCase(),
              dueDate: new Date(Date.now() + (i + 2) * 86400000 * 2),
            },
          });

          // Assign member
          if (assignedUser) {
            await tx.taskAssignee.create({
              data: { taskId: created.id, userId: assignedUser },
            });
          }

          // Assign label
          if (labelId) {
            await tx.taskLabel.create({
              data: { taskId: created.id, labelId },
            });
          }

          // Checklists
          if (cardDef.checklists && cardDef.checklists.length > 0) {
            const cl = await tx.checklist.create({
              data: {
                taskId: created.id,
                title: 'Action Items',
                position: 0,
              },
            });
            for (let cIdx = 0; cIdx < cardDef.checklists.length; cIdx++) {
              await tx.checklistItem.create({
                data: {
                  checklistId: cl.id,
                  text: cardDef.checklists[cIdx],
                  completed: sectionKey === 'DONE', // mark done if in Done column!
                  position: cIdx,
                },
              });
            }
          }
        }
      }
    });

    // 5. Fetch and return complete refreshed board
    const updatedBoard = await prisma.board.findUnique({
      where: { id: board.id },
      include: {
        lists: {
          orderBy: { position: 'asc' },
          include: {
            tasks: {
              where: { archived: false },
              orderBy: { position: 'asc' },
              include: {
                assignees: {
                  include: {
                    user: { select: { id: true, name: true, email: true, avatarUrl: true } },
                  },
                },
                labels: { include: { label: true } },
                checklists: { include: { items: true } },
                attachments: true,
                comments: { select: { id: true } },
              },
            },
          },
        },
      },
    });

    broadcastToProject(projectId, 'board:updated', updatedBoard);
    res.json(updatedBoard);
  } catch (error) {
    console.error('Failed to populate presets:', error);
    res.status(500).json({ message: 'Failed to populate card options on board.' });
  }
});

export default router;
