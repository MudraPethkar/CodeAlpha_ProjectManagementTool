import { Router, Response } from 'express';
import { z } from 'zod';
import prisma from '../prisma.js';
import { hashPassword, comparePassword, generateAccessToken, generateRefreshToken, verifyRefreshToken } from '../utils/jwt.js';
import { authenticate } from '../middleware/auth.js';
import { AuthRequest } from '../types/index.js';

const router = Router();

const registerSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Invalid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  avatarUrl: z.string().optional(),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1, 'Password is required'),
});

// POST /auth/register
router.post('/register', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const validated = registerSchema.safeParse(req.body);
    if (!validated.success) {
      res.status(400).json({ message: validated.error.errors[0].message });
      return;
    }

    const { name, email, password, avatarUrl } = validated.data;
    const existing = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
    });

    if (existing) {
      res.status(400).json({ message: 'A user with this email already exists.' });
      return;
    }

    const passwordHash = await hashPassword(password);
    const user = await prisma.user.create({
      data: {
        name,
        email: email.toLowerCase(),
        passwordHash,
        avatarUrl: avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(name)}`,
      },
      select: {
        id: true,
        name: true,
        email: true,
        avatarUrl: true,
        role: true,
        bio: true,
        createdAt: true,
      },
    });

    const accessToken = generateAccessToken({ userId: user.id, email: user.email, role: user.role });
    const refreshToken = generateRefreshToken({ userId: user.id, email: user.email, role: user.role });

    res.status(201).json({
      user,
      accessToken,
      refreshToken,
      message: 'Account created successfully!',
    });
  } catch (error) {
    console.error('Register error:', error);
    res.status(500).json({ message: 'Internal server error while creating account.' });
  }
});

// POST /auth/login
router.post('/login', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const validated = loginSchema.safeParse(req.body);
    if (!validated.success) {
      res.status(400).json({ message: validated.error.errors[0].message });
      return;
    }

    const { email, password } = validated.data;
    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
    });

    if (!user) {
      res.status(401).json({ message: 'Invalid email or password.' });
      return;
    }

    const isValid = await comparePassword(password, user.passwordHash);
    if (!isValid) {
      res.status(401).json({ message: 'Invalid email or password.' });
      return;
    }

    const accessToken = generateAccessToken({ userId: user.id, email: user.email, role: user.role });
    const refreshToken = generateRefreshToken({ userId: user.id, email: user.email, role: user.role });

    const safeUser = {
      id: user.id,
      name: user.name,
      email: user.email,
      avatarUrl: user.avatarUrl,
      role: user.role,
      bio: user.bio,
      createdAt: user.createdAt,
    };

    res.json({
      user: safeUser,
      accessToken,
      refreshToken,
      message: 'Logged in successfully!',
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Internal server error while logging in.' });
  }
});

// POST /auth/refresh
router.post('/refresh', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) {
      res.status(400).json({ message: 'Refresh token is required.' });
      return;
    }

    const payload = verifyRefreshToken(refreshToken);
    if (!payload) {
      res.status(401).json({ message: 'Invalid or expired refresh token.' });
      return;
    }

    const user = await prisma.user.findUnique({
      where: { id: payload.userId },
      select: { id: true, email: true, role: true },
    });

    if (!user) {
      res.status(401).json({ message: 'User not found.' });
      return;
    }

    const newAccessToken = generateAccessToken({ userId: user.id, email: user.email, role: user.role });
    res.json({ accessToken: newAccessToken });
  } catch (error) {
    res.status(500).json({ message: 'Failed to refresh token.' });
  }
});

// POST /auth/logout
router.post('/logout', (_req: AuthRequest, res: Response): void => {
  res.json({ message: 'Logged out successfully.' });
});

// GET /me
router.get('/me', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.userId;
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        name: true,
        email: true,
        avatarUrl: true,
        role: true,
        bio: true,
        createdAt: true,
      },
    });

    if (!user) {
      res.status(404).json({ message: 'User not found.' });
      return;
    }

    res.json(user);
  } catch (error) {
    res.status(500).json({ message: 'Failed to retrieve profile.' });
  }
});

// PATCH /me
router.patch('/me', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.userId;
    const { name, bio, avatarUrl, currentPassword, newPassword } = req.body;

    const currentUser = await prisma.user.findUnique({
      where: { id: userId },
    });

    if (!currentUser) {
      res.status(404).json({ message: 'User not found.' });
      return;
    }

    let passwordHash = currentUser.passwordHash;
    if (newPassword) {
      if (!currentPassword) {
        res.status(400).json({ message: 'Current password is required to set a new password.' });
        return;
      }
      const match = await comparePassword(currentPassword, currentUser.passwordHash);
      if (!match) {
        res.status(400).json({ message: 'Current password is incorrect.' });
        return;
      }
      if (newPassword.length < 6) {
        res.status(400).json({ message: 'New password must be at least 6 characters.' });
        return;
      }
      passwordHash = await hashPassword(newPassword);
    }

    const updated = await prisma.user.update({
      where: { id: userId },
      data: {
        name: name !== undefined ? name : currentUser.name,
        bio: bio !== undefined ? bio : currentUser.bio,
        avatarUrl: avatarUrl !== undefined ? avatarUrl : currentUser.avatarUrl,
        passwordHash,
      },
      select: {
        id: true,
        name: true,
        email: true,
        avatarUrl: true,
        role: true,
        bio: true,
        createdAt: true,
      },
    });

    res.json({ user: updated, message: 'Profile updated successfully!' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to update profile.' });
  }
});

// POST /auth/forgot-password
router.post('/forgot-password', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { email } = req.body;
    if (!email) {
      res.status(400).json({ message: 'Email is required.' });
      return;
    }

    const user = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });
    if (!user) {
      // Security best practice: don't reveal if email exists
      res.json({ message: 'If an account exists with this email, a reset link/code has been generated.' });
      return;
    }

    // In a production app with SendGrid/Resend, you would send an email here.
    // For demo/development, we simulate the reset token response.
    const resetToken = Buffer.from(`${user.id}:${Date.now()}`).toString('base64');
    res.json({
      message: 'Password reset link sent to your email.',
      demoResetToken: resetToken, // Provided for easy testing in development
    });
  } catch (error) {
    res.status(500).json({ message: 'Failed to process forgot-password request.' });
  }
});

// POST /auth/reset-password
router.post('/reset-password', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { token, newPassword } = req.body;
    if (!token || !newPassword || newPassword.length < 6) {
      res.status(400).json({ message: 'Valid token and minimum 6 character password required.' });
      return;
    }

    const decoded = Buffer.from(token, 'base64').toString('utf8');
    const [userId] = decoded.split(':');

    if (!userId) {
      res.status(400).json({ message: 'Invalid reset token.' });
      return;
    }

    const passwordHash = await hashPassword(newPassword);
    await prisma.user.update({
      where: { id: userId },
      data: { passwordHash },
    });

    res.json({ message: 'Password has been reset successfully. You can now log in.' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to reset password.' });
  }
});

export default router;
