import React, { useState, useEffect } from 'react';
import {
  Users,
  UserPlus,
  Settings,
  Circle,
  Share2,
  Lock,
  Globe,
  Sparkles,
} from 'lucide-react';
import { Project, Board, Task } from '../../types';
import { KanbanBoard } from '../Kanban/KanbanBoard';
import { useSocket } from '../../context/SocketContext';
import api from '../../services/api';

interface ProjectBoardViewProps {
  projectId: string;
  onSelectTask: (task: Task) => void;
  onOpenMembersModal: () => void;
}

export const ProjectBoardView: React.FC<ProjectBoardViewProps> = ({
  projectId,
  onSelectTask,
  onOpenMembersModal,
}) => {
  const { onlineUsers } = useSocket();
  const [project, setProject] = useState<Project | null>(null);
  const [board, setBoard] = useState<Board | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const loadProjectAndBoard = async () => {
    try {
      const [projData, boardData] = await Promise.all([
        api.getProject(projectId),
        api.getBoard(projectId),
      ]);
      setProject(projData);
      setBoard(boardData);
    } catch (err) {
      console.error('Failed to load project board:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    setIsLoading(true);
    loadProjectAndBoard();
  }, [projectId]);

  if (isLoading || !project || !board) {
    return (
      <div className="flex-1 flex items-center justify-center bg-[#F9FAFB]">
        <div className="text-center">
          <div className="w-10 h-10 border-4 border-[#A3E635] border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-xs font-bold text-gray-500">Loading Kanban board...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col h-[calc(100vh-4rem)] overflow-hidden">
      {/* Top Project Sub-Header */}
      <div className="bg-white border-b border-[#E5E7EB] px-6 py-3 flex flex-wrap items-center justify-between gap-3 shadow-xs">
        {/* Project Title & Metadata */}
        <div className="flex items-center space-x-3">
          <span
            className="w-3.5 h-3.5 rounded-full ring-2 ring-offset-2 ring-transparent"
            style={{ backgroundColor: project.color }}
          />
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-lg font-extrabold text-[#20242C] tracking-tight">
                {project.name}
              </h2>
              {project.isPrivate ? (
                <span className="flex items-center gap-1 text-[10px] font-bold uppercase text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full">
                  <Lock className="w-2.5 h-2.5" />
                  Private
                </span>
              ) : (
                <span className="flex items-center gap-1 text-[10px] font-bold uppercase text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                  <Globe className="w-2.5 h-2.5" />
                  Public
                </span>
              )}
            </div>
            {project.description && (
              <p className="text-xs text-gray-400 truncate max-w-md">{project.description}</p>
            )}
          </div>
        </div>

        {/* Live Presence, Members & Controls */}
        <div className="flex items-center space-x-3">
          {/* Member avatars */}
          <div className="flex items-center -space-x-1.5 mr-1">
            {project.members?.slice(0, 5).map((m) => {
              const isOnline = onlineUsers.some((ou) => ou.userId === m.userId);
              return (
                <div key={m.id} className="relative group" title={`${m.user.name} (${m.role})`}>
                  <img
                    src={m.user?.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${m.user?.name}`}
                    alt={m.user?.name}
                    className={`w-7 h-7 rounded-full object-cover border-2 border-white transition-transform ${
                      isOnline ? 'ring-2 ring-[#A3E635]' : ''
                    }`}
                  />
                  {isOnline && (
                    <span className="absolute bottom-0 right-0 w-2 h-2 rounded-full bg-[#A3E635] ring-1 ring-white" />
                  )}
                </div>
              );
            })}
          </div>

          {/* Invite Member Button */}
          <button
            onClick={onOpenMembersModal}
            className="flex items-center space-x-1.5 text-xs font-bold bg-gray-100 hover:bg-[#20242C] text-[#20242C] hover:text-white px-3 py-1.5 rounded-xl transition-all"
          >
            <UserPlus className="w-3.5 h-3.5 text-[#A3E635]" />
            <span>Invite</span>
          </button>
        </div>
      </div>

      {/* Kanban Board Container */}
      <KanbanBoard
        project={project}
        board={board}
        onSelectTask={onSelectTask}
        onRefreshBoard={loadProjectAndBoard}
      />
    </div>
  );
};
