import React, { useState, useEffect } from 'react';
import { Search, FolderKanban, CheckSquare, X, ArrowRight } from 'lucide-react';
import api from '../../services/api';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProject: (projectId: string) => void;
  onSelectTask: (taskId: string, projectId: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectProject,
  onSelectTask,
}) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<{ projects: any[]; tasks: any[] }>({
    projects: [],
    tasks: [],
  });
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      setQuery('');
      setResults({ projects: [], tasks: [] });
    }
  }, [isOpen]);

  useEffect(() => {
    const delayDebounceFn = setTimeout(async () => {
      if (query.trim().length > 1) {
        setIsSearching(true);
        try {
          const res = await api.search(query);
          setResults(res);
        } catch (err) {
          console.error('Search error:', err);
        } finally {
          setIsSearching(false);
        }
      } else {
        setResults({ projects: [], tasks: [] });
      }
    }, 250);

    return () => clearTimeout(delayDebounceFn);
  }, [query]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-start justify-center pt-20 p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-3xl w-full max-w-xl shadow-2xl border border-gray-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Bar Input */}
        <div className="p-4 border-b border-gray-100 flex items-center space-x-3 bg-gray-50/50">
          <Search className="w-5 h-5 text-gray-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type to search projects, tasks, or tags..."
            className="w-full text-sm font-medium bg-transparent focus:outline-none text-[#20242C] placeholder-gray-400"
            autoFocus
          />
          {query && (
            <button onClick={() => setQuery('')} className="text-gray-400 hover:text-gray-600">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Results Container */}
        <div className="max-h-96 overflow-y-auto p-4 space-y-4">
          {isSearching && (
            <div className="text-center py-6 text-xs text-gray-400 font-medium">Searching...</div>
          )}

          {/* Projects Results */}
          {results.projects.length > 0 && (
            <div>
              <h5 className="text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-2">
                Projects ({results.projects.length})
              </h5>
              <div className="space-y-1">
                {results.projects.map((p) => (
                  <div
                    key={p.id}
                    onClick={() => {
                      onSelectProject(p.id);
                      onClose();
                    }}
                    className="flex items-center justify-between p-2.5 rounded-xl hover:bg-[#F3F4F6] cursor-pointer transition-colors group"
                  >
                    <div className="flex items-center space-x-2.5">
                      <span
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: p.color }}
                      />
                      <div>
                        <h6 className="text-xs font-bold text-[#20242C] group-hover:text-[#20242C]">
                          {p.name}
                        </h6>
                        {p.description && (
                          <p className="text-[11px] text-gray-400 truncate max-w-sm">
                            {p.description}
                          </p>
                        )}
                      </div>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-gray-400 group-hover:text-[#20242C] opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tasks Results */}
          {results.tasks.length > 0 && (
            <div>
              <h5 className="text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-2">
                Task Cards ({results.tasks.length})
              </h5>
              <div className="space-y-1">
                {results.tasks.map((t) => (
                  <div
                    key={t.id}
                    onClick={() => {
                      onSelectTask(t.id, t.projectId);
                      onClose();
                    }}
                    className="flex items-center justify-between p-2.5 rounded-xl hover:bg-[#F3F4F6] cursor-pointer transition-colors group"
                  >
                    <div className="flex items-center space-x-2.5">
                      <CheckSquare className="w-4 h-4 text-[#A3E635] flex-shrink-0" />
                      <div>
                        <h6 className="text-xs font-bold text-[#20242C]">{t.title}</h6>
                        <span className="text-[10px] text-gray-400">
                          in {t.projectName} • {t.listName}
                        </span>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold uppercase px-1.5 py-0.5 rounded bg-gray-100 text-gray-600">
                      {t.priority}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {query.trim().length > 1 &&
            !isSearching &&
            results.projects.length === 0 &&
            results.tasks.length === 0 && (
              <div className="text-center py-8 text-xs text-gray-400">
                No matching results found for "{query}".
              </div>
            )}

          {!query && (
            <div className="text-center py-8 text-xs text-gray-400">
              Search by typing any task name, project title, or keyword.
            </div>
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="px-4 py-2.5 bg-gray-50 border-t border-gray-100 flex items-center justify-between text-[11px] text-gray-400 font-medium">
          <span>Navigate with mouse or keyboard</span>
          <kbd className="bg-white border border-gray-200 px-1.5 py-0.5 rounded font-mono text-[10px]">
            ESC to close
          </kbd>
        </div>
      </div>
    </div>
  );
};
