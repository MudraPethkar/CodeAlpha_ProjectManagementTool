import React, { useState } from 'react';
import {
  FolderKanban,
  Plus,
  Search,
  ArrowRight,
  MoreVertical,
  Trash2,
  Lock,
  Globe,
  Users,
} from 'lucide-react';
import { Project } from '../../types';

interface ProjectsViewProps {
  projects: Project[];
  onSelectProject: (projectId: string) => void;
  onOpenCreateProject: () => void;
  onDeleteProject?: (projectId: string) => void;
}

export const ProjectsView: React.FC<ProjectsViewProps> = ({
  projects,
  onSelectProject,
  onOpenCreateProject,
  onDeleteProject,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [privacyFilter, setPrivacyFilter] = useState<'ALL' | 'PUBLIC' | 'PRIVATE'>('ALL');

  const filtered = projects.filter((p) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = p.name.toLowerCase().includes(q);
      const matchDesc = p.description?.toLowerCase().includes(q);
      if (!matchName && !matchDesc) return false;
    }
    if (privacyFilter === 'PUBLIC' && p.isPrivate) return false;
    if (privacyFilter === 'PRIVATE' && !p.isPrivate) return false;
    return true;
  });

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8 space-y-6 bg-[#F9FAFB]">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-[#20242C] tracking-tight">All Projects</h2>
          <p className="text-xs text-gray-500 mt-1">
            Browse and organize all team boards and workspaces.
          </p>
        </div>

        <button
          onClick={onOpenCreateProject}
          className="bg-[#A3E635] hover:bg-[#8dd321] text-[#20242C] font-bold text-xs px-4 py-2.5 rounded-xl flex items-center space-x-2 shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>New Project</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-3 rounded-2xl border border-[#E5E7EB] flex flex-wrap items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center space-x-2.5 flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search projects..."
            className="w-full text-xs bg-transparent focus:outline-none text-[#20242C]"
          />
        </div>

        <div className="flex items-center space-x-2">
          <select
            value={privacyFilter}
            onChange={(e) => setPrivacyFilter(e.target.value as any)}
            className="text-xs font-semibold px-2.5 py-1.5 bg-gray-50 border border-gray-200 rounded-lg text-[#20242C] focus:outline-none focus:border-[#A3E635]"
          >
            <option value="ALL">All Visibility</option>
            <option value="PUBLIC">Public</option>
            <option value="PRIVATE">Private</option>
          </select>
        </div>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.map((project) => (
          <div
            key={project.id}
            onClick={() => onSelectProject(project.id)}
            className="bg-white rounded-2xl p-6 border border-[#E5E7EB] hover:border-[#A3E635] shadow-xs hover:shadow-md transition-all duration-200 cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <span
                    className="w-3.5 h-3.5 rounded-full"
                    style={{ backgroundColor: project.color }}
                  />
                  {project.isPrivate ? (
                    <span className="flex items-center gap-1 text-[10px] font-bold uppercase text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full">
                      <Lock className="w-2.5 h-2.5" />
                      Private
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-[10px] font-bold uppercase text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                      <Globe className="w-2.5 h-2.5" />
                      Public
                    </span>
                  )}
                </div>

                <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">
                  {project.currentUserRole || 'Member'}
                </span>
              </div>

              <h3 className="font-extrabold text-base text-[#20242C] group-hover:text-[#20242C] mb-2 transition-colors">
                {project.name}
              </h3>
              <p className="text-xs text-gray-500 line-clamp-2 leading-relaxed mb-6">
                {project.description || 'No description provided.'}
              </p>
            </div>

            <div>
              {/* Progress Bar */}
              <div className="mb-4">
                <div className="flex items-center justify-between text-[11px] text-gray-500 font-semibold mb-1.5">
                  <span>Progress ({project.completedTasks || 0}/{project.totalTasks || 0} tasks)</span>
                  <span>{project.progressPercent || 0}%</span>
                </div>
                <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#A3E635] rounded-full transition-all duration-300"
                    style={{ width: `${project.progressPercent || 0}%` }}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                <div className="flex items-center -space-x-1.5">
                  {project.members?.slice(0, 4).map((m) => (
                    <img
                      key={m.id}
                      src={m.user?.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${m.user?.name}`}
                      alt={m.user?.name}
                      title={m.user?.name}
                      className="w-6 h-6 rounded-full object-cover border-2 border-white"
                    />
                  ))}
                  {project.members && project.members.length > 4 && (
                    <span className="w-6 h-6 rounded-full bg-gray-100 text-gray-600 border-2 border-white flex items-center justify-center text-[10px] font-bold">
                      +{project.members.length - 4}
                    </span>
                  )}
                </div>

                <span className="text-xs font-bold text-gray-400 group-hover:text-[#20242C] flex items-center gap-1 transition-colors">
                  Open Board
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="py-16 text-center text-xs text-gray-400">
          No projects found matching your criteria.
        </div>
      )}
    </div>
  );
};
