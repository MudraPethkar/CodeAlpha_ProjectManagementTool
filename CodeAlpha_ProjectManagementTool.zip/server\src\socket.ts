import { Server as SocketIOServer, Socket } from 'socket.io';
import { verifyAccessToken } from './utils/jwt.js';

let io: SocketIOServer | null = null;

// Track presence: projectId -> Map<socketId, { userId: string, name: string, avatarUrl?: string }>
const projectPresence = new Map<string, Map<string, { userId: string; name: string; avatarUrl?: string }>>();

export const setupSocketIO = (socketServer: SocketIOServer) => {
  io = socketServer;

  // Socket middleware for authentication
  io.use((socket: Socket, next) => {
    const token = socket.handshake.auth?.token || socket.handshake.headers?.authorization?.replace('Bearer ', '');
    if (!token) {
      // Allow unauthenticated connection or guest, but flag it
      return next();
    }

    const payload = verifyAccessToken(token);
    if (payload) {
      (socket as any).user = payload;
    }
    next();
  });

  io.on('connection', (socket: Socket) => {
    const user = (socket as any).user;

    // If user is authenticated, join their private notifications room
    if (user?.userId) {
      socket.join(`user:${user.userId}`);
    }

    // Join project room for board real-time collaboration
    socket.on('project:join', ({ projectId, userInfo }: { projectId: string; userInfo?: { name: string; avatarUrl?: string } }) => {
      if (!projectId) return;

      socket.join(`project:${projectId}`);
      (socket as any).currentProjectId = projectId;

      if (user?.userId) {
        if (!projectPresence.has(projectId)) {
          projectPresence.set(projectId, new Map());
        }
        const roomUsers = projectPresence.get(projectId)!;
        roomUsers.set(socket.id, {
          userId: user.userId,
          name: userInfo?.name || user.email.split('@')[0],
          avatarUrl: userInfo?.avatarUrl,
        });

        // Broadcast presence list (deduplicating by userId)
        const activeUsers = Array.from(
          new Map(Array.from(roomUsers.values()).map(u => [u.userId, u])).values()
        );
        io?.to(`project:${projectId}`).emit('project:presence', activeUsers);
      }
    });

    // Leave project room
    socket.on('project:leave', ({ projectId }: { projectId: string }) => {
      if (!projectId) return;
      socket.leave(`project:${projectId}`);

      if (projectPresence.has(projectId)) {
        const roomUsers = projectPresence.get(projectId)!;
        roomUsers.delete(socket.id);
        if (roomUsers.size === 0) {
          projectPresence.delete(projectId);
        } else {
          const activeUsers = Array.from(
            new Map(Array.from(roomUsers.values()).map(u => [u.userId, u])).values()
          );
          io?.to(`project:${projectId}`).emit('project:presence', activeUsers);
        }
      }
    });

    // Typing indicators in task comments
    socket.on('task:typing', ({ projectId, taskId, userName, isTyping }: { projectId: string; taskId: string; userName: string; isTyping: boolean }) => {
      socket.to(`project:${projectId}`).emit('task:typing', {
        taskId,
        userName,
        isTyping,
        userId: user?.userId,
      });
    });

    // Handle disconnect
    socket.on('disconnect', () => {
      const projectId = (socket as any).currentProjectId;
      if (projectId && projectPresence.has(projectId)) {
        const roomUsers = projectPresence.get(projectId)!;
        roomUsers.delete(socket.id);
        if (roomUsers.size === 0) {
          projectPresence.delete(projectId);
        } else {
          const activeUsers = Array.from(
            new Map(Array.from(roomUsers.values()).map(u => [u.userId, u])).values()
          );
          io?.to(`project:${projectId}`).emit('project:presence', activeUsers);
        }
      }
    });
  });

  return io;
};

export const getIO = (): SocketIOServer | null => io;

export const broadcastToProject = (projectId: string, event: string, data: any) => {
  if (io) {
    io.to(`project:${projectId}`).emit(event, data);
  }
};

export const sendNotificationToUser = (userId: string, notification: any) => {
  if (io) {
    io.to(`user:${userId}`).emit('notification:new', notification);
  }
};
