import nodemailer, { type Transporter } from 'nodemailer';

const SMTP_HOST = process.env.SMTP_HOST || '';
const SMTP_PORT = parseInt(process.env.SMTP_PORT || '587', 10);
const SMTP_SECURE = process.env.SMTP_SECURE === 'true' || SMTP_PORT === 465;
const SMTP_USER = process.env.SMTP_USER || '';
const SMTP_PASS = process.env.SMTP_PASS || '';
const SMTP_FROM = process.env.SMTP_FROM || (SMTP_USER ? `"TASKLY" <${SMTP_USER}>` : '"TASKLY" <no-reply@taskly.dev>');
const CLIENT_URL = process.env.CLIENT_URL || 'http://localhost:5173';

let transporter: Transporter | null = null;

if (SMTP_HOST && SMTP_USER && SMTP_PASS) {
  transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: SMTP_PORT,
    secure: SMTP_SECURE,
    auth: {
      user: SMTP_USER,
      pass: SMTP_PASS,
    },
  });
  console.log(`📧 Mailer configured with SMTP host: ${SMTP_HOST}:${SMTP_PORT} (${SMTP_USER})`);
} else {
  console.log('ℹ️ SMTP credentials not configured in server/.env (emails will log invite URLs to console)');
}

interface SendInvitationEmailParams {
  to: string;
  inviterName: string;
  projectName: string;
  inviteToken: string;
  role: string;
}

export const sendProjectInvitationEmail = async ({
  to,
  inviterName,
  projectName,
  inviteToken,
  role,
}: SendInvitationEmailParams): Promise<{ sent: boolean; inviteUrl: string; reason?: string }> => {
  const inviteUrl = `${CLIENT_URL}?inviteToken=${inviteToken}`;

  const emailHtml = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #F9FAFB; margin: 0; padding: 24px; color: #20242C; }
          .container { max-width: 560px; margin: 0 auto; background: #ffffff; border-radius: 16px; border: 1px solid #E5E7EB; overflow: hidden; }
          .header { background: #20242C; padding: 24px; text-align: center; }
          .logo { font-size: 20px; font-weight: 800; color: #ffffff; letter-spacing: -0.5px; }
          .badge { background: #A3E635; color: #20242C; padding: 2px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; margin-left: 6px; }
          .content { padding: 32px 28px; }
          h2 { font-size: 20px; font-weight: 800; color: #20242C; margin-top: 0; }
          p { font-size: 14px; line-height: 1.6; color: #4B5563; }
          .btn-container { text-align: center; margin: 28px 0; }
          .btn { background-color: #A3E635; color: #20242C; text-decoration: none; padding: 12px 28px; border-radius: 10px; font-weight: 800; font-size: 14px; display: inline-block; box-shadow: 0 4px 6px -1px rgba(163, 230, 53, 0.3); }
          .footer { padding: 20px; text-align: center; font-size: 12px; color: #9CA3AF; border-top: 1px solid #F3F4F6; }
          .url-box { background: #F3F4F6; padding: 12px; border-radius: 8px; font-size: 12px; word-break: break-all; color: #6B7280; margin-top: 16px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <span class="logo">TASKLY<span class="badge">COLLABORATE</span></span>
          </div>
          <div class="content">
            <h2>You've been invited to join ${projectName}</h2>
            <p><strong>${inviterName}</strong> has invited you to collaborate on <strong>${projectName}</strong> as a <strong>${role}</strong>.</p>
            <p>TASKLY lets you organize tasks with real-time Kanban boards, communicate through task comments, and track project progress effortlessly.</p>
            <div class="btn-container">
              <a href="${inviteUrl}" class="btn">Accept Invitation & Join Project</a>
            </div>
            <p>Or paste this link into your browser:</p>
            <div class="url-box">${inviteUrl}</div>
          </div>
          <div class="footer">
            Plan together. Ship faster. • TASKLY Collaborative Project Management
          </div>
        </div>
      </body>
    </html>
  `;

  if (transporter) {
    try {
      await transporter.sendMail({
        from: SMTP_FROM,
        to,
        subject: `${inviterName} invited you to join "${projectName}" on TASKLY`,
        html: emailHtml,
        text: `${inviterName} invited you to join "${projectName}" as a ${role} on TASKLY. Click the link to join: ${inviteUrl}`,
      });
      console.log(`✅ Real email successfully delivered to: ${to}`);
      return { sent: true, inviteUrl };
    } catch (error: any) {
      console.error(`⚠️ Failed to deliver email to ${to}:`, error.message);
      return { sent: false, inviteUrl, reason: error.message };
    }
  } else {
    console.log(`\n========================================`);
    console.log(`📬 [SIMULATED EMAIL DISPATCH]`);
    console.log(`To: ${to}`);
    console.log(`Subject: ${inviterName} invited you to join "${projectName}" on TASKLY`);
    console.log(`Invite URL: ${inviteUrl}`);
    console.log(`========================================\n`);
    return { sent: false, inviteUrl, reason: 'SMTP not configured in server/.env' };
  }
};
