import express, { Request, Response, NextFunction } from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import { Server as SocketIOServer } from 'socket.io';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

import authRoutes from './routes/auth.routes.js';
import projectRoutes from './routes/project.routes.js';
import boardRoutes from './routes/board.routes.js';
import taskRoutes from './routes/task.routes.js';
import commentRoutes from './routes/comment.routes.js';
import notificationRoutes from './routes/notification.routes.js';
import activityRoutes from './routes/activity.routes.js';
import { setupSocketIO } from './socket.js';
import prisma from './prisma.js';

const app = express();
const server = http.createServer(app);

const PORT = process.env.PORT || 5000;
const CLIENT_URL = process.env.CLIENT_URL || 'http://localhost:5173';

// Setup Socket.IO
const io = new SocketIOServer(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST', 'PATCH', 'DELETE'],
  },
});
setupSocketIO(io);

// Middleware
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Health Check
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    app: 'TASKLY API',
    tagline: 'Plan together. Ship faster.',
    timestamp: new Date().toISOString(),
  });
});

// Download Project Zip
app.get('/api/download-zip', (_req: Request, res: Response) => {
  const zipPath = path.resolve(process.cwd(), '..', 'CodeAlpha_ProjectManagementTool.zip');
  const fallbackPath = path.resolve(process.cwd(), 'CodeAlpha_ProjectManagementTool.zip');
  const target = fs.existsSync(zipPath) ? zipPath : fallbackPath;
  if (fs.existsSync(target)) {
    return res.download(target, 'CodeAlpha_ProjectManagementTool.zip');
  }
  return res.status(404).json({ message: 'Zip file not found' });
});

// Mount Routes
app.use('/api/auth', authRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/projects/:projectId/board', boardRoutes);
app.use('/api', taskRoutes);
app.use('/api', commentRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api', activityRoutes);

// Global Error Handler
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  console.error('Unhandled Server Error:', err);
  res.status(500).json({
    message: err.message || 'Internal server error',
  });
});

// Start Server
server.listen(PORT, async () => {
  try {
    await prisma.$connect();
    console.log(`🚀 TASKLY Backend Server running on port ${PORT}`);
    console.log(`✨ WebSocket collaboration active`);
  } catch (err) {
    console.error('Failed to connect to database:', err);
  }
});
