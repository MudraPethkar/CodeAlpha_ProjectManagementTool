import { describe, it, expect, beforeAll } from 'vitest';
import bcrypt from 'bcryptjs';
import { hashPassword, comparePassword, generateAccessToken, verifyAccessToken } from '../src/utils/jwt.js';

describe('TASKLY Auth Utilities & Security', () => {
  it('should correctly hash and verify passwords', async () => {
    const password = 'TestSecurePassword123!';
    const hash = await hashPassword(password);

    expect(hash).not.toBe(password);
    const isValid = await comparePassword(password, hash);
    expect(isValid).toBe(true);

    const isInvalid = await comparePassword('WrongPassword', hash);
    expect(isInvalid).toBe(false);
  });

  it('should generate and verify valid JWT tokens', () => {
    const payload = {
      userId: 'user-test-123',
      email: 'alex@taskly.dev',
      role: 'ADMIN',
    };

    const token = generateAccessToken(payload);
    expect(typeof token).toBe('string');

    const decoded = verifyAccessToken(token);
    expect(decoded).not.toBeNull();
    expect(decoded?.userId).toBe('user-test-123');
    expect(decoded?.email).toBe('alex@taskly.dev');
    expect(decoded?.role).toBe('ADMIN');
  });

  it('should reject invalid or tampered tokens', () => {
    const result = verifyAccessToken('invalid.token.here');
    expect(result).toBeNull();
  });
});
