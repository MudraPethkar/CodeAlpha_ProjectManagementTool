import {
  User,
  Project,
  Board,
  List,
  Task,
  Comment,
  Notification,
  Activity,
  Invitation,
  Label,
  Checklist,
  ChecklistItem,
  Attachment,
} from '../types';

const API_BASE = '/api';

class ApiService {
  private getHeaders(): HeadersInit {
    const token = localStorage.getItem('taskly_token');
    return {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    };
  }

  private async handleResponse<T>(response: Response): Promise<T> {
    if (!response.ok) {
      let errorMessage = 'An error occurred';
      try {
        const errorData = await response.json();
        errorMessage = errorData.message || errorMessage;
      } catch {
        errorMessage = response.statusText;
      }
      throw new Error(errorMessage);
    }
    return response.json();
  }

  // --- Auth Endpoints ---
  async login(email: string, password: string):Promise<{ user: User; accessToken: string; refreshToken: string }> {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    return this.handleResponse(res);
  }

  async register(data: { name: string; email: string; password: string; avatarUrl?: string }): Promise<{ user: User; accessToken: string; refreshToken: string }> {
    const res = await fetch(`${API_BASE}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return this.handleResponse(res);
  }

  async getMe(): Promise<User> {
    const res = await fetch(`${API_BASE}/auth/me`, {
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  async updateMe(data: Partial<User> & { currentPassword?: string; newPassword?: string }): Promise<{ user: User; message: string }> {
    const res = await fetch(`${API_BASE}/auth/me`, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });
    return this.handleResponse(res);
  }

  async forgotPassword(email: string): Promise<{ message: string; demoResetToken?: string }> {
    const res = await fetch(`${API_BASE}/auth/forgot-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email }),
    });
    return this.handleResponse(res);
  }

  async resetPassword(token: string, newPassword: string): Promise<{ message: string }> {
    const res = await fetch(`${API_BASE}/auth/reset-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, newPassword }),
    });
    return this.handleResponse(res);
  }

  // --- Project Endpoints ---
  async getProjects(): Promise<Project[]> {
    const res = await fetch(`${API_BASE}/projects`, {
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  async createProject(data: { name: string; description?: string; color?: string; icon?: string; isPrivate?: boolean }): Promise<Project> {
    const res = await fetch(`${API_BASE}/projects`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });
    return this.handleResponse(res);
  }

  async getProject(projectId: string): Promise<Project> {
    const res = await fetch(`${API_BASE}/projects/${projectId}`, {
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  async updateProject(projectId: string, data: Partial<Project>): Promise<Project> {
    const res = await fetch(`${API_BASE}/projects/${projectId}`, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });
    return this.handleResponse(res);
  }

  async deleteProject(projectId: string): Promise<{ message: string }> {
    const res = await fetch(`${API_BASE}/projects/${projectId}`, {
      method: 'DELETE',
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  async inviteMember(projectId: string, email: string, role: string = 'MEMBER'): Promise<{ invitation: Invitation; inviteUrl?: string; emailSent?: boolean; emailReason?: string; message: string }> {
    const res = await fetch(`${API_BASE}/projects/${projectId}/invitations`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ email, role }),
    });
    return this.handleResponse(res);
  }

  async cancelInvitation(projectId: string, invitationId: string): Promise<{ message: string }> {
    const res = await fetch(`${API_BASE}/projects/${projectId}/invitations/${invitationId}`, {
      method: 'DELETE',
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  async getInvitationByToken(token: string): Promise<any> {
    const res = await fetch(`${API_BASE}/projects/invitations/by-token/${token}`);
    return this.handleResponse(res);
  }

  async acceptInvitationByToken(token: string): Promise<{ message: string; projectId: string }> {
    const res = await fetch(`${API_BASE}/projects/invitations/accept-by-token`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ token }),
    });
    return this.handleResponse(res);
  }

  async getInvitations(projectId: string): Promise<Invitation[]> {
    const res = await fetch(`${API_BASE}/projects/${projectId}/invitations`, {
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  async acceptInvitation(invitationId: string): Promise<{ message: string; projectId: string }> {
    const res = await fetch(`${API_BASE}/projects/invitations/${invitationId}/accept`, {
      method: 'POST',
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  async declineInvitation(invitationId: string): Promise<{ message: string }> {
    const res = await fetch(`${API_BASE}/projects/invitations/${invitationId}/decline`, {
      method: 'POST',
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  async updateMemberRole(projectId: string, memberId: string, role: string): Promise<any> {
    const res = await fetch(`${API_BASE}/projects/${projectId}/members/${memberId}`, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: JSON.stringify({ role }),
    });
    return this.handleResponse(res);
  }

  async removeMember(projectId: string, memberId: string): Promise<{ message: string }> {
    const res = await fetch(`${API_BASE}/projects/${projectId}/members/${memberId}`, {
      method: 'DELETE',
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  // --- Board & List Endpoints ---
  async getBoard(projectId: string): Promise<Board> {
    const res = await fetch(`${API_BASE}/projects/${projectId}/board`, {
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  async createList(projectId: string, name: string): Promise<List> {
    const res = await fetch(`${API_BASE}/projects/${projectId}/board/lists`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ name }),
    });
    return this.handleResponse(res);
  }

  async updateList(projectId: string, listId: string, data: { name?: string; position?: number }): Promise<List> {
    const res = await fetch(`${API_BASE}/projects/${projectId}/board/lists/${listId}`, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });
    return this.handleResponse(res);
  }

  async deleteList(projectId: string, listId: string): Promise<{ message: string }> {
    const res = await fetch(`${API_BASE}/projects/${projectId}/board/lists/${listId}`, {
      method: 'DELETE',
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  async populateBoardPresets(projectId: string, templateId?: string): Promise<Board> {
    const res = await fetch(`${API_BASE}/projects/${projectId}/board/populate-presets`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ templateId }),
    });
    return this.handleResponse(res);
  }

  // --- Task Endpoints ---
  async createTask(listId: string, data: {
    title: string;
    description?: string;
    priority?: string;
    dueDate?: string;
    assigneeIds?: string[];
    labelIds?: string[];
    checklists?: string[];
  }): Promise<Task> {
    const res = await fetch(`${API_BASE}/lists/${listId}/tasks`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });
    return this.handleResponse(res);
  }

  async getTask(taskId: string): Promise<Task> {
    const res = await fetch(`${API_BASE}/tasks/${taskId}`, {
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  async updateTask(taskId: string, data: Partial<Task>): Promise<Task> {
    const res = await fetch(`${API_BASE}/tasks/${taskId}`, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });
    return this.handleResponse(res);
  }

  async moveTask(taskId: string, targetListId: string, newPosition: number): Promise<Task> {
    const res = await fetch(`${API_BASE}/tasks/${taskId}/move`, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: JSON.stringify({ targetListId, newPosition }),
    });
    return this.handleResponse(res);
  }

  async deleteTask(taskId: string): Promise<{ message: string }> {
    const res = await fetch(`${API_BASE}/tasks/${taskId}`, {
      method: 'DELETE',
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  async toggleAssignee(taskId: string, targetUserId: string): Promise<any> {
    const res = await fetch(`${API_BASE}/tasks/${taskId}/assignees`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ targetUserId }),
    });
    return this.handleResponse(res);
  }

  async toggleLabel(taskId: string, labelId: string): Promise<any> {
    const res = await fetch(`${API_BASE}/tasks/${taskId}/labels`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ labelId }),
    });
    return this.handleResponse(res);
  }

  // --- Checklists ---
  async createChecklist(taskId: string, title?: string): Promise<Checklist> {
    const res = await fetch(`${API_BASE}/tasks/${taskId}/checklists`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ title }),
    });
    return this.handleResponse(res);
  }

  async createChecklistItem(checklistId: string, text: string): Promise<ChecklistItem> {
    const res = await fetch(`${API_BASE}/checklists/${checklistId}/items`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ text }),
    });
    return this.handleResponse(res);
  }

  async updateChecklistItem(itemId: string, data: { completed?: boolean; text?: string }): Promise<ChecklistItem> {
    const res = await fetch(`${API_BASE}/checklist-items/${itemId}`, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });
    return this.handleResponse(res);
  }

  async deleteChecklistItem(itemId: string): Promise<{ message: string }> {
    const res = await fetch(`${API_BASE}/checklist-items/${itemId}`, {
      method: 'DELETE',
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  // --- Attachments ---
  async addAttachment(taskId: string, data: { fileName: string; fileUrl: string; fileSize?: number }): Promise<Attachment> {
    const res = await fetch(`${API_BASE}/tasks/${taskId}/attachments`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });
    return this.handleResponse(res);
  }

  async deleteAttachment(attachmentId: string): Promise<{ message: string }> {
    const res = await fetch(`${API_BASE}/attachments/${attachmentId}`, {
      method: 'DELETE',
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  // --- Comments ---
  async createComment(taskId: string, body: string): Promise<Comment> {
    const res = await fetch(`${API_BASE}/tasks/${taskId}/comments`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ body }),
    });
    return this.handleResponse(res);
  }

  async updateComment(commentId: string, body: string): Promise<Comment> {
    const res = await fetch(`${API_BASE}/comments/${commentId}`, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: JSON.stringify({ body }),
    });
    return this.handleResponse(res);
  }

  async deleteComment(commentId: string): Promise<{ message: string }> {
    const res = await fetch(`${API_BASE}/comments/${commentId}`, {
      method: 'DELETE',
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  async toggleReaction(commentId: string, emoji: string): Promise<Comment> {
    const res = await fetch(`${API_BASE}/comments/${commentId}/reaction`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ emoji }),
    });
    return this.handleResponse(res);
  }

  // --- Notifications ---
  async getNotifications(): Promise<{ notifications: Notification[]; unreadCount: number }> {
    const res = await fetch(`${API_BASE}/notifications`, {
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  async markNotificationRead(notificationId: string): Promise<Notification> {
    const res = await fetch(`${API_BASE}/notifications/${notificationId}/read`, {
      method: 'PATCH',
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  async markAllNotificationsRead(): Promise<{ message: string }> {
    const res = await fetch(`${API_BASE}/notifications/read-all`, {
      method: 'PATCH',
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  // --- Activities & Search ---
  async getActivities(): Promise<Activity[]> {
    const res = await fetch(`${API_BASE}/activities`, {
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  async getProjectActivities(projectId: string): Promise<Activity[]> {
    const res = await fetch(`${API_BASE}/activities/project/${projectId}`, {
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }

  async search(query: string): Promise<{ projects: any[]; tasks: any[] }> {
    const res = await fetch(`${API_BASE}/search?q=${encodeURIComponent(query)}`, {
      headers: this.getHeaders(),
    });
    return this.handleResponse(res);
  }
}

export const api = new ApiService();
export default api;
