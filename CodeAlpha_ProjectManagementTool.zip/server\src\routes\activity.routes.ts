import { Router, Response } from 'express';
import prisma from '../prisma.js';
import { authenticate } from '../middleware/auth.js';
import { AuthRequest } from '../types/index.js';

const router = Router();

// GET /activities - Recent activities for current user's projects (for dashboard feed)
router.get('/', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.userId;

    const userProjects = await prisma.projectMember.findMany({
      where: { userId },
      select: { projectId: true },
    });

    const projectIds = userProjects.map((p) => p.projectId);

    const activities = await prisma.activity.findMany({
      where: { projectId: { in: projectIds } },
      orderBy: { createdAt: 'desc' },
      take: 25,
      include: {
        actor: { select: { id: true, name: true, avatarUrl: true } },
        project: { select: { id: true, name: true, color: true } },
        task: { select: { id: true, title: true } },
      },
    });

    res.json(activities);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch activities.' });
  }
});

// GET /projects/:projectId/activities
router.get('/project/:projectId', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { projectId } = req.params;
    const activities = await prisma.activity.findMany({
      where: { projectId },
      orderBy: { createdAt: 'desc' },
      take: 50,
      include: {
        actor: { select: { id: true, name: true, avatarUrl: true } },
        task: { select: { id: true, title: true } },
      },
    });

    res.json(activities);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch project activities.' });
  }
});

// GET /search - Search across projects and tasks
router.get('/search', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.userId;
    const query = (req.query.q as string || '').trim().toLowerCase();

    if (!query) {
      res.json({ projects: [], tasks: [] });
      return;
    }

    const userProjects = await prisma.projectMember.findMany({
      where: { userId },
      select: { projectId: true },
    });
    const projectIds = userProjects.map((p) => p.projectId);

    // Search matching projects
    const matchedProjects = await prisma.project.findMany({
      where: {
        id: { in: projectIds },
        OR: [
          { name: { contains: query } },
          { description: { contains: query } },
        ],
      },
      select: {
        id: true,
        name: true,
        description: true,
        color: true,
        icon: true,
      },
      take: 5,
    });

    // Search matching tasks
    const matchedTasks = await prisma.task.findMany({
      where: {
        list: { board: { projectId: { in: projectIds } } },
        archived: false,
        OR: [
          { title: { contains: query } },
          { description: { contains: query } },
        ],
      },
      include: {
        list: {
          include: {
            board: {
              include: {
                project: { select: { id: true, name: true, color: true } },
              },
            },
          },
        },
        assignees: { include: { user: { select: { name: true, avatarUrl: true } } } },
      },
      take: 10,
    });

    res.json({
      projects: matchedProjects,
      tasks: matchedTasks.map((t) => ({
        id: t.id,
        title: t.title,
        priority: t.priority,
        dueDate: t.dueDate,
        listName: t.list.name,
        projectName: t.list.board.project.name,
        projectId: t.list.board.project.id,
        assignees: t.assignees.map((a) => a.user),
      })),
    });
  } catch (error) {
    console.error('Search error:', error);
    res.status(500).json({ message: 'Search failed.' });
  }
});

export default router;
