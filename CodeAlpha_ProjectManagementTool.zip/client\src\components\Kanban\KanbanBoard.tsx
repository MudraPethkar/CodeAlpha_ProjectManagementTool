import React, { useState, useEffect } from 'react';
import {
  Plus,
  Search,
  Filter,
  CheckCircle2,
  User,
  Tag,
  Sparkles,
  Zap,
  Layers,
  X,
  Code,
  Rocket,
  Shield,
  HelpCircle,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Board, List, Task, Project } from '../../types';
import { KanbanColumn } from './KanbanColumn';
import { useSocket } from '../../context/SocketContext';
import { useAuth } from '../../context/AuthContext';
import api from '../../services/api';
import { WORKFLOW_BUNDLES, WorkflowBundle } from '../../data/cardTemplates';

interface KanbanBoardProps {
  project: Project;
  board: Board;
  onSelectTask: (task: Task) => void;
  onRefreshBoard: () => void;
}

export const KanbanBoard: React.FC<KanbanBoardProps> = ({
  project,
  board,
  onSelectTask,
  onRefreshBoard,
}) => {
  const { user } = useAuth();
  const { socket, joinProject, leaveProject } = useSocket();
  const [lists, setLists] = useState<List[]>(board.lists);
  const [draggedTask, setDraggedTask] = useState<Task | null>(null);
  const [isAddingList, setIsAddingList] = useState(false);
  const [newListName, setNewListName] = useState('');

  // Workflow preset population states
  const [isPopulatingPresets, setIsPopulatingPresets] = useState(false);
  const [showBundlePicker, setShowBundlePicker] = useState(false);
  const [dismissEmptyBanner, setDismissEmptyBanner] = useState(false);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<string>('ALL');
  const [assigneeFilter, setAssigneeFilter] = useState<string>('ALL');

  // Keep local state in sync when board prop changes
  useEffect(() => {
    setLists(board.lists);
  }, [board]);

  // Join project room for WebSocket updates
  useEffect(() => {
    joinProject(project.id);

    if (!socket) return;

    const handleTaskCreated = ({ task, listId }: { task: Task; listId: string }) => {
      setLists((prev) =>
        prev.map((list) => {
          if (list.id === listId) {
            if (list.tasks.some((t) => t.id === task.id)) return list;
            return { ...list, tasks: [...list.tasks, task] };
          }
          return list;
        })
      );
    };

    const handleTaskUpdated = ({ task }: { task: Task }) => {
      setLists((prev) =>
        prev.map((list) => ({
          ...list,
          tasks: list.tasks.map((t) => (t.id === task.id ? { ...t, ...task } : t)),
        }))
      );
    };

    const handleTaskMoved = ({
      task,
      fromListId,
      toListId,
    }: {
      task: Task;
      fromListId: string;
      toListId: string;
    }) => {
      setLists((prev) => {
        if (fromListId === toListId) {
          return prev.map((l) =>
            l.id === toListId
              ? { ...l, tasks: l.tasks.map((t) => (t.id === task.id ? task : t)) }
              : l
          );
        }
        return prev.map((l) => {
          if (l.id === fromListId) {
            return { ...l, tasks: l.tasks.filter((t) => t.id !== task.id) };
          }
          if (l.id === toListId) {
            if (l.tasks.some((t) => t.id === task.id)) return l;
            return { ...l, tasks: [...l.tasks, task] };
          }
          return l;
        });
      });
    };

    const handleTaskDeleted = ({ taskId, listId }: { taskId: string; listId: string }) => {
      setLists((prev) =>
        prev.map((l) =>
          l.id === listId ? { ...l, tasks: l.tasks.filter((t) => t.id !== taskId) } : l
        )
      );
    };

    const handleListCreated = (newList: List) => {
      setLists((prev) => {
        if (prev.some((l) => l.id === newList.id)) return prev;
        return [...prev, newList];
      });
    };

    const handleListUpdated = (updatedList: List) => {
      setLists((prev) =>
        prev.map((l) => (l.id === updatedList.id ? { ...l, name: updatedList.name } : l))
      );
    };

    const handleListDeleted = ({ listId }: { listId: string }) => {
      setLists((prev) => prev.filter((l) => l.id !== listId));
    };

    const handleBoardUpdated = (updatedBoard: Board) => {
      if (updatedBoard && updatedBoard.lists) {
        setLists(updatedBoard.lists);
      }
    };

    socket.on('task:created', handleTaskCreated);
    socket.on('task:updated', handleTaskUpdated);
    socket.on('task:moved', handleTaskMoved);
    socket.on('task:deleted', handleTaskDeleted);
    socket.on('list:created', handleListCreated);
    socket.on('list:updated', handleListUpdated);
    socket.on('list:deleted', handleListDeleted);
    socket.on('board:updated', handleBoardUpdated);

    return () => {
      leaveProject(project.id);
      socket.off('task:created', handleTaskCreated);
      socket.off('task:updated', handleTaskUpdated);
      socket.off('task:moved', handleTaskMoved);
      socket.off('task:deleted', handleTaskDeleted);
      socket.off('list:created', handleListCreated);
      socket.off('list:updated', handleListUpdated);
      socket.off('list:deleted', handleListDeleted);
      socket.off('board:updated', handleBoardUpdated);
    };
  }, [project.id, socket]);

  // Drag & Drop Handlers
  const handleDragStart = (e: React.DragEvent, task: Task) => {
    setDraggedTask(task);
    e.dataTransfer.setData('text/plain', task.id);
  };

  const handleDropTask = async (targetListId: string) => {
    if (!draggedTask) return;
    const sourceListId = draggedTask.listId;
    if (sourceListId === targetListId) {
      setDraggedTask(null);
      return;
    }

    const targetList = lists.find((l) => l.id === targetListId);
    const movingToDone = targetList?.name.toLowerCase() === 'done';

    if (movingToDone) {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#A3E635', '#D9F99D', '#20242C', '#38BDF8'],
      });
    }

    // Optimistic UI Update
    const taskToMove = { ...draggedTask, listId: targetListId };
    setLists((prev) =>
      prev.map((l) => {
        if (l.id === sourceListId) {
          return { ...l, tasks: l.tasks.filter((t) => t.id !== draggedTask.id) };
        }
        if (l.id === targetListId) {
          return { ...l, tasks: [...l.tasks, taskToMove] };
        }
        return l;
      })
    );

    setDraggedTask(null);

    try {
      await api.moveTask(draggedTask.id, targetListId, 0);
    } catch (error) {
      console.error('Failed to move task:', error);
      onRefreshBoard();
    }
  };

  // Populate Board Preset Handler
  const handlePopulatePresets = async (templateId: string = 'fullstack') => {
    setIsPopulatingPresets(true);
    try {
      const updatedBoard = await api.populateBoardPresets(project.id, templateId);
      setLists(updatedBoard.lists);
      confetti({
        particleCount: 120,
        spread: 70,
        origin: { y: 0.5 },
        colors: ['#A3E635', '#D9F99D', '#20242C', '#38BDF8'],
      });
      setShowBundlePicker(false);
      setDismissEmptyBanner(true);
    } catch (err: any) {
      console.error('Failed to populate presets:', err);
      alert(err.message || 'Failed to populate card options. Please try again.');
    } finally {
      setIsPopulatingPresets(false);
    }
  };

  // List Management
  const handleCreateList = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newListName.trim()) return;
    try {
      const newList = await api.createList(project.id, newListName.trim());
      setLists((prev) => [...prev, newList]);
      setNewListName('');
      setIsAddingList(false);
    } catch (error) {
      console.error('Failed to create list:', error);
    }
  };

  const handleRenameList = async (listId: string, newName: string) => {
    try {
      await api.updateList(project.id, listId, { name: newName });
      setLists((prev) =>
        prev.map((l) => (l.id === listId ? { ...l, name: newName } : l))
      );
    } catch (error) {
      console.error('Failed to rename list:', error);
    }
  };

  const handleDeleteList = async (listId: string) => {
    if (!confirm('Are you sure you want to delete this list and all its tasks?')) return;
    try {
      await api.deleteList(project.id, listId);
      setLists((prev) => prev.filter((l) => l.id !== listId));
    } catch (error) {
      console.error('Failed to delete list:', error);
    }
  };

  const handleCreateTask = async (
    listId: string,
    taskData:
      | { title: string; description?: string; priority?: string; checklists?: string[]; assigneeIds?: string[] }
      | string
  ) => {
    try {
      const basePayload = typeof taskData === 'string' ? { title: taskData } : taskData;
      const payload = {
        ...basePayload,
        assigneeIds:
          basePayload.assigneeIds && basePayload.assigneeIds.length > 0
            ? basePayload.assigneeIds
            : user?.id
            ? [user.id]
            : undefined,
      };
      const newTask = await api.createTask(listId, payload);
      setLists((prev) =>
        prev.map((l) => (l.id === listId ? { ...l, tasks: [...l.tasks, newTask] } : l))
      );
    } catch (error: any) {
      console.error('Failed to create task:', error);
      alert(error.message || 'Failed to create task. Please try again.');
    }
  };

  // Filter Tasks
  const filteredLists = lists.map((list) => {
    const filteredTasks = list.tasks.filter((task) => {
      // Search
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = task.title.toLowerCase().includes(query);
        const matchesDesc = task.description?.toLowerCase().includes(query);
        if (!matchesTitle && !matchesDesc) return false;
      }
      // Priority
      if (priorityFilter !== 'ALL' && task.priority !== priorityFilter) {
        return false;
      }
      // Assignee
      if (assigneeFilter !== 'ALL') {
        const hasAssignee = task.assignees?.some((a) => a.userId === assigneeFilter);
        if (!hasAssignee) return false;
      }
      return true;
    });

    return {
      ...list,
      tasks: filteredTasks,
    };
  });

  const totalTasksCount = lists.reduce((acc, l) => acc + l.tasks.length, 0);

  return (
    <div className="flex-1 flex flex-col h-full bg-[#F9FAFB] overflow-hidden relative">
      {/* Board Controls & Filter Bar */}
      <div className="bg-white border-b border-[#E5E7EB] px-6 py-3 flex flex-wrap items-center justify-between gap-3">
        {/* Left: Search, Filters & Card Presets Button */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Search inside board */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter tasks..."
              className="text-xs bg-[#F9FAFB] border border-[#E5E7EB] focus:border-[#A3E635] rounded-lg pl-8 pr-3 py-1.5 focus:outline-none w-44 transition-all"
            />
          </div>

          {/* Priority filter */}
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="text-xs bg-[#F9FAFB] border border-[#E5E7EB] text-gray-700 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-[#A3E635]"
          >
            <option value="ALL">All Priorities</option>
            <option value="URGENT">Urgent</option>
            <option value="HIGH">High</option>
            <option value="MEDIUM">Medium</option>
            <option value="LOW">Low</option>
          </select>

          {/* Assignee filter */}
          {project.members && project.members.length > 0 && (
            <select
              value={assigneeFilter}
              onChange={(e) => setAssigneeFilter(e.target.value)}
              className="text-xs bg-[#F9FAFB] border border-[#E5E7EB] text-gray-700 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-[#A3E635]"
            >
              <option value="ALL">All Assignees</option>
              {project.members.map((m) => (
                <option key={m.userId} value={m.userId}>
                  {m.user.name}
                </option>
              ))}
            </select>
          )}

          {/* Section Options / Preset Bundles Button */}
          <button
            onClick={() => setShowBundlePicker(true)}
            className="text-xs font-bold px-3 py-1.5 rounded-lg bg-[#A3E635]/20 hover:bg-[#A3E635]/35 text-lime-900 border border-[#A3E635]/60 flex items-center gap-1.5 transition-all shadow-2xs"
            title="Choose ready-made card options for all project sections"
          >
            <Sparkles className="w-3.5 h-3.5 text-lime-700" />
            <span>Card Options & Presets</span>
          </button>

          {(searchQuery || priorityFilter !== 'ALL' || assigneeFilter !== 'ALL') && (
            <button
              onClick={() => {
                setSearchQuery('');
                setPriorityFilter('ALL');
                setAssigneeFilter('ALL');
              }}
              className="text-xs text-rose-500 hover:underline font-medium"
            >
              Reset filters
            </button>
          )}
        </div>

        {/* Right: Board Stats */}
        <div className="hidden sm:flex items-center space-x-4 text-xs text-gray-500 font-medium">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#A3E635]" />
            {totalTasksCount} Total Tasks
          </span>
          <span className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#A3E635]" />
            {lists.find((l) => l.name.toLowerCase() === 'done')?.tasks.length || 0} Done
          </span>
        </div>
      </div>

      {/* Empty Board Banner - 1-Click Multi-Section Card Population */}
      {totalTasksCount === 0 && !dismissEmptyBanner && (
        <div className="mx-6 mt-4 p-4 rounded-2xl bg-[#20242C] text-white border border-[#2D333F] shadow-md flex flex-wrap items-center justify-between gap-3 animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="flex items-center space-x-3.5">
            <div className="w-10 h-10 rounded-xl bg-[#A3E635] text-[#20242C] flex items-center justify-center font-black shadow-xs">
              <Zap className="w-5 h-5 fill-[#20242C]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="font-extrabold text-sm text-white">
                  Add Card Options to All Project Sections
                </h4>
                <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#A3E635] text-[#20242C]">
                  1-Click
                </span>
              </div>
              <p className="text-xs text-gray-300 mt-0.5">
                Skip typing manually! Instantly populate Backlog, To Do, In Progress, Review, and Done with structured cards.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => handlePopulatePresets('fullstack')}
              disabled={isPopulatingPresets}
              className="px-4 py-2 rounded-xl bg-[#A3E635] hover:bg-[#8dd321] text-[#20242C] font-extrabold text-xs flex items-center space-x-1.5 shadow-sm transition-all"
            >
              <Sparkles className="w-3.5 h-3.5 fill-[#20242C]" />
              <span>{isPopulatingPresets ? 'Populating...' : 'Auto-Fill Cards Now'}</span>
            </button>
            <button
              onClick={() => setShowBundlePicker(true)}
              className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition-colors"
            >
              More Workflows ▾
            </button>
            <button
              onClick={() => setDismissEmptyBanner(true)}
              className="p-2 text-gray-400 hover:text-white rounded-lg transition-colors"
              title="Dismiss"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Horizontal Kanban Columns Container */}
      <div className="flex-1 overflow-x-auto p-6 flex items-start space-x-5">
        {filteredLists.map((list) => (
          <KanbanColumn
            key={list.id}
            list={list}
            onSelectTask={onSelectTask}
            onDragStart={handleDragStart}
            onDropTask={handleDropTask}
            onCreateTask={handleCreateTask}
            onRenameList={handleRenameList}
            onDeleteList={handleDeleteList}
          />
        ))}

        {/* Add List Column Button / Input */}
        <div className="w-72 sm:w-80 flex-shrink-0">
          {isAddingList ? (
            <form
              onSubmit={handleCreateList}
              className="bg-[#F3F4F6] rounded-2xl p-3 border border-[#A3E635] shadow-xs space-y-2.5"
            >
              <input
                type="text"
                value={newListName}
                onChange={(e) => setNewListName(e.target.value)}
                placeholder="Column name (e.g. QA, Blocked)..."
                className="w-full text-xs font-bold px-3 py-2 bg-white border border-[#E5E7EB] rounded-xl focus:outline-none focus:border-[#A3E635]"
                autoFocus
              />
              <div className="flex space-x-2">
                <button
                  type="submit"
                  disabled={!newListName.trim()}
                  className="bg-[#A3E635] hover:bg-[#8dd321] text-[#20242C] font-bold text-xs px-3.5 py-1.5 rounded-lg disabled:opacity-50 transition-colors"
                >
                  Create Column
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setIsAddingList(false);
                    setNewListName('');
                  }}
                  className="text-gray-500 hover:text-gray-700 text-xs px-2 py-1.5"
                >
                  Cancel
                </button>
              </div>
            </form>
          ) : (
            <button
              onClick={() => setIsAddingList(true)}
              className="w-full h-12 rounded-2xl border-2 border-dashed border-gray-300 hover:border-[#A3E635] hover:bg-[#A3E635]/5 text-gray-500 hover:text-[#20242C] flex items-center justify-center space-x-2 text-xs font-bold transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Add Column</span>
            </button>
          )}
        </div>
      </div>

      {/* Workflow Bundles Modal Dialog */}
      {showBundlePicker && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setShowBundlePicker(false)}
        >
          <div
            className="bg-white rounded-3xl w-full max-w-xl shadow-2xl border border-gray-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="px-6 py-4 bg-[#20242C] text-white flex items-center justify-between border-b border-[#2D333F]">
              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-xl bg-[#A3E635] flex items-center justify-center text-[#20242C]">
                  <Layers className="w-4 h-4 stroke-[2.5]" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base tracking-tight">
                    Populate Cards for All Sections
                  </h3>
                  <p className="text-[11px] text-gray-400">
                    Choose a workflow bundle to automatically add ready cards to Backlog, To Do, In Progress, Review, and Done.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowBundlePicker(false)}
                className="p-1 rounded-lg text-gray-400 hover:text-white hover:bg-[#2D333F] transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Bundles List */}
            <div className="p-6 space-y-3.5 max-h-[70vh] overflow-y-auto">
              {WORKFLOW_BUNDLES.map((bundle) => (
                <div
                  key={bundle.id}
                  className="p-4 rounded-2xl border-2 border-gray-100 hover:border-[#A3E635] bg-gray-50/60 hover:bg-[#A3E635]/5 transition-all flex flex-col space-y-3"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-extrabold text-sm text-[#20242C] flex items-center gap-2">
                        {bundle.name}
                      </h4>
                      <p className="text-xs text-gray-500 mt-0.5">{bundle.description}</p>
                    </div>
                    <button
                      onClick={() => handlePopulatePresets(bundle.id)}
                      disabled={isPopulatingPresets}
                      className="px-4 py-2 rounded-xl bg-[#A3E635] hover:bg-[#8dd321] text-[#20242C] font-extrabold text-xs flex items-center space-x-1.5 shadow-2xs transition-all shrink-0"
                    >
                      <Zap className="w-3.5 h-3.5 fill-[#20242C]" />
                      <span>{isPopulatingPresets ? 'Adding...' : 'Apply Cards'}</span>
                    </button>
                  </div>

                  {/* Preview Cards */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 pt-1 border-t border-gray-200/60">
                    {bundle.cards.slice(0, 5).map((c, i) => (
                      <div
                        key={i}
                        className="p-1.5 rounded-lg bg-white border border-gray-200 text-[10px]"
                      >
                        <span className="font-extrabold uppercase text-[9px] text-gray-400 block">
                          {c.section.replace('_', ' ')}
                        </span>
                        <span className="font-bold text-[#20242C] line-clamp-1">{c.title}</span>
                      </div>
                    ))}
                    {bundle.cards.length > 5 && (
                      <div className="p-1.5 rounded-lg bg-white border border-dashed border-gray-300 text-[10px] text-gray-400 flex items-center justify-center font-bold">
                        +{bundle.cards.length - 5} more cards
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-3.5 bg-gray-50 border-t border-gray-100 flex items-center justify-between text-xs text-gray-500">
              <span>💡 You can also add cards individually from each column's "Card Options" button.</span>
              <button
                onClick={() => setShowBundlePicker(false)}
                className="px-3.5 py-1.5 rounded-lg font-bold text-gray-600 hover:text-gray-900"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
