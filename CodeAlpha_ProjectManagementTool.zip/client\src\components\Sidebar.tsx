import React from 'react';
import {
  LayoutDashboard,
  FolderKanban,
  Activity,
  Plus,
  Circle,
  Users,
  ChevronRight,
} from 'lucide-react';
import { Project, PresenceUser } from '../types';

interface SidebarProps {
  currentView: 'dashboard' | 'projects' | 'board' | 'activity';
  projects: Project[];
  selectedProjectId: string | null;
  onlineUsers: PresenceUser[];
  onSelectView: (view: 'dashboard' | 'projects' | 'activity') => void;
  onSelectProject: (projectId: string) => void;
  onOpenCreateProject: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  projects,
  selectedProjectId,
  onlineUsers,
  onSelectView,
  onSelectProject,
  onOpenCreateProject,
}) => {
  return (
    <aside className="w-64 bg-[#20242C] text-gray-300 border-r border-[#2D333F] flex flex-col h-[calc(100vh-4rem)] select-none">
      {/* Main Nav Links */}
      <div className="p-3 space-y-1">
        <button
          onClick={() => onSelectView('dashboard')}
          className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
            currentView === 'dashboard'
              ? 'bg-[#2D333F] text-[#A3E635]'
              : 'hover:bg-[#282D37] text-gray-300 hover:text-white'
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span>Dashboard</span>
        </button>

        <button
          onClick={() => onSelectView('projects')}
          className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
            currentView === 'projects'
              ? 'bg-[#2D333F] text-[#A3E635]'
              : 'hover:bg-[#282D37] text-gray-300 hover:text-white'
          }`}
        >
          <FolderKanban className="w-4 h-4" />
          <span>All Projects</span>
        </button>

        <button
          onClick={() => onSelectView('activity')}
          className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
            currentView === 'activity'
              ? 'bg-[#2D333F] text-[#A3E635]'
              : 'hover:bg-[#282D37] text-gray-300 hover:text-white'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Activity Stream</span>
        </button>
      </div>

      {/* Projects List Section */}
      <div className="flex-1 overflow-y-auto px-3 py-2">
        <div className="flex items-center justify-between px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-gray-400">
          <span>Active Projects ({projects.length})</span>
          <button
            onClick={onOpenCreateProject}
            className="p-1 hover:text-[#A3E635] hover:bg-[#2D333F] rounded transition-colors"
            title="Create Project"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="mt-1 space-y-0.5">
          {projects.map((p) => {
            const isSelected = currentView === 'board' && selectedProjectId === p.id;
            return (
              <button
                key={p.id}
                onClick={() => onSelectProject(p.id)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors group ${
                  isSelected
                    ? 'bg-[#2D333F] text-white font-semibold border-l-2 border-[#A3E635]'
                    : 'text-gray-300 hover:bg-[#282D37] hover:text-white'
                }`}
              >
                <div className="flex items-center space-x-2.5 truncate">
                  <span
                    className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                    style={{ backgroundColor: p.color || '#A3E635' }}
                  />
                  <span className="truncate">{p.name}</span>
                </div>
                <ChevronRight
                  className={`w-3.5 h-3.5 text-gray-500 opacity-0 group-hover:opacity-100 transition-opacity ${
                    isSelected ? 'opacity-100 text-[#A3E635]' : ''
                  }`}
                />
              </button>
            );
          })}

          {projects.length === 0 && (
            <div className="px-3 py-4 text-center text-xs text-gray-500">
              No projects yet. Click + to create one!
            </div>
          )}
        </div>
      </div>

      {/* Real-time Online Team Section */}
      <div className="p-3 border-t border-[#2D333F] bg-[#181B21]/60">
        <div className="flex items-center justify-between text-xs text-gray-400 mb-2 font-medium">
          <span className="flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 text-[#A3E635]" />
            Live Presence
          </span>
          <span className="inline-flex items-center gap-1 text-[11px] text-[#A3E635]">
            <Circle className="w-2 h-2 fill-[#A3E635]" />
            {onlineUsers.length} Online
          </span>
        </div>

        <div className="flex items-center space-x-1.5 overflow-x-auto py-1">
          {onlineUsers.map((u, i) => (
            <div key={i} className="relative group flex-shrink-0" title={u.name}>
              <img
                src={u.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${u.name}`}
                alt={u.name}
                className="w-7 h-7 rounded-full object-cover border-2 border-[#A3E635]"
              />
              <span className="absolute bottom-0 right-0 w-2 h-2 bg-[#A3E635] rounded-full ring-1 ring-[#20242C]" />
            </div>
          ))}
          {onlineUsers.length === 0 && (
            <span className="text-[11px] text-gray-500 italic">No teammates connected to this room</span>
          )}
        </div>
      </div>
    </aside>
  );
};
