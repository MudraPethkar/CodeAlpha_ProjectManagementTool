export interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string | null;
  role: string;
  bio?: string | null;
  createdAt: string;
}

export interface ProjectMember {
  id: string;
  projectId: string;
  userId: string;
  role: 'OWNER' | 'ADMIN' | 'MEMBER';
  joinedAt: string;
  user: User;
}

export interface Invitation {
  id: string;
  projectId: string;
  email: string;
  token: string;
  role: string;
  status: 'PENDING' | 'ACCEPTED' | 'DECLINED';
  expiresAt: string;
  createdAt: string;
}

export interface Label {
  id: string;
  projectId: string;
  name: string;
  color: string;
}

export interface ChecklistItem {
  id: string;
  checklistId: string;
  text: string;
  completed: boolean;
  position: number;
  createdAt: string;
}

export interface Checklist {
  id: string;
  taskId: string;
  title: string;
  position: number;
  createdAt: string;
  items: ChecklistItem[];
}

export interface Attachment {
  id: string;
  taskId: string;
  fileName: string;
  fileUrl: string;
  fileSize?: number | null;
  uploadedBy: string;
  createdAt: string;
  uploader?: {
    id: string;
    name: string;
  };
}

export interface Comment {
  id: string;
  taskId: string;
  authorId: string;
  body: string;
  edited: boolean;
  reactions?: string | null; // JSON string e.g. {"👍": ["userId1"]}
  createdAt: string;
  updatedAt: string;
  author: User;
}

export interface Task {
  id: string;
  listId: string;
  title: string;
  description?: string | null;
  position: number;
  dueDate?: string | null;
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
  status?: string | null;
  createdById: string;
  archived: boolean;
  createdAt: string;
  updatedAt: string;
  list?: {
    id: string;
    name: string;
  };
  creator?: User;
  assignees: {
    id: string;
    userId: string;
    user: User;
  }[];
  labels: {
    id: string;
    labelId: string;
    label: Label;
  }[];
  checklists?: Checklist[];
  attachments?: Attachment[];
  comments?: { id: string }[] | Comment[];
  activities?: Activity[];
}

export interface List {
  id: string;
  boardId: string;
  name: string;
  position: number;
  createdAt: string;
  updatedAt: string;
  tasks: Task[];
}

export interface Board {
  id: string;
  projectId: string;
  name: string;
  position: number;
  createdAt: string;
  updatedAt: string;
  lists: List[];
}

export interface Project {
  id: string;
  name: string;
  description?: string | null;
  color: string;
  icon: string;
  isPrivate: boolean;
  archived: boolean;
  createdAt: string;
  updatedAt: string;
  owner?: User;
  memberCount?: number;
  members?: ProjectMember[];
  labels?: Label[];
  invitations?: Invitation[];
  totalTasks?: number;
  completedTasks?: number;
  progressPercent?: number;
  currentUserRole?: 'OWNER' | 'ADMIN' | 'MEMBER';
}

export interface Activity {
  id: string;
  projectId: string;
  taskId?: string | null;
  actorId: string;
  action: string;
  metadata?: string | null;
  createdAt: string;
  actor: {
    id: string;
    name: string;
    avatarUrl?: string | null;
  };
  project?: {
    id: string;
    name: string;
    color: string;
  };
  task?: {
    id: string;
    title: string;
  };
}

export interface Notification {
  id: string;
  userId: string;
  type: 'TASK_ASSIGNED' | 'TASK_DUE_SOON' | 'TASK_OVERDUE' | 'COMMENT_MENTION' | 'PROJECT_INVITE' | 'STATUS_CHANGED';
  title: string;
  body: string;
  resourceType: 'project' | 'task' | 'comment';
  resourceId: string;
  read: boolean;
  createdAt: string;
}

export interface PresenceUser {
  userId: string;
  name: string;
  avatarUrl?: string;
}
