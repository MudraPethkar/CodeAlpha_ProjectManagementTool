import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SocketProvider, useSocket } from './context/SocketContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { LandingPage } from './components/Views/LandingPage';
import { AuthPage } from './components/Views/AuthPage';
import { DashboardView } from './components/Views/DashboardView';
import { ProjectsView } from './components/Views/ProjectsView';
import { ProjectBoardView } from './components/Views/ProjectBoardView';
import { ActivityView } from './components/Views/ActivityView';
import { TaskDetailModal } from './components/TaskModal/TaskDetailModal';
import { CreateProjectModal } from './components/Modals/CreateProjectModal';
import { CreateTaskModal } from './components/Modals/CreateTaskModal';
import { ProjectMembersModal } from './components/Modals/ProjectMembersModal';
import { SearchModal } from './components/Modals/SearchModal';
import { ProfileModal } from './components/Modals/ProfileModal';
import { NotificationPanel } from './components/Notifications/NotificationPanel';
import { Project, Task, Notification } from './types';
import api from './services/api';
import { X, Bell, Mail } from 'lucide-react';

const MainApp: React.FC = () => {
  const { user, isLoading: isAuthLoading } = useAuth();
  const { onlineUsers, latestNotification, clearLatestNotification } = useSocket();

  // Navigation states
  const [currentView, setCurrentView] = useState<'dashboard' | 'projects' | 'board' | 'activity'>('dashboard');
  const [authViewMode, setAuthViewMode] = useState<'landing' | 'auth'>('landing');
  const [authInitialMode, setAuthInitialMode] = useState<'login' | 'register'>('login');

  // Active Project & Task selection
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);

  // Modals
  const [isCreateProjectOpen, setIsCreateProjectOpen] = useState(false);
  const [isCreateTaskOpen, setIsCreateTaskOpen] = useState(false);
  const [isMembersModalOpen, setIsMembersModalOpen] = useState(false);
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [boardRefreshTrigger, setBoardRefreshTrigger] = useState(0);

  // Notifications list
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  // Live Toast state
  const [toastNotification, setToastNotification] = useState<Notification | null>(null);

  // Invite token state
  const [pendingInvite, setPendingInvite] = useState<any | null>(null);
  const [isAcceptingInvite, setIsAcceptingInvite] = useState(false);

  // Check URL for invite token (e.g. ?inviteToken=...)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const token = params.get('inviteToken');
    if (token) {
      api.getInvitationByToken(token)
        .then((data) => {
          setPendingInvite({ ...data, token });
        })
        .catch((err) => {
          console.warn('Invalid invitation token:', err);
        });
    }
  }, []);

  const handleAcceptInvite = async () => {
    if (!pendingInvite) return;
    setIsAcceptingInvite(true);
    try {
      const res = await api.acceptInvitationByToken(pendingInvite.token);
      window.history.replaceState({}, document.title, window.location.pathname);
      setPendingInvite(null);
      await loadProjects();
      setSelectedProjectId(res.projectId);
      setCurrentView('board');
    } catch (err: any) {
      alert(err.message || 'Failed to accept invitation');
    } finally {
      setIsAcceptingInvite(false);
    }
  };

  const handleDismissInvite = () => {
    window.history.replaceState({}, document.title, window.location.pathname);
    setPendingInvite(null);
  };

  // Global Ctrl+K / Cmd+K search shortcut
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchModalOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Fetch Projects & Notifications
  const loadProjects = async () => {
    try {
      const data = await api.getProjects();
      setProjects(data);
      if (data.length > 0 && !selectedProjectId) {
        setSelectedProjectId(data[0].id);
      }
    } catch (err) {
      console.warn('Could not load projects:', err);
    }
  };

  const loadNotifications = async () => {
    try {
      const data = await api.getNotifications();
      setNotifications(data.notifications);
      setUnreadCount(data.unreadCount);
    } catch (err) {
      console.warn('Could not load notifications:', err);
    }
  };

  useEffect(() => {
    if (user) {
      loadProjects();
      loadNotifications();
    }
  }, [user]);

  // Handle incoming live notification toast
  useEffect(() => {
    if (latestNotification) {
      setToastNotification(latestNotification);
      setUnreadCount((c) => c + 1);
      setNotifications((prev) => [latestNotification, ...prev]);

      const timer = setTimeout(() => {
        setToastNotification(null);
        clearLatestNotification();
      }, 5000);

      return () => clearTimeout(timer);
    }
  }, [latestNotification]);

  if (isAuthLoading) {
    return (
      <div className="min-h-screen bg-[#20242C] flex items-center justify-center text-white font-sans">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 border-4 border-[#A3E635] border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs font-bold uppercase tracking-wider text-gray-400">Loading TASKLY...</p>
        </div>
      </div>
    );
  }

  // Guest / Unauthenticated flow
  if (!user) {
    if (authViewMode === 'auth') {
      return (
        <AuthPage
          initialMode={authInitialMode}
          onBackToLanding={() => setAuthViewMode('landing')}
        />
      );
    }

    return (
      <LandingPage
        onGoToAuth={(mode) => {
          setAuthInitialMode(mode);
          setAuthViewMode('auth');
        }}
      />
    );
  }

  const currentProject = projects.find((p) => p.id === selectedProjectId) || null;

  return (
    <div className="min-h-screen bg-[#F9FAFB] flex flex-col font-sans select-none overflow-hidden">
      {/* Top Navbar */}
      <Navbar
        currentProject={currentProject}
        unreadNotificationsCount={unreadCount}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        onOpenSearch={() => setIsSearchModalOpen(true)}
        onOpenCreateProject={() => setIsCreateProjectOpen(true)}
        onOpenCreateTask={() => setIsCreateTaskOpen(true)}
        onOpenProfile={() => setIsProfileModalOpen(true)}
        onNavigateHome={() => setCurrentView('dashboard')}
      />

      {/* Main Workspace: Sidebar + Dynamic View */}
      <div className="flex-1 flex overflow-hidden">
        <Sidebar
          currentView={currentView}
          projects={projects}
          selectedProjectId={selectedProjectId}
          onlineUsers={onlineUsers}
          onSelectView={(view) => setCurrentView(view)}
          onSelectProject={(projectId) => {
            setSelectedProjectId(projectId);
            setCurrentView('board');
          }}
          onOpenCreateProject={() => setIsCreateProjectOpen(true)}
        />

        <main className="flex-1 flex flex-col overflow-hidden bg-[#F9FAFB]">
          {currentView === 'dashboard' && (
            <DashboardView
              projects={projects}
              onSelectProject={(pId) => {
                setSelectedProjectId(pId);
                setCurrentView('board');
              }}
              onOpenCreateProject={() => setIsCreateProjectOpen(true)}
              onOpenCreateTask={() => setIsCreateTaskOpen(true)}
              onSelectTask={(task) => setSelectedTaskId(task.id)}
            />
          )}

          {currentView === 'projects' && (
            <ProjectsView
              projects={projects}
              onSelectProject={(pId) => {
                setSelectedProjectId(pId);
                setCurrentView('board');
              }}
              onOpenCreateProject={() => setIsCreateProjectOpen(true)}
            />
          )}

          {currentView === 'board' && selectedProjectId && (
            <ProjectBoardView
              key={`${selectedProjectId}-${boardRefreshTrigger}`}
              projectId={selectedProjectId}
              onSelectTask={(task) => setSelectedTaskId(task.id)}
              onOpenMembersModal={() => setIsMembersModalOpen(true)}
            />
          )}

          {currentView === 'activity' && <ActivityView />}
        </main>
      </div>

      {/* Live Toast Pop-up Notification */}
      {toastNotification && (
        <div className="fixed bottom-6 right-6 z-50 max-w-sm bg-[#20242C] text-white p-4 rounded-2xl shadow-2xl border border-[#A3E635] flex items-start space-x-3 animate-in slide-in-from-bottom-5 duration-200">
          <div className="p-2 rounded-xl bg-[#A3E635]/20 text-[#A3E635] mt-0.5">
            <Bell className="w-4 h-4" />
          </div>
          <div className="flex-1">
            <h5 className="text-xs font-bold text-white">{toastNotification.title}</h5>
            <p className="text-xs text-gray-400 mt-0.5 leading-snug">{toastNotification.body}</p>
          </div>
          <button
            onClick={() => setToastNotification(null)}
            className="text-gray-400 hover:text-white p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Modals */}
      {selectedTaskId && currentProject && (
        <TaskDetailModal
          taskId={selectedTaskId}
          project={currentProject}
          onClose={() => setSelectedTaskId(null)}
          onTaskUpdated={() => {
            loadProjects();
            setBoardRefreshTrigger((prev) => prev + 1);
          }}
          onTaskDeleted={() => {
            setSelectedTaskId(null);
            loadProjects();
            setBoardRefreshTrigger((prev) => prev + 1);
          }}
        />
      )}

      <CreateProjectModal
        isOpen={isCreateProjectOpen}
        onClose={() => setIsCreateProjectOpen(false)}
        onProjectCreated={(newProject) => {
          setProjects((prev) => [newProject, ...prev]);
          setSelectedProjectId(newProject.id);
          setBoardRefreshTrigger((prev) => prev + 1);
          setCurrentView('board');
        }}
      />

      <CreateTaskModal
        isOpen={isCreateTaskOpen}
        onClose={() => setIsCreateTaskOpen(false)}
        projects={projects}
        defaultProjectId={selectedProjectId}
        onTaskCreated={() => {
          loadProjects();
          setBoardRefreshTrigger((prev) => prev + 1);
        }}
      />

      {currentProject && (
        <ProjectMembersModal
          isOpen={isMembersModalOpen}
          onClose={() => setIsMembersModalOpen(false)}
          project={currentProject}
          onRefreshProject={() => loadProjects()}
        />
      )}

      <SearchModal
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
        onSelectProject={(projectId) => {
          setSelectedProjectId(projectId);
          setCurrentView('board');
        }}
        onSelectTask={(taskId, projectId) => {
          setSelectedProjectId(projectId);
          setSelectedTaskId(taskId);
          setCurrentView('board');
        }}
      />

      <ProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
      />

      <NotificationPanel
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        notifications={notifications}
        onRefreshNotifications={loadNotifications}
        onSelectResource={(type, resourceId) => {
          if (type === 'task') {
            setSelectedTaskId(resourceId);
          } else if (type === 'project') {
            setSelectedProjectId(resourceId);
            setCurrentView('board');
          }
        }}
      />

      {/* Project Invitation Acceptance Modal */}
      {pendingInvite && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-gray-200 text-center animate-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-2xl bg-[#A3E635] flex items-center justify-center text-[#20242C] mx-auto mb-4 shadow-md shadow-[#A3E635]/25">
              <Mail className="w-6 h-6 stroke-[2.5]" />
            </div>
            <h3 className="text-xl font-extrabold text-[#20242C] mb-2">Project Invitation</h3>
            <p className="text-xs text-gray-600 mb-6 leading-relaxed">
              You've been invited to join <strong className="text-[#20242C] font-bold">{pendingInvite.project?.name}</strong> as <span className="px-2 py-0.5 rounded font-bold uppercase text-[10px] bg-gray-100 text-gray-800">{pendingInvite.role}</span>.
            </p>
            <div className="flex space-x-3">
              <button
                onClick={handleAcceptInvite}
                disabled={isAcceptingInvite}
                className="flex-1 py-3 bg-[#A3E635] hover:bg-[#8dd321] text-[#20242C] font-extrabold text-xs rounded-xl shadow-md transition-all active:scale-95"
              >
                {isAcceptingInvite ? 'Joining...' : 'Accept & Open Project'}
              </button>
              <button
                onClick={handleDismissInvite}
                className="px-4 py-3 bg-gray-100 hover:bg-gray-200 text-gray-600 font-bold text-xs rounded-xl transition-colors"
              >
                Decline
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <AuthProvider>
      <SocketProvider>
        <MainApp />
      </SocketProvider>
    </AuthProvider>
  );
};

export default App;
