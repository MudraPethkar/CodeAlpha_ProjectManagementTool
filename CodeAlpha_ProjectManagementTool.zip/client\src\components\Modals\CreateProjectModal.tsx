import React, { useState } from 'react';
import { X, FolderPlus, Lock, Globe, Sparkles } from 'lucide-react';
import api from '../../services/api';
import { Project } from '../../types';

interface CreateProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onProjectCreated: (project: Project) => void;
}

export const CreateProjectModal: React.FC<CreateProjectModalProps> = ({
  isOpen,
  onClose,
  onProjectCreated,
}) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [color, setColor] = useState('#A3E635');
  const [isPrivate, setIsPrivate] = useState(false);
  const [populateStarterCards, setPopulateStarterCards] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const colorOptions = [
    { name: 'Graphite Lime', value: '#A3E635' },
    { name: 'Electric Sky', value: '#0EA5E9' },
    { name: 'Violet Pulse', value: '#8B5CF6' },
    { name: 'Rose Red', value: '#F43F5E' },
    { name: 'Amber Gold', value: '#F59E0B' },
    { name: 'Teal Emerald', value: '#10B981' },
    { name: 'Obsidian Dark', value: '#20242C' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Project name is required');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      const project = await api.createProject({
        name: name.trim(),
        description: description.trim(),
        color,
        isPrivate,
      });

      if (populateStarterCards) {
        try {
          await api.populateBoardPresets(project.id, 'fullstack');
        } catch (presetErr) {
          console.warn('Could not auto-populate starter cards:', presetErr);
        }
      }

      onProjectCreated(project);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to create project');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-3xl w-full max-w-lg shadow-2xl border border-gray-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 bg-[#20242C] text-white flex items-center justify-between border-b border-[#2D333F]">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#A3E635] flex items-center justify-center text-[#20242C]">
              <FolderPlus className="w-4 h-4 stroke-[2.5]" />
            </div>
            <h3 className="font-extrabold text-base tracking-tight">Create New Project</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-gray-400 hover:text-white hover:bg-[#2D333F] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs font-semibold text-rose-600">
              {error}
            </div>
          )}

          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-[#20242C] block mb-1.5">
              Project Name *
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Website Redesign v2, Mobile App MVP"
              className="w-full text-xs font-semibold px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-[#A3E635]"
              required
              autoFocus
            />
          </div>

          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-[#20242C] block mb-1.5">
              Description
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What is this project about? What are the key goals?"
              rows={3}
              className="w-full text-xs text-[#20242C] p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-[#A3E635] resize-none leading-relaxed"
            />
          </div>

          {/* Color Palette Selector */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-[#20242C] block mb-2">
              Brand Accent Color
            </label>
            <div className="flex items-center space-x-2.5">
              {colorOptions.map((c) => (
                <button
                  type="button"
                  key={c.value}
                  onClick={() => setColor(c.value)}
                  className={`w-8 h-8 rounded-full transition-transform flex items-center justify-center ${
                    color === c.value ? 'scale-110 ring-2 ring-[#20242C] ring-offset-2' : 'hover:scale-105'
                  }`}
                  style={{ backgroundColor: c.value }}
                  title={c.name}
                >
                  {color === c.value && (
                    <span
                      className={`text-xs font-black ${
                        c.value === '#A3E635' || c.value === '#D9F99D' ? 'text-[#20242C]' : 'text-white'
                      }`}
                    >
                      ✓
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Privacy Toggle */}
          <div className="pt-2">
            <label className="text-xs font-bold uppercase tracking-wider text-[#20242C] block mb-2">
              Privacy Setting
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setIsPrivate(false)}
                className={`p-3 rounded-2xl border text-left transition-all ${
                  !isPrivate
                    ? 'border-[#A3E635] bg-[#A3E635]/10 font-bold'
                    : 'border-gray-200 hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center gap-1.5 text-xs text-[#20242C] mb-1">
                  <Globe className="w-4 h-4 text-[#A3E635]" />
                  <span>Public</span>
                </div>
                <p className="text-[11px] text-gray-500 font-normal">
                  All team members can view and join
                </p>
              </button>

              <button
                type="button"
                onClick={() => setIsPrivate(true)}
                className={`p-3 rounded-2xl border text-left transition-all ${
                  isPrivate
                    ? 'border-[#A3E635] bg-[#A3E635]/10 font-bold'
                    : 'border-gray-200 hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center gap-1.5 text-xs text-[#20242C] mb-1">
                  <Lock className="w-4 h-4 text-amber-500" />
                  <span>Private</span>
                </div>
                <p className="text-[11px] text-gray-500 font-normal">
                  Only invited collaborators have access
                </p>
              </button>
            </div>
          </div>

          {/* Starter Cards Option */}
          <label className="flex items-start space-x-2.5 p-3 rounded-2xl bg-gray-50 border border-gray-200 cursor-pointer hover:bg-gray-100/70 transition-colors">
            <input
              type="checkbox"
              checked={populateStarterCards}
              onChange={(e) => setPopulateStarterCards(e.target.checked)}
              className="mt-0.5 rounded text-[#A3E635] focus:ring-[#A3E635]"
            />
            <div>
              <span className="text-xs font-bold text-[#20242C] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-lime-600" />
                Auto-populate with starter cards for all sections
              </span>
              <span className="text-[11px] text-gray-500 block mt-0.5">
                Automatically creates structured cards for Backlog, To Do, In Progress, Review, and Done so your board isn't empty.
              </span>
            </div>
          </label>

          {/* Footer Actions */}
          <div className="flex items-center justify-end space-x-2.5 pt-4 border-t border-gray-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-gray-600 hover:text-gray-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2.5 bg-[#A3E635] hover:bg-[#8dd321] text-[#20242C] font-bold text-xs rounded-xl shadow-sm transition-all"
            >
              {isSubmitting ? 'Creating...' : 'Create Project'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
