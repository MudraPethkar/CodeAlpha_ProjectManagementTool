import React, { useState, useEffect } from 'react';
import { Activity as ActivityIcon, Clock, CheckCircle2, MessageSquare, ArrowRight, FolderKanban } from 'lucide-react';
import { Activity } from '../../types';
import api from '../../services/api';

export const ActivityView: React.FC = () => {
  const [activities, setActivities] = useState<Activity[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchActivities = async () => {
      try {
        const data = await api.getActivities();
        setActivities(data);
      } catch (err) {
        console.error('Failed to load activities:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchActivities();
  }, []);

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8 space-y-6 bg-[#F9FAFB]">
      <div>
        <h2 className="text-2xl font-extrabold text-[#20242C] tracking-tight flex items-center gap-2">
          <ActivityIcon className="w-6 h-6 text-[#A3E635]" />
          Activity Stream
        </h2>
        <p className="text-xs text-gray-500 mt-1">
          Chronological audit trail of team changes, task moves, and comments.
        </p>
      </div>

      <div className="bg-white rounded-3xl border border-[#E5E7EB] p-6 shadow-xs divide-y divide-gray-100 max-w-4xl">
        {activities.map((act) => (
          <div key={act.id} className="py-4 flex items-start space-x-4">
            <img
              src={act.actor?.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${act.actor?.name}`}
              alt={act.actor?.name}
              className="w-9 h-9 rounded-full object-cover border border-gray-200 mt-0.5"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-[#20242C]">{act.actor?.name}</span>
                <span className="text-[11px] text-gray-400">
                  {new Date(act.createdAt).toLocaleString([], {
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </span>
              </div>
              <p className="text-xs text-gray-600 leading-relaxed">
                <span className="font-medium text-[#20242C]">
                  {act.action === 'task_created' && 'created task'}
                  {act.action === 'task_moved' && 'moved task'}
                  {act.action === 'task_completed' && 'completed task'}
                  {act.action === 'comment_added' && 'commented on'}
                  {act.action === 'project_created' && 'created project'}
                  {!['task_created', 'task_moved', 'task_completed', 'comment_added', 'project_created'].includes(act.action) && act.action.replace('_', ' ')}
                </span>{' '}
                {act.task && <span className="font-bold text-[#20242C]">"{act.task.title}"</span>}{' '}
                {act.project && (
                  <span className="text-gray-400">in project {act.project.name}</span>
                )}
              </p>
            </div>
          </div>
        ))}

        {activities.length === 0 && !isLoading && (
          <div className="py-16 text-center text-xs text-gray-400">
            No activity records found.
          </div>
        )}
      </div>
    </div>
  );
};
