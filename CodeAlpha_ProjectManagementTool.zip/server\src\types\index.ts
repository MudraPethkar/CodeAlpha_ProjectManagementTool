import { Request } from 'express';

export interface AuthRequest extends Request {
  user?: {
    userId: string;
    email: string;
    role: string;
  };
}

export interface UserDTO {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string | null;
  role: string;
  bio?: string | null;
  createdAt: Date;
}
