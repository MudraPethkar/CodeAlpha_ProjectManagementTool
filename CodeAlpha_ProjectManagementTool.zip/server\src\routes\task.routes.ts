import { Router, Response } from 'express';
import { z } from 'zod';
import prisma from '../prisma.js';
import { authenticate } from '../middleware/auth.js';
import { AuthRequest } from '../types/index.js';
import { broadcastToProject, sendNotificationToUser } from '../socket.js';

const router = Router();

// Helper to check user membership in task's project
const verifyTaskAccess = async (taskId: string, userId: string) => {
  const task = await prisma.task.findUnique({
    where: { id: taskId },
    include: {
      list: {
        include: {
          board: {
            include: {
              project: {
                include: { members: true },
              },
            },
          },
        },
      },
    },
  });

  if (!task) return null;
  const isMember = task.list.board.project.members.some((m) => m.userId === userId);
  if (!isMember) return null;

  return {
    task,
    projectId: task.list.board.projectId,
  };
};

// POST /lists/:listId/tasks - Create task in a list
router.post('/lists/:listId/tasks', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { listId } = req.params;
    const userId = req.user!.userId;
    const { title, description, priority = 'MEDIUM', dueDate, assigneeIds = [], labelIds = [] } = req.body;

    if (!title || title.trim().length === 0) {
      res.status(400).json({ message: 'Task title is required.' });
      return;
    }

    const list = await prisma.list.findUnique({
      where: { id: listId },
      include: { board: { include: { project: { include: { members: true } } } } },
    });

    if (!list) {
      res.status(404).json({ message: 'List not found.' });
      return;
    }

    const isOwner = list.board.project.ownerId === userId;
    const isMember = isOwner || list.board.project.members.some((m) => m.userId === userId);
    if (!isMember) {
      res.status(403).json({ message: 'Access denied: You are not a member of this project.' });
      return;
    }

    if (isOwner && !list.board.project.members.some((m) => m.userId === userId)) {
      await prisma.projectMember.upsert({
        where: { projectId_userId: { projectId: list.board.projectId, userId } },
        create: { projectId: list.board.projectId, userId, role: 'OWNER' },
        update: { role: 'OWNER' },
      });
    }

    const lastTask = await prisma.task.findFirst({
      where: { listId },
      orderBy: { position: 'desc' },
    });

    const nextPosition = lastTask ? lastTask.position + 1 : 0;
    const parsedDueDate = dueDate && !isNaN(new Date(dueDate).getTime()) ? new Date(dueDate) : null;

    const task = await prisma.$transaction(async (tx) => {
      const createdTask = await tx.task.create({
        data: {
          listId,
          title: title.trim(),
          description,
          priority,
          dueDate: parsedDueDate,
          position: nextPosition,
          createdById: userId,
          status: list.name.toUpperCase(),
        },
      });

      // Assignees
      let targetAssigneeIds: string[] = [];
      if (Array.isArray(assigneeIds) && assigneeIds.length > 0) {
        const validUsers = await tx.user.findMany({
          where: { id: { in: assigneeIds } },
          select: { id: true },
        });
        targetAssigneeIds = validUsers.map((u) => u.id);
      }

      // Default to assigning to creator so task is visible in "My Assigned Tasks"
      if (targetAssigneeIds.length === 0) {
        targetAssigneeIds = [userId];
      }

      for (const aId of targetAssigneeIds) {
        await tx.taskAssignee.create({
          data: { taskId: createdTask.id, userId: aId },
        });
      }

      // Labels
      if (labelIds.length > 0) {
        for (const lId of labelIds) {
          await tx.taskLabel.create({
            data: { taskId: createdTask.id, labelId: lId },
          });
        }
      }

      // Checklists (if provided via presets)
      const initialChecklists = req.body.checklists || req.body.checklist;
      if (initialChecklists && Array.isArray(initialChecklists) && initialChecklists.length > 0) {
        const checklist = await tx.checklist.create({
          data: {
            taskId: createdTask.id,
            title: 'Action Items',
            position: 0,
          },
        });
        for (let i = 0; i < initialChecklists.length; i++) {
          const itemText = typeof initialChecklists[i] === 'string' ? initialChecklists[i] : initialChecklists[i]?.text;
          if (itemText && typeof itemText === 'string') {
            await tx.checklistItem.create({
              data: {
                checklistId: checklist.id,
                text: itemText.trim(),
                position: i,
              },
            });
          }
        }
      }

      // Activity log
      await tx.activity.create({
        data: {
          projectId: list.board.projectId,
          taskId: createdTask.id,
          actorId: userId,
          action: 'task_created',
          metadata: JSON.stringify({ taskTitle: title.trim(), listName: list.name }),
        },
      });

      return tx.task.findUnique({
        where: { id: createdTask.id },
        include: {
          assignees: { include: { user: { select: { id: true, name: true, email: true, avatarUrl: true } } } },
          labels: { include: { label: true } },
          checklists: { include: { items: true } },
          attachments: true,
          comments: { select: { id: true } },
        },
      });
    });

    // Notify assigned users
    if (assigneeIds.length > 0) {
      const creator = await prisma.user.findUnique({ where: { id: userId } });
      for (const aId of assigneeIds) {
        if (aId !== userId) {
          const notification = await prisma.notification.create({
            data: {
              userId: aId,
              type: 'TASK_ASSIGNED',
              title: 'Task Assigned to You',
              body: `${creator?.name || 'A teammate'} assigned you to "${title.trim()}".`,
              resourceType: 'task',
              resourceId: task!.id,
            },
          });
          sendNotificationToUser(aId, notification);
        }
      }
    }

    broadcastToProject(list.board.projectId, 'task:created', {
      task,
      listId,
      projectId: list.board.projectId,
    });

    res.status(201).json(task);
  } catch (error) {
    console.error('Create task error:', error);
    res.status(500).json({ message: 'Failed to create task.' });
  }
});

// GET /tasks/:taskId - Get task full details
router.get('/tasks/:taskId', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { taskId } = req.params;
    const userId = req.user!.userId;

    const access = await verifyTaskAccess(taskId, userId);
    if (!access) {
      res.status(403).json({ message: 'Task not found or access denied.' });
      return;
    }

    const task = await prisma.task.findUnique({
      where: { id: taskId },
      include: {
        list: { select: { id: true, name: true } },
        creator: { select: { id: true, name: true, email: true, avatarUrl: true } },
        assignees: {
          include: {
            user: { select: { id: true, name: true, email: true, avatarUrl: true } },
          },
        },
        labels: { include: { label: true } },
        checklists: {
          orderBy: { position: 'asc' },
          include: {
            items: { orderBy: { position: 'asc' } },
          },
        },
        attachments: {
          orderBy: { createdAt: 'desc' },
          include: { uploader: { select: { id: true, name: true } } },
        },
        comments: {
          orderBy: { createdAt: 'asc' },
          include: {
            author: { select: { id: true, name: true, email: true, avatarUrl: true } },
          },
        },
        activities: {
          orderBy: { createdAt: 'desc' },
          take: 30,
          include: {
            actor: { select: { id: true, name: true, avatarUrl: true } },
          },
        },
      },
    });

    res.json(task);
  } catch (error) {
    res.status(500).json({ message: 'Failed to load task details.' });
  }
});

// PATCH /tasks/:taskId - Update task details
router.patch('/tasks/:taskId', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { taskId } = req.params;
    const userId = req.user!.userId;

    const access = await verifyTaskAccess(taskId, userId);
    if (!access) {
      res.status(403).json({ message: 'Task not found or access denied.' });
      return;
    }

    const { title, description, priority, dueDate, status, archived } = req.body;

    const updated = await prisma.task.update({
      where: { id: taskId },
      data: {
        ...(title !== undefined && { title: title.trim() }),
        ...(description !== undefined && { description }),
        ...(priority !== undefined && { priority }),
        ...(dueDate !== undefined && { dueDate: dueDate ? new Date(dueDate) : null }),
        ...(status !== undefined && { status }),
        ...(archived !== undefined && { archived }),
      },
      include: {
        assignees: { include: { user: { select: { id: true, name: true, email: true, avatarUrl: true } } } },
        labels: { include: { label: true } },
        checklists: { include: { items: true } },
        attachments: true,
        comments: { select: { id: true } },
      },
    });

    // Activity log
    await prisma.activity.create({
      data: {
        projectId: access.projectId,
        taskId,
        actorId: userId,
        action: 'task_updated',
        metadata: JSON.stringify({ taskTitle: updated.title }),
      },
    });

    broadcastToProject(access.projectId, 'task:updated', {
      task: updated,
      projectId: access.projectId,
    });

    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: 'Failed to update task.' });
  }
});

// PATCH /tasks/:taskId/move - Move task between lists or reorder within list
router.patch('/tasks/:taskId/move', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { taskId } = req.params;
    const userId = req.user!.userId;
    const { targetListId, newPosition } = req.body;

    const access = await verifyTaskAccess(taskId, userId);
    if (!access) {
      res.status(403).json({ message: 'Task not found or access denied.' });
      return;
    }

    const previousListId = access.task.listId;
    const previousListName = access.task.list.name;

    const targetList = await prisma.list.findUnique({
      where: { id: targetListId },
    });

    if (!targetList) {
      res.status(404).json({ message: 'Target list not found.' });
      return;
    }

    const isMovingLists = previousListId !== targetListId;

    const updated = await prisma.task.update({
      where: { id: taskId },
      data: {
        listId: targetListId,
        position: newPosition,
        status: targetList.name.toUpperCase(),
      },
      include: {
        assignees: { include: { user: { select: { id: true, name: true, email: true, avatarUrl: true } } } },
        labels: { include: { label: true } },
        checklists: { include: { items: true } },
        attachments: true,
        comments: { select: { id: true } },
      },
    });

    // If moved between lists, log activity and create notifications
    if (isMovingLists) {
      const user = await prisma.user.findUnique({ where: { id: userId } });
      await prisma.activity.create({
        data: {
          projectId: access.projectId,
          taskId,
          actorId: userId,
          action: 'task_moved',
          metadata: JSON.stringify({
            fromList: previousListName,
            toList: targetList.name,
            taskTitle: updated.title,
          }),
        },
      });

      // If moved to Done, notify assignees with completion praise
      if (targetList.name.toLowerCase() === 'done') {
        for (const a of updated.assignees) {
          if (a.userId !== userId) {
            const notification = await prisma.notification.create({
              data: {
                userId: a.userId,
                type: 'STATUS_CHANGED',
                title: 'Task Completed! 🎉',
                body: `${user?.name || 'A teammate'} moved "${updated.title}" to Done.`,
                resourceType: 'task',
                resourceId: updated.id,
              },
            });
            sendNotificationToUser(a.userId, notification);
          }
        }
      }
    }

    broadcastToProject(access.projectId, 'task:moved', {
      task: updated,
      fromListId: previousListId,
      toListId: targetListId,
      newPosition,
      projectId: access.projectId,
    });

    res.json(updated);
  } catch (error) {
    console.error('Move task error:', error);
    res.status(500).json({ message: 'Failed to move task.' });
  }
});

// DELETE /tasks/:taskId - Delete task
router.delete('/tasks/:taskId', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { taskId } = req.params;
    const userId = req.user!.userId;

    const access = await verifyTaskAccess(taskId, userId);
    if (!access) {
      res.status(403).json({ message: 'Task not found or access denied.' });
      return;
    }

    await prisma.task.delete({ where: { id: taskId } });

    broadcastToProject(access.projectId, 'task:deleted', {
      taskId,
      listId: access.task.listId,
      projectId: access.projectId,
    });

    res.json({ message: 'Task deleted successfully.' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete task.' });
  }
});

// POST /tasks/:taskId/assignees - Toggle/add assignee
router.post('/tasks/:taskId/assignees', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { taskId } = req.params;
    const userId = req.user!.userId;
    const { targetUserId } = req.body;

    const access = await verifyTaskAccess(taskId, userId);
    if (!access) {
      res.status(403).json({ message: 'Access denied.' });
      return;
    }

    const existing = await prisma.taskAssignee.findUnique({
      where: { taskId_userId: { taskId, userId: targetUserId } },
    });

    if (existing) {
      await prisma.taskAssignee.delete({
        where: { id: existing.id },
      });
    } else {
      await prisma.taskAssignee.create({
        data: { taskId, userId: targetUserId },
      });

      // Send notification
      const actor = await prisma.user.findUnique({ where: { id: userId } });
      const notification = await prisma.notification.create({
        data: {
          userId: targetUserId,
          type: 'TASK_ASSIGNED',
          title: 'Assigned to Task',
          body: `${actor?.name || 'A teammate'} assigned you to "${access.task.title}".`,
          resourceType: 'task',
          resourceId: taskId,
        },
      });
      sendNotificationToUser(targetUserId, notification);
    }

    const assignees = await prisma.taskAssignee.findMany({
      where: { taskId },
      include: { user: { select: { id: true, name: true, email: true, avatarUrl: true } } },
    });

    broadcastToProject(access.projectId, 'task:assignees_updated', {
      taskId,
      assignees,
      projectId: access.projectId,
    });

    res.json(assignees);
  } catch (error) {
    res.status(500).json({ message: 'Failed to update assignees.' });
  }
});

// POST /tasks/:taskId/labels - Toggle label on task
router.post('/tasks/:taskId/labels', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { taskId } = req.params;
    const userId = req.user!.userId;
    const { labelId } = req.body;

    const access = await verifyTaskAccess(taskId, userId);
    if (!access) {
      res.status(403).json({ message: 'Access denied.' });
      return;
    }

    const existing = await prisma.taskLabel.findUnique({
      where: { taskId_labelId: { taskId, labelId } },
    });

    if (existing) {
      await prisma.taskLabel.delete({ where: { id: existing.id } });
    } else {
      await prisma.taskLabel.create({
        data: { taskId, labelId },
      });
    }

    const labels = await prisma.taskLabel.findMany({
      where: { taskId },
      include: { label: true },
    });

    broadcastToProject(access.projectId, 'task:labels_updated', {
      taskId,
      labels,
      projectId: access.projectId,
    });

    res.json(labels);
  } catch (error) {
    res.status(500).json({ message: 'Failed to toggle label.' });
  }
});

// POST /tasks/:taskId/checklists - Add a new checklist
router.post('/tasks/:taskId/checklists', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { taskId } = req.params;
    const userId = req.user!.userId;
    const { title = 'Checklist' } = req.body;

    const access = await verifyTaskAccess(taskId, userId);
    if (!access) {
      res.status(403).json({ message: 'Access denied.' });
      return;
    }

    const checklist = await prisma.checklist.create({
      data: {
        taskId,
        title,
      },
      include: { items: true },
    });

    broadcastToProject(access.projectId, 'checklist:created', { taskId, checklist });
    res.status(201).json(checklist);
  } catch (error) {
    res.status(500).json({ message: 'Failed to create checklist.' });
  }
});

// POST /checklists/:checklistId/items - Add item to checklist
router.post('/checklists/:checklistId/items', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { checklistId } = req.params;
    const { text } = req.body;

    if (!text || text.trim().length === 0) {
      res.status(400).json({ message: 'Item text is required.' });
      return;
    }

    const checklist = await prisma.checklist.findUnique({
      where: { id: checklistId },
      include: { task: { include: { list: { include: { board: true } } } } },
    });

    if (!checklist) {
      res.status(404).json({ message: 'Checklist not found.' });
      return;
    }

    const item = await prisma.checklistItem.create({
      data: {
        checklistId,
        text: text.trim(),
        completed: false,
      },
    });

    const projectId = checklist.task.list.board.projectId;
    broadcastToProject(projectId, 'checklist_item:created', {
      taskId: checklist.taskId,
      checklistId,
      item,
    });

    res.status(201).json(item);
  } catch (error) {
    res.status(500).json({ message: 'Failed to add checklist item.' });
  }
});

// PATCH /checklist-items/:itemId - Toggle or update item
router.patch('/checklist-items/:itemId', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { itemId } = req.params;
    const { completed, text } = req.body;

    const updated = await prisma.checklistItem.update({
      where: { id: itemId },
      data: {
        ...(completed !== undefined && { completed }),
        ...(text !== undefined && { text }),
      },
      include: {
        checklist: {
          include: { task: { include: { list: { include: { board: true } } } } },
        },
      },
    });

    const projectId = updated.checklist.task.list.board.projectId;
    broadcastToProject(projectId, 'checklist_item:updated', {
      taskId: updated.checklist.taskId,
      item: updated,
    });

    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: 'Failed to update checklist item.' });
  }
});

// DELETE /checklist-items/:itemId - Delete item
router.delete('/checklist-items/:itemId', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { itemId } = req.params;
    const item = await prisma.checklistItem.findUnique({
      where: { id: itemId },
      include: { checklist: { include: { task: { include: { list: { include: { board: true } } } } } } },
    });

    if (!item) {
      res.status(404).json({ message: 'Item not found.' });
      return;
    }

    await prisma.checklistItem.delete({ where: { id: itemId } });

    const projectId = item.checklist.task.list.board.projectId;
    broadcastToProject(projectId, 'checklist_item:deleted', {
      taskId: item.checklist.taskId,
      itemId,
    });

    res.json({ message: 'Item deleted.' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete item.' });
  }
});

// POST /tasks/:taskId/attachments - Add attachment
router.post('/tasks/:taskId/attachments', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { taskId } = req.params;
    const userId = req.user!.userId;
    const { fileName, fileUrl, fileSize } = req.body;

    if (!fileName || !fileUrl) {
      res.status(400).json({ message: 'File name and URL are required.' });
      return;
    }

    const access = await verifyTaskAccess(taskId, userId);
    if (!access) {
      res.status(403).json({ message: 'Access denied.' });
      return;
    }

    const attachment = await prisma.attachment.create({
      data: {
        taskId,
        fileName,
        fileUrl,
        fileSize: fileSize || 1024 * 100,
        uploadedBy: userId,
      },
      include: { uploader: { select: { id: true, name: true } } },
    });

    broadcastToProject(access.projectId, 'attachment:created', {
      taskId,
      attachment,
    });

    res.status(201).json(attachment);
  } catch (error) {
    res.status(500).json({ message: 'Failed to upload attachment.' });
  }
});

// DELETE /attachments/:attachmentId - Delete attachment
router.delete('/attachments/:attachmentId', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { attachmentId } = req.params;
    const attachment = await prisma.attachment.findUnique({
      where: { id: attachmentId },
      include: { task: { include: { list: { include: { board: true } } } } },
    });

    if (!attachment) {
      res.status(404).json({ message: 'Attachment not found.' });
      return;
    }

    await prisma.attachment.delete({ where: { id: attachmentId } });

    const projectId = attachment.task.list.board.projectId;
    broadcastToProject(projectId, 'attachment:deleted', {
      taskId: attachment.taskId,
      attachmentId,
    });

    res.json({ message: 'Attachment deleted.' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete attachment.' });
  }
});

export default router;
