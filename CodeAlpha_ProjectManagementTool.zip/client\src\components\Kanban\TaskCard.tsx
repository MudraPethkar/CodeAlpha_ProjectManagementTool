import React from 'react';
import {
  Calendar,
  CheckSquare,
  MessageSquare,
  Paperclip,
  AlertCircle,
  Clock,
} from 'lucide-react';
import { Task } from '../../types';

interface TaskCardProps {
  task: Task;
  onSelectTask: (task: Task) => void;
  onDragStart: (e: React.DragEvent, task: Task) => void;
}

export const TaskCard: React.FC<TaskCardProps> = ({
  task,
  onSelectTask,
  onDragStart,
}) => {
  // Calculate checklist progress
  let totalChecklistItems = 0;
  let completedChecklistItems = 0;

  if (task.checklists) {
    task.checklists.forEach((cl) => {
      if (cl.items) {
        totalChecklistItems += cl.items.length;
        completedChecklistItems += cl.items.filter((item) => item.completed).length;
      }
    });
  }

  // Priority color config
  const priorityStyles: Record<string, { bg: string; text: string; label: string }> = {
    LOW: { bg: 'bg-emerald-50 border-emerald-200', text: 'text-emerald-700', label: 'Low' },
    MEDIUM: { bg: 'bg-blue-50 border-blue-200', text: 'text-blue-700', label: 'Medium' },
    HIGH: { bg: 'bg-amber-50 border-amber-200', text: 'text-amber-700', label: 'High' },
    URGENT: { bg: 'bg-rose-50 border-rose-200', text: 'text-rose-700', label: 'Urgent' },
  };

  const currentPriority = priorityStyles[task.priority] || priorityStyles.MEDIUM;

  // Due date status
  let isOverdue = false;
  let isDueSoon = false;
  let formattedDueDate = '';

  if (task.dueDate) {
    const due = new Date(task.dueDate);
    const now = new Date();
    const diffHours = (due.getTime() - now.getTime()) / (1000 * 60 * 60);

    isOverdue = diffHours < 0;
    isDueSoon = diffHours >= 0 && diffHours <= 48;

    formattedDueDate = due.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
    });
  }

  const commentCount = Array.isArray(task.comments) ? task.comments.length : 0;
  const attachmentCount = Array.isArray(task.attachments) ? task.attachments.length : 0;

  return (
    <div
      draggable
      onDragStart={(e) => onDragStart(e, task)}
      onClick={() => onSelectTask(task)}
      className="group bg-white rounded-xl p-3.5 border border-[#E5E7EB] hover:border-[#A3E635] shadow-xs hover:shadow-md transition-all duration-200 cursor-grab active:cursor-grabbing select-none"
    >
      {/* Top meta: Priority & Labels */}
      <div className="flex flex-wrap items-center justify-between gap-1.5 mb-2.5">
        <span
          className={`inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-bold uppercase tracking-wider border ${currentPriority.bg} ${currentPriority.text}`}
        >
          {task.priority === 'URGENT' && <AlertCircle className="w-3 h-3 mr-1 stroke-[2.5]" />}
          {currentPriority.label}
        </span>

        {/* Labels */}
        <div className="flex flex-wrap gap-1">
          {task.labels?.slice(0, 2).map((tl) => (
            <span
              key={tl.id || tl.labelId}
              className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-gray-100 text-gray-700"
            >
              <span
                className="w-1.5 h-1.5 rounded-full mr-1"
                style={{ backgroundColor: tl.label?.color || '#A3E635' }}
              />
              {tl.label?.name}
            </span>
          ))}
          {task.labels && task.labels.length > 2 && (
            <span className="text-[10px] text-gray-400 font-semibold self-center">
              +{task.labels.length - 2}
            </span>
          )}
        </div>
      </div>

      {/* Card Title */}
      <h4 className="font-semibold text-sm text-[#20242C] group-hover:text-[#20242C] line-clamp-2 mb-1.5 leading-snug">
        {task.title}
      </h4>

      {/* Description Snippet if available */}
      {task.description && (
        <p className="text-xs text-gray-500 line-clamp-2 mb-3 leading-relaxed">
          {task.description}
        </p>
      )}

      {/* Checklist Progress Bar */}
      {totalChecklistItems > 0 && (
        <div className="mb-3">
          <div className="flex items-center justify-between text-[11px] text-gray-500 mb-1">
            <span className="flex items-center gap-1 font-medium">
              <CheckSquare className="w-3 h-3 text-[#A3E635]" />
              Checklist
            </span>
            <span className="font-semibold text-gray-700">
              {completedChecklistItems}/{totalChecklistItems}
            </span>
          </div>
          <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-[#A3E635] rounded-full transition-all duration-300"
              style={{
                width: `${Math.round((completedChecklistItems / totalChecklistItems) * 100)}%`,
              }}
            />
          </div>
        </div>
      )}

      {/* Bottom Row: Due Date, Indicators & Assignees */}
      <div className="flex items-center justify-between pt-2 border-t border-gray-100 text-xs text-gray-400">
        <div className="flex items-center space-x-2.5">
          {formattedDueDate && (
            <span
              className={`inline-flex items-center gap-1 text-[11px] font-medium px-1.5 py-0.5 rounded ${
                isOverdue
                  ? 'bg-rose-50 text-rose-600 font-bold'
                  : isDueSoon
                  ? 'bg-amber-50 text-amber-600 font-semibold'
                  : 'text-gray-500 bg-gray-50'
              }`}
              title={isOverdue ? 'Overdue!' : isDueSoon ? 'Due soon' : 'Due date'}
            >
              {isOverdue ? <AlertCircle className="w-3 h-3" /> : <Calendar className="w-3 h-3" />}
              {formattedDueDate}
            </span>
          )}

          {commentCount > 0 && (
            <span className="flex items-center gap-1 text-[11px] hover:text-gray-600">
              <MessageSquare className="w-3 h-3" />
              {commentCount}
            </span>
          )}

          {attachmentCount > 0 && (
            <span className="flex items-center gap-1 text-[11px] hover:text-gray-600">
              <Paperclip className="w-3 h-3" />
              {attachmentCount}
            </span>
          )}
        </div>

        {/* Assignees Avatars */}
        <div className="flex items-center -space-x-1.5">
          {task.assignees?.map((a) => (
            <img
              key={a.id || a.userId}
              src={a.user?.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${a.user?.name || 'Assignee'}`}
              alt={a.user?.name}
              title={a.user?.name}
              className="w-6 h-6 rounded-full object-cover border-2 border-white shadow-xs"
            />
          ))}
        </div>
      </div>
    </div>
  );
};
