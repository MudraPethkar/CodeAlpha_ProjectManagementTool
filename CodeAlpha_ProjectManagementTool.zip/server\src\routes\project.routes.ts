import { Router, Response } from 'express';
import { z } from 'zod';
import prisma from '../prisma.js';
import { authenticate, requireProjectMember } from '../middleware/auth.js';
import { AuthRequest } from '../types/index.js';
import { broadcastToProject, sendNotificationToUser } from '../socket.js';
import { sendProjectInvitationEmail } from '../utils/mailer.js';

const router = Router();

const createProjectSchema = z.object({
  name: z.string().min(2, 'Project name must be at least 2 characters'),
  description: z.string().optional(),
  color: z.string().default('#A3E635'),
  icon: z.string().default('layout'),
  isPrivate: z.boolean().default(false),
});

// GET /projects - Get all projects current user belongs to or owns
router.get('/', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.userId;

    const projects = await prisma.project.findMany({
      where: {
        members: {
          some: { userId },
        },
      },
      include: {
        owner: {
          select: { id: true, name: true, email: true, avatarUrl: true },
        },
        members: {
          include: {
            user: {
              select: { id: true, name: true, email: true, avatarUrl: true },
            },
          },
        },
        boards: {
          include: {
            lists: {
              include: {
                tasks: {
                  select: { id: true, status: true, archived: true },
                },
              },
            },
          },
        },
      },
      orderBy: { updatedAt: 'desc' },
    });

    // Calculate task metrics and user role for each project
    const formatted = projects.map((p) => {
      let totalTasks = 0;
      let completedTasks = 0;

      p.boards.forEach((b) => {
        b.lists.forEach((l) => {
          l.tasks.forEach((t) => {
            if (!t.archived) {
              totalTasks++;
              if (l.name.toLowerCase() === 'done' || t.status === 'DONE') {
                completedTasks++;
              }
            }
          });
        });
      });

      const userMembership = p.members.find((m) => m.userId === userId);

      return {
        id: p.id,
        name: p.name,
        description: p.description,
        color: p.color,
        icon: p.icon,
        isPrivate: p.isPrivate,
        archived: p.archived,
        createdAt: p.createdAt,
        updatedAt: p.updatedAt,
        owner: p.owner,
        memberCount: p.members.length,
        members: p.members.map((m) => ({
          id: m.id,
          role: m.role,
          joinedAt: m.joinedAt,
          user: m.user,
        })),
        totalTasks,
        completedTasks,
        progressPercent: totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0,
        currentUserRole: userMembership?.role || 'MEMBER',
      };
    });

    res.json(formatted);
  } catch (error) {
    console.error('Fetch projects error:', error);
    res.status(500).json({ message: 'Failed to retrieve projects.' });
  }
});

// POST /projects - Create a new project with default board and standard lists
router.post('/', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.userId;
    const validated = createProjectSchema.safeParse(req.body);
    if (!validated.success) {
      res.status(400).json({ message: validated.error.errors[0].message });
      return;
    }

    const { name, description, color, icon, isPrivate } = validated.data;

    // Create project, set owner in ProjectMember, create Board, and create default 5 Kanban lists
    const project = await prisma.$transaction(async (tx) => {
      const newProject = await tx.project.create({
        data: {
          name,
          description,
          color,
          icon,
          isPrivate,
          ownerId: userId,
          members: {
            create: {
              userId,
              role: 'OWNER',
            },
          },
        },
      });

      // Default board
      const board = await tx.board.create({
        data: {
          projectId: newProject.id,
          name: 'Main Board',
          position: 0,
        },
      });

      // Default lists: Backlog, To Do, In Progress, Review, Done
      const defaultLists = ['Backlog', 'To Do', 'In Progress', 'Review', 'Done'];
      for (let i = 0; i < defaultLists.length; i++) {
        await tx.list.create({
          data: {
            boardId: board.id,
            name: defaultLists[i],
            position: i,
          },
        });
      }

      // Default project labels
      const defaultLabels = [
        { name: 'Feature', color: '#A3E635' },
        { name: 'Bug', color: '#F43F5E' },
        { name: 'Design', color: '#8B5CF6' },
        { name: 'Backend', color: '#0EA5E9' },
        { name: 'High Priority', color: '#F59E0B' },
      ];
      for (const label of defaultLabels) {
        await tx.label.create({
          data: {
            projectId: newProject.id,
            name: label.name,
            color: label.color,
          },
        });
      }

      // Log initial activity
      await tx.activity.create({
        data: {
          projectId: newProject.id,
          actorId: userId,
          action: 'project_created',
          metadata: JSON.stringify({ projectName: name }),
        },
      });

      return newProject;
    });

    res.status(201).json(project);
  } catch (error) {
    console.error('Create project error:', error);
    res.status(500).json({ message: 'Failed to create project.' });
  }
});

// GET /projects/:projectId - Get single project details
router.get('/:projectId', authenticate, requireProjectMember('MEMBER'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { projectId } = req.params;
    const userId = req.user!.userId;

    const project = await prisma.project.findUnique({
      where: { id: projectId },
      include: {
        owner: { select: { id: true, name: true, email: true, avatarUrl: true } },
        members: {
          include: {
            user: { select: { id: true, name: true, email: true, avatarUrl: true, role: true } },
          },
        },
        labels: true,
        invitations: {
          where: { status: 'PENDING' },
        },
      },
    });

    if (!project) {
      res.status(404).json({ message: 'Project not found.' });
      return;
    }

    const currentMember = project.members.find((m) => m.userId === userId);

    res.json({
      ...project,
      currentUserRole: currentMember?.role || 'MEMBER',
    });
  } catch (error) {
    res.status(500).json({ message: 'Failed to load project details.' });
  }
});

// PATCH /projects/:projectId - Update project info (Admin/Owner only)
router.patch('/:projectId', authenticate, requireProjectMember('ADMIN'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { projectId } = req.params;
    const { name, description, color, icon, isPrivate, archived } = req.body;

    const updated = await prisma.project.update({
      where: { id: projectId },
      data: {
        ...(name !== undefined && { name }),
        ...(description !== undefined && { description }),
        ...(color !== undefined && { color }),
        ...(icon !== undefined && { icon }),
        ...(isPrivate !== undefined && { isPrivate }),
        ...(archived !== undefined && { archived }),
      },
    });

    broadcastToProject(projectId, 'project:updated', updated);
    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: 'Failed to update project.' });
  }
});

// DELETE /projects/:projectId - Delete project (Owner only)
router.delete('/:projectId', authenticate, requireProjectMember('OWNER'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { projectId } = req.params;
    await prisma.project.delete({ where: { id: projectId } });
    res.json({ message: 'Project deleted successfully.' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete project.' });
  }
});

// POST /projects/:projectId/invitations - Invite member
router.post('/:projectId/invitations', authenticate, requireProjectMember('ADMIN'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { projectId } = req.params;
    const inviterId = req.user!.userId;
    const { email, role = 'MEMBER' } = req.body;

    if (!email) {
      res.status(400).json({ message: 'Email is required to invite member.' });
      return;
    }

    const project = await prisma.project.findUnique({
      where: { id: projectId },
      include: { members: { include: { user: true } } },
    });

    if (!project) {
      res.status(404).json({ message: 'Project not found.' });
      return;
    }

    // Check if already a member
    const isAlreadyMember = project.members.some((m) => m.user.email.toLowerCase() === email.toLowerCase());
    if (isAlreadyMember) {
      res.status(400).json({ message: 'This user is already a member of this project.' });
      return;
    }

    // Check if an existing user matches this email
    const existingUser = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
    });

    // Create invitation
    const token = Buffer.from(`${projectId}:${email}:${Date.now()}`).toString('hex');
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days

    const invitation = await prisma.invitation.create({
      data: {
        projectId,
        email: email.toLowerCase(),
        token,
        role,
        expiresAt,
      },
    });

    // Get inviter details
    const inviter = await prisma.user.findUnique({ where: { id: inviterId } });

    // Send email (or log link if SMTP not configured)
    const emailResult = await sendProjectInvitationEmail({
      to: email.toLowerCase(),
      inviterName: inviter?.name || 'A teammate',
      projectName: project.name,
      inviteToken: token,
      role,
    });

    // If existing user, create an in-app notification directly as well
    if (existingUser) {
      const notification = await prisma.notification.create({
        data: {
          userId: existingUser.id,
          type: 'PROJECT_INVITE',
          title: 'Project Invitation',
          body: `${inviter?.name || 'A teammate'} invited you to join "${project.name}" as ${role}.`,
          resourceType: 'project',
          resourceId: project.id,
        },
      });
      sendNotificationToUser(existingUser.id, notification);
    }

    res.status(201).json({
      invitation,
      inviteUrl: emailResult.inviteUrl,
      emailSent: emailResult.sent,
      emailReason: emailResult.reason,
      message: emailResult.sent
        ? `Invitation successfully emailed to ${email}`
        : `Invitation created! Share this direct invite link: ${emailResult.inviteUrl}`,
    });
  } catch (error) {
    console.error('Invite error:', error);
    res.status(500).json({ message: 'Failed to send invitation.' });
  }
});

// GET /projects/:projectId/invitations - List invitations
router.get('/:projectId/invitations', authenticate, requireProjectMember('ADMIN'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { projectId } = req.params;
    const invitations = await prisma.invitation.findMany({
      where: { projectId },
      orderBy: { createdAt: 'desc' },
    });
    res.json(invitations);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch invitations.' });
  }
});

// POST /invitations/:invitationId/accept - Accept invitation
router.post('/invitations/:invitationId/accept', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { invitationId } = req.params;
    const userId = req.user!.userId;

    const invitation = await prisma.invitation.findUnique({
      where: { id: invitationId },
      include: { project: true },
    });

    if (!invitation || invitation.status !== 'PENDING') {
      res.status(404).json({ message: 'Invitation not found or already processed.' });
      return;
    }

    // Add user as project member
    await prisma.$transaction(async (tx) => {
      await tx.projectMember.create({
        data: {
          projectId: invitation.projectId,
          userId,
          role: invitation.role,
        },
      });

      await tx.invitation.update({
        where: { id: invitationId },
        data: { status: 'ACCEPTED' },
      });

      await tx.activity.create({
        data: {
          projectId: invitation.projectId,
          actorId: userId,
          action: 'member_joined',
          metadata: JSON.stringify({ role: invitation.role }),
        },
      });
    });

    broadcastToProject(invitation.projectId, 'member:added', {
      projectId: invitation.projectId,
      userId,
    });

    res.json({ message: `Successfully joined ${invitation.project.name}!`, projectId: invitation.projectId });
  } catch (error) {
    console.error('Accept invitation error:', error);
    res.status(500).json({ message: 'Failed to accept invitation.' });
  }
});

// POST /invitations/:invitationId/decline - Decline invitation
router.post('/invitations/:invitationId/decline', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { invitationId } = req.params;
    await prisma.invitation.update({
      where: { id: invitationId },
      data: { status: 'DECLINED' },
    });
    res.json({ message: 'Invitation declined.' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to decline invitation.' });
  }
});

// DELETE /projects/:projectId/invitations/:invitationId - Revoke/cancel invitation
router.delete('/:projectId/invitations/:invitationId', authenticate, requireProjectMember('ADMIN'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { invitationId } = req.params;
    await prisma.invitation.delete({
      where: { id: invitationId },
    });
    res.json({ message: 'Invitation cancelled successfully.' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to cancel invitation.' });
  }
});

// GET /projects/invitations/by-token/:token - Public check of invitation details
router.get('/invitations/by-token/:token', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { token } = req.params;
    const invitation = await prisma.invitation.findUnique({
      where: { token },
      include: {
        project: {
          select: { id: true, name: true, color: true, description: true },
        },
      },
    });

    if (!invitation) {
      res.status(404).json({ message: 'Invitation link is invalid or has expired.' });
      return;
    }

    if (invitation.status !== 'PENDING') {
      res.status(400).json({ message: `This invitation has already been ${invitation.status.toLowerCase()}.` });
      return;
    }

    if (new Date(invitation.expiresAt).getTime() < Date.now()) {
      res.status(400).json({ message: 'This invitation link has expired.' });
      return;
    }

    res.json(invitation);
  } catch (error) {
    res.status(500).json({ message: 'Failed to retrieve invitation details.' });
  }
});

// POST /projects/invitations/accept-by-token - Accept invitation by token
router.post('/invitations/accept-by-token', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { token } = req.body;
    const userId = req.user!.userId;

    if (!token) {
      res.status(400).json({ message: 'Invitation token is required.' });
      return;
    }

    const invitation = await prisma.invitation.findUnique({
      where: { token },
      include: { project: true },
    });

    if (!invitation || invitation.status !== 'PENDING') {
      res.status(404).json({ message: 'Invitation not found or already processed.' });
      return;
    }

    // Check if already a member
    const existingMember = await prisma.projectMember.findUnique({
      where: {
        projectId_userId: {
          projectId: invitation.projectId,
          userId,
        },
      },
    });

    if (existingMember) {
      await prisma.invitation.update({
        where: { id: invitation.id },
        data: { status: 'ACCEPTED' },
      });
      res.json({ message: `You are already a member of ${invitation.project.name}!`, projectId: invitation.projectId });
      return;
    }

    // Add user to project members
    await prisma.$transaction(async (tx) => {
      await tx.projectMember.create({
        data: {
          projectId: invitation.projectId,
          userId,
          role: invitation.role,
        },
      });

      await tx.invitation.update({
        where: { id: invitation.id },
        data: { status: 'ACCEPTED' },
      });

      await tx.activity.create({
        data: {
          projectId: invitation.projectId,
          actorId: userId,
          action: 'member_joined',
          metadata: JSON.stringify({ role: invitation.role }),
        },
      });
    });

    broadcastToProject(invitation.projectId, 'member:added', {
      projectId: invitation.projectId,
      userId,
    });

    res.json({
      message: `Successfully joined ${invitation.project.name}!`,
      projectId: invitation.projectId,
    });
  } catch (error) {
    console.error('Accept token error:', error);
    res.status(500).json({ message: 'Failed to accept invitation.' });
  }
});

// PATCH /projects/:projectId/members/:memberId - Update member role
router.patch('/:projectId/members/:memberId', authenticate, requireProjectMember('ADMIN'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { projectId, memberId } = req.params;
    const { role } = req.body;

    if (!['MEMBER', 'ADMIN'].includes(role)) {
      res.status(400).json({ message: 'Invalid role.' });
      return;
    }

    const updated = await prisma.projectMember.update({
      where: { id: memberId },
      data: { role },
      include: { user: { select: { id: true, name: true, email: true, avatarUrl: true } } },
    });

    broadcastToProject(projectId, 'member:updated', updated);
    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: 'Failed to update member role.' });
  }
});

// DELETE /projects/:projectId/members/:memberId - Remove member
router.delete('/:projectId/members/:memberId', authenticate, requireProjectMember('ADMIN'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { projectId, memberId } = req.params;
    const member = await prisma.projectMember.findUnique({ where: { id: memberId } });

    if (!member) {
      res.status(404).json({ message: 'Member not found.' });
      return;
    }

    if (member.role === 'OWNER') {
      res.status(400).json({ message: 'Cannot remove project owner.' });
      return;
    }

    await prisma.projectMember.delete({ where: { id: memberId } });
    broadcastToProject(projectId, 'member:removed', { memberId, userId: member.userId });
    res.json({ message: 'Member removed successfully.' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to remove member.' });
  }
});

export default router;
