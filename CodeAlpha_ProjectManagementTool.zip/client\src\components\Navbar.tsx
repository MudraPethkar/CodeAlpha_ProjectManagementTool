import React, { useState } from 'react';
import {
  Search,
  Bell,
  Plus,
  CheckCircle2,
  ChevronDown,
  User as UserIcon,
  LogOut,
  FolderPlus,
  LayoutGrid,
  Download,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Project } from '../types';

interface NavbarProps {
  currentProject?: Project | null;
  unreadNotificationsCount: number;
  onOpenNotifications: () => void;
  onOpenSearch: () => void;
  onOpenCreateProject: () => void;
  onOpenCreateTask: () => void;
  onOpenProfile: () => void;
  onNavigateHome: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentProject,
  unreadNotificationsCount,
  onOpenNotifications,
  onOpenSearch,
  onOpenCreateProject,
  onOpenCreateTask,
  onOpenProfile,
  onNavigateHome,
}) => {
  const { user, logout } = useAuth();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showQuickCreate, setShowQuickCreate] = useState(false);

  return (
    <header className="h-16 bg-[#20242C] text-white border-b border-[#2D333F] px-4 md:px-6 flex items-center justify-between sticky top-0 z-40 select-none shadow-sm">
      {/* Left: Brand & Breadcrumb */}
      <div className="flex items-center space-x-4 md:space-x-6">
        <button
          onClick={onNavigateHome}
          className="flex items-center space-x-2.5 group focus:outline-none"
        >
          <div className="w-9 h-9 rounded-xl bg-[#A3E635] flex items-center justify-center text-[#20242C] shadow-md shadow-[#A3E635]/20 group-hover:scale-105 transition-transform duration-200">
            <CheckCircle2 className="w-5 h-5 stroke-[2.5]" />
          </div>
          <div className="flex flex-col text-left">
            <span className="font-extrabold text-lg tracking-tight text-white flex items-center gap-1.5">
              TASKLY
              <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-[#A3E635]/20 text-[#A3E635]">
                v2.0
              </span>
            </span>
          </div>
        </button>

        {currentProject && (
          <div className="hidden sm:flex items-center space-x-2 pl-4 border-l border-[#2D333F] text-sm">
            <span className="text-gray-400">Project /</span>
            <span className="font-semibold text-white flex items-center gap-1.5">
              <span
                className="w-2.5 h-2.5 rounded-full"
                style={{ backgroundColor: currentProject.color }}
              />
              {currentProject.name}
            </span>
          </div>
        )}
      </div>

      {/* Center: Global Search Trigger */}
      <div className="flex-1 max-w-md mx-4 hidden md:block">
        <button
          onClick={onOpenSearch}
          className="w-full bg-[#181B21] border border-[#2D333F] hover:border-gray-600 rounded-lg py-1.5 px-3.5 flex items-center justify-between text-gray-400 text-sm transition-all duration-150"
        >
          <span className="flex items-center space-x-2">
            <Search className="w-4 h-4 text-gray-400" />
            <span>Search tasks, projects, tags...</span>
          </span>
          <kbd className="hidden lg:inline-block text-[11px] bg-[#20242C] border border-[#3A4150] text-gray-300 px-1.5 py-0.5 rounded font-mono shadow-inner">
            Ctrl + K
          </kbd>
        </button>
      </div>

      {/* Right: Actions, Notifications, User */}
      <div className="flex items-center space-x-2.5 sm:space-x-3.5">
        {/* Mobile Search Icon */}
        <button
          onClick={onOpenSearch}
          className="md:hidden p-2 rounded-lg text-gray-300 hover:text-white hover:bg-[#2D333F] transition-colors"
          title="Search"
        >
          <Search className="w-5 h-5" />
        </button>

        {/* Quick Add Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowQuickCreate(!showQuickCreate)}
            className="flex items-center space-x-1.5 bg-[#A3E635] hover:bg-[#8dd321] text-[#20242C] font-semibold text-xs sm:text-sm px-3 py-1.5 rounded-lg shadow-sm transition-all duration-150 active:scale-95"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span className="hidden sm:inline">Create</span>
            <ChevronDown className="w-3.5 h-3.5" />
          </button>

          {showQuickCreate && (
            <div
              className="absolute right-0 mt-2 w-48 bg-[#20242C] border border-[#2D333F] rounded-xl shadow-xl py-1.5 z-50 text-sm animate-in fade-in duration-100"
              onClick={() => setShowQuickCreate(false)}
            >
              <button
                onClick={onOpenCreateTask}
                className="w-full px-3.5 py-2 text-left text-gray-200 hover:bg-[#2D333F] hover:text-[#A3E635] flex items-center space-x-2.5 transition-colors"
              >
                <Plus className="w-4 h-4 text-[#A3E635]" />
                <span>New Task Card</span>
              </button>
              <button
                onClick={onOpenCreateProject}
                className="w-full px-3.5 py-2 text-left text-gray-200 hover:bg-[#2D333F] hover:text-[#A3E635] flex items-center space-x-2.5 transition-colors"
              >
                <FolderPlus className="w-4 h-4 text-[#A3E635]" />
                <span>New Project</span>
              </button>
              <div className="border-t border-[#2D333F] my-1" />
              <a
                href="/CodeAlpha_ProjectManagementTool.zip"
                download="CodeAlpha_ProjectManagementTool.zip"
                className="w-full px-3.5 py-2 text-left text-gray-200 hover:bg-[#2D333F] hover:text-[#A3E635] flex items-center space-x-2.5 transition-colors"
              >
                <Download className="w-4 h-4 text-[#A3E635]" />
                <span>Download Project ZIP</span>
              </a>
            </div>
          )}
        </div>

        {/* Direct Download ZIP Button */}
        <a
          href="/CodeAlpha_ProjectManagementTool.zip"
          download="CodeAlpha_ProjectManagementTool.zip"
          className="hidden md:flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#20242C] hover:bg-[#2D333F] border border-[#2D333F] text-gray-200 hover:text-white transition-all shadow-sm active:scale-95"
          title="Download full project zip"
        >
          <Download className="w-3.5 h-3.5 text-[#A3E635]" />
          <span>Download ZIP</span>
        </a>

        {/* Notification Bell */}
        <button
          onClick={onOpenNotifications}
          className="relative p-2 rounded-lg text-gray-300 hover:text-white hover:bg-[#2D333F] transition-colors"
          title="Notifications"
        >
          <Bell className="w-5 h-5" />
          {unreadNotificationsCount > 0 && (
            <span className="absolute top-1.5 right-1.5 min-w-[18px] h-[18px] px-1 bg-[#A3E635] text-[#20242C] text-[10px] font-black rounded-full flex items-center justify-center animate-pulse">
              {unreadNotificationsCount > 9 ? '9+' : unreadNotificationsCount}
            </span>
          )}
        </button>

        {/* User Profile Menu */}
        <div className="relative">
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center space-x-2 p-1 rounded-full hover:ring-2 hover:ring-[#A3E635]/60 transition-all focus:outline-none"
          >
            <img
              src={user?.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.name || 'User'}`}
              alt={user?.name}
              className="w-8 h-8 rounded-full object-cover border border-[#3A4150]"
            />
          </button>

          {showUserMenu && (
            <div
              className="absolute right-0 mt-2 w-56 bg-[#20242C] border border-[#2D333F] rounded-xl shadow-2xl py-2 z-50 text-sm animate-in fade-in duration-100"
              onClick={() => setShowUserMenu(false)}
            >
              <div className="px-4 py-2 border-b border-[#2D333F]">
                <p className="font-semibold text-white truncate">{user?.name}</p>
                <p className="text-xs text-gray-400 truncate">{user?.email}</p>
              </div>

              <div className="py-1">
                <button
                  onClick={onOpenProfile}
                  className="w-full px-4 py-2 text-left text-gray-300 hover:bg-[#2D333F] hover:text-[#A3E635] flex items-center space-x-2.5 transition-colors"
                >
                  <UserIcon className="w-4 h-4" />
                  <span>Profile & Account</span>
                </button>
                <button
                  onClick={onNavigateHome}
                  className="w-full px-4 py-2 text-left text-gray-300 hover:bg-[#2D333F] hover:text-[#A3E635] flex items-center space-x-2.5 transition-colors"
                >
                  <LayoutGrid className="w-4 h-4" />
                  <span>Dashboard</span>
                </button>
              </div>

              <div className="border-t border-[#2D333F] pt-1 mt-1">
                <button
                  onClick={logout}
                  className="w-full px-4 py-2 text-left text-rose-400 hover:bg-rose-500/10 flex items-center space-x-2.5 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sign out</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
