import { Router, Response } from 'express';
import prisma from '../prisma.js';
import { authenticate } from '../middleware/auth.js';
import { AuthRequest } from '../types/index.js';
import { broadcastToProject, sendNotificationToUser } from '../socket.js';

const router = Router();

// POST /tasks/:taskId/comments - Add comment with @mention extraction
router.post('/tasks/:taskId/comments', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { taskId } = req.params;
    const authorId = req.user!.userId;
    const { body } = req.body;

    if (!body || body.trim().length === 0) {
      res.status(400).json({ message: 'Comment content cannot be empty.' });
      return;
    }

    const task = await prisma.task.findUnique({
      where: { id: taskId },
      include: {
        list: { include: { board: true } },
        assignees: true,
      },
    });

    if (!task) {
      res.status(404).json({ message: 'Task not found.' });
      return;
    }

    const projectId = task.list.board.projectId;

    const comment = await prisma.comment.create({
      data: {
        taskId,
        authorId,
        body: body.trim(),
        reactions: JSON.stringify({}),
      },
      include: {
        author: { select: { id: true, name: true, email: true, avatarUrl: true } },
      },
    });

    // Activity log
    await prisma.activity.create({
      data: {
        projectId,
        taskId,
        actorId: authorId,
        action: 'comment_added',
        metadata: JSON.stringify({ taskTitle: task.title }),
      },
    });

    // Check for @mentions in comment body (e.g. @alex or @riya)
    const mentionMatches = body.match(/@(\w+)/g);
    if (mentionMatches) {
      const mentionedNames = mentionMatches.map((m: string) => m.substring(1).toLowerCase());
      const allMembers = await prisma.projectMember.findMany({
        where: { projectId },
        include: { user: true },
      });

      for (const member of allMembers) {
        const userNameLower = member.user.name.toLowerCase().replace(/\s+/g, '');
        const emailPrefix = member.user.email.split('@')[0].toLowerCase();

        if (
          (mentionedNames.includes(userNameLower) || mentionedNames.includes(emailPrefix)) &&
          member.userId !== authorId
        ) {
          const notification = await prisma.notification.create({
            data: {
              userId: member.userId,
              type: 'COMMENT_MENTION',
              title: 'Mentioned in a Comment',
              body: `${comment.author.name} mentioned you in "${task.title}": "${body.substring(0, 50)}..."`,
              resourceType: 'task',
              resourceId: task.id,
            },
          });
          sendNotificationToUser(member.userId, notification);
        }
      }
    }

    broadcastToProject(projectId, 'comment:created', {
      taskId,
      comment,
    });

    res.status(201).json(comment);
  } catch (error) {
    console.error('Comment error:', error);
    res.status(500).json({ message: 'Failed to add comment.' });
  }
});

// PATCH /comments/:commentId - Edit comment
router.patch('/comments/:commentId', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { commentId } = req.params;
    const userId = req.user!.userId;
    const { body } = req.body;

    const comment = await prisma.comment.findUnique({
      where: { id: commentId },
      include: { task: { include: { list: { include: { board: true } } } } },
    });

    if (!comment) {
      res.status(404).json({ message: 'Comment not found.' });
      return;
    }

    if (comment.authorId !== userId) {
      res.status(403).json({ message: 'You can only edit your own comments.' });
      return;
    }

    const updated = await prisma.comment.update({
      where: { id: commentId },
      data: {
        body: body.trim(),
        edited: true,
      },
      include: {
        author: { select: { id: true, name: true, email: true, avatarUrl: true } },
      },
    });

    const projectId = comment.task.list.board.projectId;
    broadcastToProject(projectId, 'comment:updated', {
      taskId: comment.taskId,
      comment: updated,
    });

    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: 'Failed to update comment.' });
  }
});

// DELETE /comments/:commentId - Delete comment
router.delete('/comments/:commentId', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { commentId } = req.params;
    const userId = req.user!.userId;

    const comment = await prisma.comment.findUnique({
      where: { id: commentId },
      include: { task: { include: { list: { include: { board: true } } } } },
    });

    if (!comment) {
      res.status(404).json({ message: 'Comment not found.' });
      return;
    }

    if (comment.authorId !== userId) {
      res.status(403).json({ message: 'You can only delete your own comments.' });
      return;
    }

    await prisma.comment.delete({ where: { id: commentId } });

    const projectId = comment.task.list.board.projectId;
    broadcastToProject(projectId, 'comment:deleted', {
      taskId: comment.taskId,
      commentId,
    });

    res.json({ message: 'Comment deleted successfully.' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete comment.' });
  }
});

// POST /comments/:commentId/reaction - Toggle emoji reaction
router.post('/comments/:commentId/reaction', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { commentId } = req.params;
    const userId = req.user!.userId;
    const { emoji } = req.body;

    if (!emoji) {
      res.status(400).json({ message: 'Emoji is required.' });
      return;
    }

    const comment = await prisma.comment.findUnique({
      where: { id: commentId },
      include: { task: { include: { list: { include: { board: true } } } } },
    });

    if (!comment) {
      res.status(404).json({ message: 'Comment not found.' });
      return;
    }

    let reactions: Record<string, string[]> = {};
    if (comment.reactions) {
      try {
        reactions = JSON.parse(comment.reactions);
      } catch {
        reactions = {};
      }
    }

    const userList = reactions[emoji] || [];
    if (userList.includes(userId)) {
      // Toggle off
      reactions[emoji] = userList.filter((id) => id !== userId);
      if (reactions[emoji].length === 0) {
        delete reactions[emoji];
      }
    } else {
      // Toggle on
      reactions[emoji] = [...userList, userId];
    }

    const updated = await prisma.comment.update({
      where: { id: commentId },
      data: { reactions: JSON.stringify(reactions) },
      include: {
        author: { select: { id: true, name: true, email: true, avatarUrl: true } },
      },
    });

    const projectId = comment.task.list.board.projectId;
    broadcastToProject(projectId, 'comment:reaction_updated', {
      taskId: comment.taskId,
      commentId,
      reactions,
    });

    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: 'Failed to update reaction.' });
  }
});

export default router;
