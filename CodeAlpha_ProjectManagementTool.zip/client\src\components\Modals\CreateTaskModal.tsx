import React, { useState, useEffect } from 'react';
import { X, Plus, CheckSquare, Calendar, Flag, Sparkles, Check, User as UserIcon } from 'lucide-react';
import { Project, Board, List } from '../../types';
import api from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { SECTION_CARD_OPTIONS } from '../../data/cardTemplates';

interface CreateTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  projects: Project[];
  defaultProjectId?: string | null;
  onTaskCreated: () => void;
}

export const CreateTaskModal: React.FC<CreateTaskModalProps> = ({
  isOpen,
  onClose,
  projects,
  defaultProjectId,
  onTaskCreated,
}) => {
  const { user } = useAuth();
  const [selectedProjectId, setSelectedProjectId] = useState<string>(
    defaultProjectId || (projects[0]?.id || '')
  );
  const [board, setBoard] = useState<Board | null>(null);
  const [selectedListId, setSelectedListId] = useState<string>('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState('MEDIUM');
  const [dueDate, setDueDate] = useState('');
  const [selectedAssigneeIds, setSelectedAssigneeIds] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const currentProject = projects.find((p) => p.id === selectedProjectId);

  // Initialize assignee with logged-in user
  useEffect(() => {
    if (user && selectedAssigneeIds.length === 0) {
      setSelectedAssigneeIds([user.id]);
    }
  }, [user, isOpen]);

  useEffect(() => {
    if (defaultProjectId) {
      setSelectedProjectId(defaultProjectId);
    } else if (projects.length > 0 && !selectedProjectId) {
      setSelectedProjectId(projects[0].id);
    }
  }, [defaultProjectId, projects]);

  useEffect(() => {
    const fetchBoard = async () => {
      if (!selectedProjectId) return;
      try {
        const b = await api.getBoard(selectedProjectId);
        setBoard(b);
        if (b.lists && b.lists.length > 0) {
          // Default to 'To Do' or first list
          const todoList = b.lists.find((l) => l.name.toLowerCase() === 'to do') || b.lists[0];
          setSelectedListId(todoList.id);
        }
      } catch (err) {
        console.error('Failed to load board for task creation:', err);
      }
    };

    if (isOpen && selectedProjectId) {
      fetchBoard();
    }
  }, [isOpen, selectedProjectId]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !selectedListId) {
      setError('Title and destination list are required');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      const finalAssigneeIds =
        selectedAssigneeIds.length > 0 ? selectedAssigneeIds : user?.id ? [user.id] : [];

      await api.createTask(selectedListId, {
        title: title.trim(),
        description: description.trim(),
        priority,
        dueDate: dueDate || undefined,
        assigneeIds: finalAssigneeIds,
      });

      onTaskCreated();
      onClose();
      setTitle('');
      setDescription('');
    } catch (err: any) {
      setError(err.message || 'Failed to create task');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-3xl w-full max-w-lg shadow-2xl border border-gray-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-6 py-4 bg-[#20242C] text-white flex items-center justify-between border-b border-[#2D333F]">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#A3E635] flex items-center justify-center text-[#20242C]">
              <CheckSquare className="w-4 h-4 stroke-[2.5]" />
            </div>
            <h3 className="font-extrabold text-base tracking-tight">Create New Task Card</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-gray-400 hover:text-white hover:bg-[#2D333F] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs font-semibold text-rose-600">
              {error}
            </div>
          )}

          {/* Project & List Pickers */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-[#20242C] block mb-1">
                Project *
              </label>
              <select
                value={selectedProjectId}
                onChange={(e) => setSelectedProjectId(e.target.value)}
                className="w-full text-xs font-semibold px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-[#20242C] focus:outline-none focus:border-[#A3E635]"
              >
                {projects.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-[#20242C] block mb-1">
                Column / List *
              </label>
              <select
                value={selectedListId}
                onChange={(e) => setSelectedListId(e.target.value)}
                className="w-full text-xs font-semibold px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-[#20242C] focus:outline-none focus:border-[#A3E635]"
              >
                {board?.lists.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Quick Preset Selector */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold uppercase tracking-wider text-[#20242C] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-lime-600" />
                <span>Card Options (Instant Fill)</span>
              </label>
              <span className="text-[10px] text-gray-400 font-semibold">Optional</span>
            </div>
            <select
              onChange={(e) => {
                const selectedId = e.target.value;
                if (!selectedId) return;
                const allCards = Object.values(SECTION_CARD_OPTIONS).flat();
                const card = allCards.find((c) => c.id === selectedId);
                if (card) {
                  setTitle(card.title);
                  setDescription(card.description);
                  setPriority(card.priority);
                  if (board?.lists) {
                    const normSec = card.section.toLowerCase().replace('_', '');
                    const matchingList = board.lists.find((l) =>
                      l.name.toLowerCase().replace(/[\s-_]+/g, '').includes(normSec)
                    );
                    if (matchingList) {
                      setSelectedListId(matchingList.id);
                    }
                  }
                }
              }}
              className="w-full text-xs font-semibold px-3 py-2 bg-lime-50/70 border border-[#A3E635] rounded-xl text-[#20242C] focus:outline-none"
              defaultValue=""
            >
              <option value="">⚡ Select a ready card to fill details automatically...</option>
              <optgroup label="📋 Backlog Options">
                {SECTION_CARD_OPTIONS.BACKLOG.map((c) => (
                  <option key={c.id} value={c.id}>
                    [Backlog] {c.title}
                  </option>
                ))}
              </optgroup>
              <optgroup label="📌 To Do Options">
                {SECTION_CARD_OPTIONS.TODO.map((c) => (
                  <option key={c.id} value={c.id}>
                    [To Do] {c.title}
                  </option>
                ))}
              </optgroup>
              <optgroup label="⚡ In Progress Options">
                {SECTION_CARD_OPTIONS.IN_PROGRESS.map((c) => (
                  <option key={c.id} value={c.id}>
                    [In Progress] {c.title}
                  </option>
                ))}
              </optgroup>
              <optgroup label="🔍 Review Options">
                {SECTION_CARD_OPTIONS.REVIEW.map((c) => (
                  <option key={c.id} value={c.id}>
                    [Review] {c.title}
                  </option>
                ))}
              </optgroup>
              <optgroup label="✅ Done Options">
                {SECTION_CARD_OPTIONS.DONE.map((c) => (
                  <option key={c.id} value={c.id}>
                    [Done] {c.title}
                  </option>
                ))}
              </optgroup>
            </select>
          </div>

          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-[#20242C] block mb-1">
              Task Title *
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Design user onboarding flow"
              className="w-full text-xs font-semibold px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-[#A3E635]"
              required
              autoFocus
            />
          </div>

          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-[#20242C] block mb-1">
              Description
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add key context, specifications, or subtasks..."
              rows={3}
              className="w-full text-xs text-[#20242C] p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-[#A3E635] resize-none leading-relaxed"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-[#20242C] block mb-1">
                Priority
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
                className="w-full text-xs font-semibold px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-[#20242C] focus:outline-none focus:border-[#A3E635]"
              >
                <option value="LOW">Low</option>
                <option value="MEDIUM">Medium</option>
                <option value="HIGH">High</option>
                <option value="URGENT">Urgent ⚡</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-[#20242C] block mb-1">
                Due Date
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full text-xs font-medium px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-[#20242C] focus:outline-none focus:border-[#A3E635]"
              />
            </div>
          </div>

          {/* Assignee Selection */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-[#20242C] flex items-center gap-1.5">
                <UserIcon className="w-3.5 h-3.5 text-lime-600" />
                <span>Assigned To</span>
              </label>
              <span className="text-[10px] text-gray-400 font-semibold">
                {selectedAssigneeIds.length} selected
              </span>
            </div>

            <div className="flex flex-wrap gap-2">
              {/* Logged in user */}
              {user && (
                <button
                  type="button"
                  onClick={() => {
                    setSelectedAssigneeIds((prev) =>
                      prev.includes(user.id)
                        ? prev.filter((id) => id !== user.id)
                        : [...prev, user.id]
                    );
                  }}
                  className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center space-x-1.5 transition-all ${
                    selectedAssigneeIds.includes(user.id)
                      ? 'bg-[#A3E635] border-[#A3E635] text-[#20242C] shadow-xs ring-1 ring-[#A3E635]'
                      : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <img
                    src={user.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.name}`}
                    alt={user.name}
                    className="w-4 h-4 rounded-full object-cover"
                  />
                  <span>{user.name} (Me)</span>
                  {selectedAssigneeIds.includes(user.id) && (
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  )}
                </button>
              )}

              {/* Other project members if available */}
              {currentProject?.members
                ?.filter((m) => m.userId !== user?.id)
                .map((m) => (
                  <button
                    key={m.userId}
                    type="button"
                    onClick={() => {
                      setSelectedAssigneeIds((prev) =>
                        prev.includes(m.userId)
                          ? prev.filter((id) => id !== m.userId)
                          : [...prev, m.userId]
                      );
                    }}
                    className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center space-x-1.5 transition-all ${
                      selectedAssigneeIds.includes(m.userId)
                        ? 'bg-[#A3E635] border-[#A3E635] text-[#20242C] shadow-xs ring-1 ring-[#A3E635]'
                        : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <img
                      src={
                        m.user?.avatarUrl ||
                        `https://api.dicebear.com/7.x/avataaars/svg?seed=${m.user?.name}`
                      }
                      alt={m.user?.name}
                      className="w-4 h-4 rounded-full object-cover"
                    />
                    <span>{m.user?.name}</span>
                    {selectedAssigneeIds.includes(m.userId) && (
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    )}
                  </button>
                ))}
            </div>
          </div>

          <div className="flex items-center justify-end space-x-2.5 pt-4 border-t border-gray-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-gray-600 hover:text-gray-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2.5 bg-[#A3E635] hover:bg-[#8dd321] text-[#20242C] font-bold text-xs rounded-xl shadow-sm transition-all"
            >
              {isSubmitting ? 'Creating...' : 'Create Task'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
