import React, { useState, useEffect } from 'react';
import {
  X,
  Users,
  UserPlus,
  Mail,
  Shield,
  Trash2,
  CheckCircle,
  Copy,
  Clock,
  Link,
  Check,
  Info,
} from 'lucide-react';
import { Project, ProjectMember, Invitation } from '../../types';
import api from '../../services/api';

interface ProjectMembersModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project;
  onRefreshProject: () => void;
}

export const ProjectMembersModal: React.FC<ProjectMembersModalProps> = ({
  isOpen,
  onClose,
  project,
  onRefreshProject,
}) => {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<'MEMBER' | 'ADMIN'>('MEMBER');
  const [isInviting, setIsInviting] = useState(false);
  const [invitations, setInvitations] = useState<Invitation[]>([]);
  const [feedback, setFeedback] = useState<{ message: string; type: 'success' | 'error'; inviteUrl?: string } | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const loadInvitations = async () => {
    try {
      const data = await api.getInvitations(project.id);
      setInvitations(data);
    } catch (err) {
      console.warn('Could not load invitations:', err);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadInvitations();
    }
  }, [isOpen, project.id]);

  if (!isOpen) return null;

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;

    setIsInviting(true);
    setFeedback(null);

    try {
      const res = await api.inviteMember(project.id, email.trim(), role);
      setFeedback({
        message: res.emailSent
          ? `Invitation successfully emailed to ${email}!`
          : `Invitation created! Copy the direct link below to share with your teammate.`,
        type: 'success',
        inviteUrl: res.inviteUrl,
      });
      setEmail('');
      loadInvitations();
      onRefreshProject();
    } catch (err: any) {
      setFeedback({ message: err.message || 'Failed to send invitation', type: 'error' });
    } finally {
      setIsInviting(false);
    }
  };

  const handleCopyLink = (token: string, id: string) => {
    const url = `${window.location.origin}?inviteToken=${token}`;
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handleCancelInvitation = async (invitationId: string) => {
    try {
      await api.cancelInvitation(project.id, invitationId);
      loadInvitations();
      onRefreshProject();
    } catch (err) {
      console.error('Failed to cancel invitation:', err);
    }
  };

  const handleUpdateRole = async (memberId: string, newRole: string) => {
    try {
      await api.updateMemberRole(project.id, memberId, newRole);
      onRefreshProject();
    } catch (err) {
      console.error('Failed to change role:', err);
    }
  };

  const handleRemoveMember = async (memberId: string) => {
    if (!confirm('Are you sure you want to remove this member from the project?')) return;
    try {
      await api.removeMember(project.id, memberId);
      onRefreshProject();
    } catch (err) {
      console.error('Failed to remove member:', err);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-3xl w-full max-w-xl shadow-2xl border border-gray-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 bg-[#20242C] text-white flex items-center justify-between border-b border-[#2D333F]">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#A3E635] flex items-center justify-center text-[#20242C]">
              <Users className="w-4 h-4 stroke-[2.5]" />
            </div>
            <div>
              <h3 className="font-extrabold text-base tracking-tight">Project Members & Invites</h3>
              <p className="text-[11px] text-gray-400">{project.name}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-gray-400 hover:text-white hover:bg-[#2D333F] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Invite Form */}
        <div className="p-6 border-b border-gray-100 bg-gray-50/50">
          <h4 className="text-xs font-bold uppercase tracking-wider text-[#20242C] mb-2 flex items-center gap-1.5">
            <UserPlus className="w-3.5 h-3.5 text-[#A3E635]" />
            Invite Collaborators
          </h4>

          {feedback && (
            <div
              className={`p-3 rounded-2xl text-xs font-semibold mb-3 ${
                feedback.type === 'success'
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : 'bg-rose-50 text-rose-700 border border-rose-200'
              }`}
            >
              <p>{feedback.message}</p>
              {feedback.inviteUrl && (
                <div className="mt-2 flex items-center space-x-2 bg-white p-2 rounded-xl border border-emerald-300">
                  <input
                    type="text"
                    readOnly
                    value={feedback.inviteUrl}
                    className="flex-1 text-[11px] font-mono text-gray-700 bg-transparent focus:outline-none truncate"
                  />
                  <button
                    type="button"
                    onClick={() => handleCopyLink(feedback.inviteUrl!.split('token=')[1] || '', 'new')}
                    className="bg-[#20242C] text-[#A3E635] px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1"
                  >
                    {copiedId === 'new' ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Link</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>
          )}

          <form onSubmit={handleInvite} className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="colleague@gmail.com"
                className="w-full text-xs font-medium pl-9 pr-3 py-2 bg-white border border-gray-200 rounded-xl focus:outline-none focus:border-[#A3E635]"
                required
              />
            </div>

            <select
              value={role}
              onChange={(e) => setRole(e.target.value as any)}
              className="text-xs font-bold px-3 py-2 bg-white border border-gray-200 rounded-xl text-[#20242C] focus:outline-none focus:border-[#A3E635]"
            >
              <option value="MEMBER">Member</option>
              <option value="ADMIN">Project Admin</option>
            </select>

            <button
              type="submit"
              disabled={isInviting || !email.trim()}
              className="px-4 py-2 bg-[#A3E635] hover:bg-[#8dd321] text-[#20242C] font-bold text-xs rounded-xl disabled:opacity-50 transition-colors shadow-xs"
            >
              {isInviting ? 'Sending...' : 'Send Invite'}
            </button>
          </form>

          {/* Email Info Notice */}
          <div className="mt-3 p-2.5 rounded-xl bg-blue-50/70 border border-blue-100 flex items-start space-x-2 text-[11px] text-blue-900 leading-snug">
            <Info className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Email Dispatch Note:</span> Real email delivery requires SMTP credentials (e.g. Gmail App Password) configured in <code className="bg-white/80 px-1 py-0.5 rounded font-mono text-[10px]">server/.env</code>. You can also copy any <strong>Direct Invite Link</strong> below to share instantly!
            </div>
          </div>
        </div>

        {/* Members Roster & Pending Invites */}
        <div className="p-6 max-h-72 overflow-y-auto space-y-4">
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2">
              Current Members ({project.members?.length || 0})
            </h4>

            <div className="divide-y divide-gray-100">
              {project.members?.map((m) => (
                <div key={m.id} className="py-2.5 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <img
                      src={m.user?.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${m.user?.name}`}
                      alt={m.user?.name}
                      className="w-8 h-8 rounded-full object-cover border border-gray-200"
                    />
                    <div>
                      <h5 className="text-xs font-bold text-[#20242C]">{m.user?.name}</h5>
                      <p className="text-[11px] text-gray-400">{m.user?.email}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    {m.role === 'OWNER' ? (
                      <span className="px-2.5 py-1 rounded-md text-[11px] font-black uppercase bg-[#20242C] text-[#A3E635]">
                        Owner
                      </span>
                    ) : (
                      <select
                        value={m.role}
                        onChange={(e) => handleUpdateRole(m.id, e.target.value)}
                        className="text-xs font-bold px-2 py-1 bg-gray-50 border border-gray-200 rounded-lg text-[#20242C] focus:outline-none"
                      >
                        <option value="MEMBER">Member</option>
                        <option value="ADMIN">Admin</option>
                      </select>
                    )}

                    {m.role !== 'OWNER' && (
                      <button
                        onClick={() => handleRemoveMember(m.id)}
                        className="p-1.5 text-gray-400 hover:text-rose-500 rounded-lg hover:bg-rose-50 transition-colors"
                        title="Remove member"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Pending Invitations with Copy Link and Cancel */}
          {invitations.length > 0 && (
            <div className="pt-4 border-t border-gray-100">
              <h5 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2">
                Pending Invitations ({invitations.length})
              </h5>
              <div className="space-y-2">
                {invitations.map((inv) => (
                  <div
                    key={inv.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between p-2.5 rounded-xl bg-gray-50 border border-gray-200 gap-2 text-xs"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-[#20242C] truncate">{inv.email}</span>
                        <span className="text-[10px] font-bold uppercase px-1.5 py-0.5 rounded bg-amber-100 text-amber-700">
                          {inv.role}
                        </span>
                      </div>
                      <span className="text-[10px] text-gray-400">
                        Expires in 7 days
                      </span>
                    </div>

                    <div className="flex items-center space-x-2 self-end sm:self-auto">
                      <button
                        type="button"
                        onClick={() => handleCopyLink(inv.token, inv.id)}
                        className="px-2.5 py-1 bg-white hover:bg-gray-100 border border-gray-200 rounded-lg font-bold text-[11px] text-[#20242C] flex items-center space-x-1 transition-colors shadow-2xs"
                      >
                        {copiedId === inv.id ? (
                          <>
                            <Check className="w-3 h-3 text-green-600" />
                            <span className="text-green-600">Copied!</span>
                          </>
                        ) : (
                          <>
                            <Link className="w-3 h-3 text-[#A3E635]" />
                            <span>Copy Link</span>
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => handleCancelInvitation(inv.id)}
                        className="p-1 text-gray-400 hover:text-rose-500 rounded-lg hover:bg-rose-50 transition-colors"
                        title="Cancel invitation"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
